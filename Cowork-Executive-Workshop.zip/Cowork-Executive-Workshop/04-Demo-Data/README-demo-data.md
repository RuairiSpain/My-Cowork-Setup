# Demo Data — read before you use these files

## What these files are

Three sample files for the workshop, for attendees who do not have suitable real files of
their own. **Everything in them is invented.**

- The company **Fabrikam** does not exist.
- The customers — Contoso Retail, Northwind Traders, Woodgrove Bank, Adventure Works,
  Relecloud, Tailspin Toys, Litware Inc, Proseware, Wide World Importers, Graphic Design
  Institute — are Microsoft's standard fictional names.
- The people named are fictional.
- Every figure is synthetic. None represents any real organisation's performance.

Each file says this on its face. Say it out loud too, the first time you open one.

## Do you need them?

| Lab | Needs a file? | Which one |
|---|---|---|
| 1 — Weekly briefing | No | Uses your real email, calendar and Teams |
| 2 — Calendar audit | No | Uses your real calendar |
| **3 — Account risk** | **Yes, if you have no real account data** | `Fabrikam-demo-data.xlsx` |
| **4 — Board numbers** | **Yes, if you have no Power BI report** | `Fabrikam-demo-data.xlsx` (Financials sheet) |
| **5 — House style** | **Yes, always** | Both `.pptx` files |
| 6 — Stakeholder update | No | Uses a real decision you pick |
| 7 — Automations | No | Uses your real account |
| 8 — Build your own | No | Uses a task you pick |

**To use them:** copy this whole folder into `Documents/Cowork/` in your OneDrive.

---

## The files

### `Fabrikam-demo-data.xlsx`

Nine sheets of a fictional software vendor's management data.

| Sheet | Contents |
|---|---|
| Dashboard | Six KPI cards and three charts, all formula-driven — it recalculates live |
| Accounts | 10 customers with contact recency, escalations, sentiment, open commitments |
| Actions | 20 leadership actions with owners, due dates and evidence |
| Milestones | 18 project milestones across 4 projects, baseline vs forecast vs actual |
| Risks_Issues | 12 risks and issues with owners, severity and trend |
| Financials | 360 rows — 24 months across 3 segments and 5 regions |
| Raw_Export | **Deliberately broken.** See below |
| Evidence | What each sheet represents |
| README | The synthetic-data statement |

Headline figures: total ARR €16,885,000 · 4 accounts past the contact threshold · 16 open
actions, 5 of them overdue · €29,125,200 revenue over the last 12 months at 40.3% gross
margin.

**The Raw_Export sheet is broken on purpose.** It contains a duplicate key, the same
customer recorded under two different IDs, a blank row, the text `N/A` sitting in a numeric
column, thousands separators stored as text, three different date formats in one column,
and inconsistent capitalisation. It is the teaching material for the optional exercise in
Lab 3. **Do not clean it.**

### `Fabrikam-Q2-FY26-board-pack.pptx`

A ten-slide board pack dated 26 June 2026 — the quarter before the workshop. Built to the
Executive Design Standard. Slide 9 lists five commitments made to the board, two of which
have no owner or no date. Those gaps are deliberate: they are what Labs 3 and 5 chase.

### `Fabrikam-Q2-FY26-board-pack-OFFBRAND.pptx`

**The same content, presented badly.** Identical figures, identical order, identical
conclusions — but with mixed fonts, an incoherent palette, topic titles instead of
conclusions, overcrowded slides, gradients, shadows, a 3-D chart, emoji, placeholder text
and no source footnotes.

It exists so Lab 5 has something real to find. Putting the two decks side by side is the
point of that lab: the content is the same, so the difference the room sees is entirely
craft.

---

## How the files fit together

The workbook and the on-brand deck describe **the same quarter of the same fictional
business**, deliberately:

- The commitments on slide 9 of the deck appear as open and overdue rows in the workbook's
  Actions sheet.
- The Atlas migration slippage shown on slide 5 is the same slippage the Milestones sheet
  evidences.
- The two at-risk accounts named on slide 6 are the two the workbook scores worst.

That consistency is what lets one lab hand off to the next — a skill can chase a commitment
from the deck and find its current state in the workbook, exactly as it would with real
material.

---

## Rules

- **Never present these figures as anyone's real performance**, in the room or afterwards.
- **Do not clean the Raw_Export sheet** in the shipped file.
- **Do not use the demo data to demonstrate anything about a named individual's
  performance**, even though the people in it are invented. The skills decline that, and
  the workshop should not work around it.
- Delete the folder from your OneDrive after the workshop if you do not want sample data
  sitting alongside your real files.
