# Cowork for Executives — Workshop Pack

**Start here.** Everything you need for the workshop is in this folder. Setup takes about
ten minutes and you only do it once.

---

## What is in this pack

| Folder | What it holds | What you do with it |
|---|---|---|
| `01-Skills/` | 37 ready-to-use Cowork skills | Copy into your Cowork skills folder (below) |
| `02-Guides/` | The overall guide and the skills trigger guide | Read before and during the workshop |
| `03-Exercise-Manual/` | Step-by-step labs | Follow during the workshop |
| `04-Demo-Data/` | Sample files to use if you do not have your own | Copy to OneDrive only if a lab tells you to |

---

## Setup — do this before the workshop

### Step 1 — Find your Cowork folder

1. Open **OneDrive** in your browser.
2. Open the **Documents** folder.
3. Look for a folder called **Cowork**.

If it is not there, open Cowork and ask it: *"Where is my Cowork skills folder?"* It will
tell you the exact location. The folder may have a different name if it was renamed.

### Step 2 — Copy the skills in

1. Open `Documents/Cowork/skills/` in OneDrive. If there is no `skills` folder, create one.
2. Copy **everything inside** `01-Skills/` into it.
3. Do **not** copy the `01-Skills` folder itself — copy its contents.

When you are done, `Documents/Cowork/skills/` should contain an `Executive` folder and
around twenty other folders alongside it.

> **Important:** keep the folder structure exactly as it is. The `Executive` folder
> contains shared settings that the other skills look for by name. Moving or renaming
> folders inside it will stop some skills working.

### Step 3 — Check it worked

Open Cowork and ask:

> Show me my skills.

You should see the Executive skills listed. If you do not, wait a minute for OneDrive to
finish syncing and ask again.

### Step 4 — Copy the demo data (only if you need it)

Most labs work best with your own real emails, meetings and files. Some labs also need a
spreadsheet, a slide deck, or business data — and you may not have a suitable one to hand.

**Copy `04-Demo-Data/` into `Documents/Cowork/` if any of these are true:**

- You do not have a spreadsheet of business data you are happy to use in a room.
- You do not have a slide deck from a previous board or leadership meeting.
- You do not have access to a Power BI report.

Each lab tells you clearly whether it needs a demo file. Copying the folder now takes ten
seconds and saves interrupting the lab later.

---

## What you need on the day

- **Your normal work account**, signed in to Cowork.
- **Email, calendar and Teams history** — most labs read your real ones.
- **At least one recorded meeting** from the last few weeks, if you have one. Meeting
  recordings are only kept for about 60 days, so an older meeting will not be available.
- **A Power BI report**, if you have one. If not, the labs tell you what to use instead.

Nothing else. You do not need to install anything.

---

## Two things to know before you start

**1. Nothing is sent without you.**
Every skill in this pack writes emails to your **Drafts** folder and shows Teams messages
on screen for you to approve. Nothing leaves your account unless you explicitly say send,
in that moment. This applies to the automated tasks too — in fact it applies more
strictly to those.

**2. "I could not find that" is the right answer.**
When a skill cannot find something, it says so and lists what is missing. It does not fill
the gap with a plausible guess. You will see this in several labs. It is the single most
important behaviour in the pack — it is what makes the output safe to put in front of a
board.

---

## If something does not work

| Problem | What to do |
|---|---|
| Skills do not appear | Wait for OneDrive to sync, then ask again. Check they are in `Documents/Cowork/skills/` |
| A skill says it cannot find a file | Check the demo data is copied into `Documents/Cowork/` |
| A skill returns very little | You may not have much history on that topic. Use the demo data instead — the lab says which file |
| A meeting recording is not available | Recordings are kept about 60 days. Use a more recent meeting |
| You are stuck | Ask your facilitator. Do not spend more than three minutes stuck in a lab |

---

## Folder map

```
Cowork-Executive-Workshop/
├── 00-START-HERE.md                    this file
├── 01-Skills/                          copy the CONTENTS into Documents/Cowork/skills/
│   ├── Executive/                      the 18 executive skills + shared settings
│   ├── README.md                       what every skill does
│   └── (19 other skill folders)
├── 02-Guides/
│   ├── Cowork-Executive-Workshop-Guide.md / .docx
│   ├── Cowork-exec-skills-trigger-guide.md
│   └── Cowork-skills-review-and-gap-analysis.md
├── 03-Exercise-Manual/
│   └── Workshop-Exercise-Manual.md / .docx
└── 04-Demo-Data/                       copy into Documents/Cowork/ if you need it
    ├── Fabrikam-demo-data.xlsx
    ├── Fabrikam-Q2-FY26-board-pack.pptx
    ├── Fabrikam-Q2-FY26-board-pack-OFFBRAND.pptx
    └── README-demo-data.md
```
