# The Seven Executive Skills — Scenarios, Capabilities and Trigger Prompts

Workshop handout · 29 September 2026

Each skill below is new in `Cowork_skills_reviewed.zip`. For each: what it does, the
scenario to tell, the prompts that fire it, and the moment to point at when demoing.

**One rule to state before any demo:** nothing sends. Email lands in Drafts, Teams text is
shown for approval, and unattended runs are held to this more strictly, not less.

---

## 1. `exec-autopilot-triggers` — "It runs without you"

### What it does
Designs, installs and maintains the executive's automation estate. It decides the right
mechanism for each job, writes the instruction so it survives unattended, installs it, and
then hands over the controls to pause, edit or delete.

- **Time-based** → scheduled prompts ("every Monday 07:00")
- **Event-based** → event triggers ("whenever the CFO emails me")
- **High-volume** → tool scripts ("across every channel I'm in")
- **Mechanical mail** → Outlook rules · **Cover** → automatic replies

### Scenario to tell
*A CEO returns from a week in Asia. The two things she needed to know arrived on Tuesday
and Wednesday, and both are now sixty messages down. She does not want a better inbox —
she wants to be told at the moment it happens.*

### Prompts that trigger it
- "Tell me the moment anything arrives from the CFO."
- "I want my Monday briefing waiting at 7am without asking for it."
- "Automate this for me — every Friday afternoon."
- "Set up a watcher for anything mentioning the Contoso renewal."
- "What have you got running for me?"
- "Pause everything while I'm on leave."

### The moment to point at
Install one trigger live, then show the estate and **turn one off in ten seconds**. Nothing
builds trust in automation faster than watching it be removed. Then read one installed
instruction aloud and point out that "the usual accounts" would have drifted into nonsense
by week three — the instruction has to be self-contained because there is nobody to ask at
3am.

### Workshop note
This is the centrepiece. If you have 90 minutes, this module is non-negotiable.

---

## 2. `exec-calendar-defence` — "Where did my week go"

### What it does
Audits the calendar against priorities the executive states **in their own words**, then
acts: protects focus blocks, finds genuinely workable slots across senior diaries, books
rooms, consolidates or declines low-value meetings, and sets travel cover.

### Scenario to tell
*A CIO says his priority this quarter is the platform migration. The audit shows 8% of his
accepted hours touch it, and 31% went to a recurring forum that has not produced a decision
since May.*

### Prompts that trigger it
- "Where did my week go?"
- "My calendar is out of control."
- "Protect my Friday afternoons for strategy work."
- "Find 90 minutes with these four people before Thursday, with a room."
- "Clear space in the two days before the board meeting."
- "Set my out of office for the Lisbon trip and name Ana as cover."

### The moment to point at
The gap between the stated priority and the actual percentage. Compute it live. Then point
out that **private appointments show as time blocks only** — it never echoes a medical or
personal subject line into a summary. That single detail is what makes senior people willing
to let it read their calendar.

### Guardrail to state
It counts **accepted** events only for any density claim, and it never assesses whether a
colleague runs good meetings — that is performance evaluation and it declines.

---

## 3. `board-metrics-from-powerbi` — "Numbers you can defend"

### What it does
Reads the organisation's Power BI semantic models directly, queries with DAX, honours
Verified Answers, reconciles reports that disagree, and produces a short deck plus a
one-page numbers annex where every metric carries its model, measure name, filter context
and last-refresh time.

### Scenario to tell
*A CFO is challenged on a growth figure in a board meeting. The number came from a deck,
which came from a spreadsheet, which someone exported in June. He cannot answer, and the
meeting moves on without the decision he came for.*

### Prompts that trigger it
- "Get the board numbers out of Power BI for the QBR."
- "What does the dashboard actually say about Q3 pipeline?"
- "These two reports disagree — which one is right?"
- "Build the metrics pack for Thursday, with sources."
- *(or simply paste an `app.powerbi.com/.../reports/...` link)*

### The moment to point at
The **numbers annex** — every metric with its measure name, filter context and refresh
timestamp. Then the reconciliation slide, where two reports differ and the skill states
both figures and explains why, rather than picking the friendlier one.

### Discussion question for the room
"Which number in your last board pack could you trace to its source today?"

---

## 4. `exec-decision-cockpit` — "Beyond documents"

### What it does
Builds a live, shareable app — filters, drill-down, editable state — bound to real data
(Dataverse, SharePoint lists, Excel, Teams, SQL) rather than a static snapshot. Drill-down
reaches the source record, and every view carries its data source and a last-refreshed stamp.

### Scenario to tell
*A CTO's leadership team maintains the same risk register in four spreadsheets and
reconciles them by email every Thursday. The reconciliation takes longer than the review.*

### Prompts that trigger it
- "Build me a dashboard I can actually click."
- "Turn this spreadsheet into something my directs can update themselves."
- "I want a live view of the portfolio, not another deck."
- "Make this tracker into a tool the leadership team can use."

### The moment to point at
Build it live, share it with one person in the room, and have **them edit it on their own
laptop** while the group watches. That is the demo people describe to colleagues afterwards.

### Guardrail to state
It refuses to present sample or illustrative rows as live data. If there is no system of
record, it says so and offers to stand one up first — it does not fake a dataset to make
the demo prettier.

---

## 5. `exec-audio-briefing` — "The commute is the only free slot"

### What it does
Turns a grounded briefing into a timed spoken audio file — scripted for the ear, budgeted
to a stated length (~140 words per minute), sources attributed out loud, sensitive content
screened out before scripting, and the script delivered alongside so a figure can be checked.

### Scenario to tell
*A managing director's only uninterrupted time is 25 minutes in a car each morning. She
currently spends it on calls she does not need to be on.*

### Prompts that trigger it
- "Give me my week as an eight-minute listen for the drive in."
- "Make me a podcast of what I missed."
- "Brief me on the way to the airport."
- "Read me the overnight news on our market."

### The moment to point at
Play 45 seconds of a real audio brief built from the room's own data. It reliably gets the
biggest reaction of the day. Then point out what it **left out** — it screens for anything
about named individuals' performance, health or compensation before scripting, because
audio gets played out loud in cars and airport lounges.

### Pairs with
`exec-autopilot-triggers` — schedule it for 06:45 so it is ready before the car.

---

## 6. `exec-live-web-desk` — "There's no connector for it"

### What it does
Handles live-web errands: reads authenticated portals the organisation has no connector
for, pulls supplier, travel, expense or regulatory status from a real page, completes
bookings and form submissions, and writes the result back into calendar, mail or a workbook.

### Scenario to tell
*A COO needs the real delivery status of a component order. It lives in a supplier portal
behind a login. Today that is a WhatsApp message to someone in procurement, and a two-day
wait.*

### Prompts that trigger it
- "Check our order status on the supplier portal."
- "Pull my receipts from the travel provider for last month."
- "Submit this in our expense tool."
- "Book the restaurant for the client dinner on the 14th, four people, under €80 a head."
- "Use the browser and go to [site] to check [thing]."

### The moment to point at
It grounds in Microsoft 365 **first** — finding the order reference in the executive's own
mail — so it arrives at the portal knowing what to look for. Then show the write-back: the
booking becomes a calendar event with the reference and the cancellation deadline in the body.

### Guardrail to state
For anything transactional it states the exact action and its limits back to you **before**
proceeding, and it stops dead at anything irreversible you did not ask for. It never invents
a credential or a card number.

---

## 7. `exec-stakeholder-update` — "Say it once, four ways"

### What it does
Takes what is actually true — from the evidence, not from memory — and recasts it for each
audience: board (decision, money, risk, ask), leadership (what changes for their teams),
wider org (what it means daily, and what is explicitly not changing), customer (impact,
commitment, date, owner). Subject states the conclusion; first three lines carry what /
why it matters / the ask.

### Scenario to tell
*A reorganisation has been decided. The board needs the rationale and the cost, 400 staff
need to know whether their manager changes, and three customers need to know nothing
changes for them. Today that is four documents written by four people, and they disagree.*

### Prompts that trigger it
- "Write an update for leadership about this decision."
- "Tell the org about the reorg — and a different version for the board."
- "Send a customer-facing summary of where we are."
- "Communicate this delay properly."
- "Put this into an email for the board."

### The moment to point at
Generate the board version and the all-staff version from the same evidence, side by side.
They should not read like edits of each other. Then point at a line reading `No date agreed`
— it names the absence rather than inventing a date, and that is precisely the line that
would have caused the problem.

### Note for the room
This is the executive-grade version. Its everyday counterpart, `stakeholder-comms`, handles
routine team and project updates — same discipline, less ceremony.

---

## How they combine

The skills are designed to hand off to each other. Three combinations worth demonstrating:

| Combination | What it shows |
|---|---|
| `board-metrics-from-powerbi` → `board-meeting-prep` → `exec-stakeholder-update` | Defensible numbers → the pack → the message afterwards. The full board cycle in one sitting. |
| `monday-morning-exec-briefing` → `exec-audio-briefing` → `exec-autopilot-triggers` | Gather, render for the ear, then make it arrive on its own. The clearest "this removes work" story. |
| `customer-health-review` → `exec-decision-cockpit` → `exec-autopilot-triggers` | A static workbook becomes a live surface the team maintains, refreshed on a schedule. |

## One-line trigger cheat sheet

| Say this | Get this |
|---|---|
| "Tell me the moment X happens" | `exec-autopilot-triggers` |
| "Where did my week go / protect my Fridays" | `exec-calendar-defence` |
| "Get the real numbers out of Power BI" | `board-metrics-from-powerbi` |
| "Build me something my team can click" | `exec-decision-cockpit` |
| "Give me this as audio for the drive" | `exec-audio-briefing` |
| "Check our status on that portal / book this" | `exec-live-web-desk` |
| "Write this for the board, and for the org" | `exec-stakeholder-update` |
