# Cowork Skills Pack — Review, Repairs and Capability Gap Analysis

Prepared for: Ruairi O'Donnell · 29 September 2026
Scope: `Cowork_skills.zip` — 36 files, 17 skills, 2 sub-folders (`Executive/`, `email-inbox/`)
Output: `Cowork_skills_reviewed.zip` — 24 skills, all validated

---

## 1. Headline

The Executive skills are genuinely strong — consistent house style, real trigger phrases,
explicit "when NOT to use" routing, evidence-first workflows, and a shared visual standard
that is enforced by pasting it into the agent brief rather than merely citing it. That last
detail is the single best design decision in the pack and it is what makes the output look
like consulting work rather than default Office.

Three things were wrong, and all three are now fixed. The bigger opportunity is what the
pack does **not** touch: roughly two-thirds of what Cowork can actually do is unrepresented,
and almost all of the missing ground is the part executives find most impressive in a room.

---

## 2. What was wrong — and what I did about it

### 2.1 Thirteen skill folders were completely empty (critical)

The archive contains these folders with **no SKILL.md and no files at all**:

`brand-consistency`, `cite-your-sources`, `clarify-the-ask`, `context-gathering`,
`email-triage`, `excel-analysis`, `project-coordinator`,
`project-management/project-status-tracker/references`, `refining-iteratively`,
`research-synthesis`, `skill-creator`, `teams-connector`, `writing-skills`

A folder without a `SKILL.md` is invisible to Cowork — it will never trigger, and it is dead
weight in a workshop handout. Most likely these are either work-in-progress stubs or the
result of a zip that did not capture file contents from those directories.

**Action:** removed from the reviewed pack. **You should check your source folder** — if
those skills exist locally with real content, the export lost them and needs redoing.

Note also that `email-triage` (empty) duplicates the name of `email-inbox/inbox-triage`
(complete). Two skills with near-identical names compete for the same trigger phrases and
make routing unreliable. Keep one name.

### 2.2 Build artefacts were shipping inside skill folders

`definition-of-done`, `escalate-one-question`, `integrate-me`, `research-scope` and
`source-grounded-writing` each carried `skill-quality-report.html` and
`skill-quality-report.json`. These are validator output, not skill content. They add noise
in a pack an executive audience is meant to read.

**Action:** removed from the reviewed pack. Keep them in your working repo, not in the
distributed pack.

### 2.3 A dangling cross-reference

`escalate-one-question` routes users away to a skill called `stakeholder-comms` in three
places. That skill is not in the pack and is not installed. A "do NOT use this — use X
instead" clause that points at nothing is worse than no clause: it tells Cowork to defer to
a skill that will never load.

**Action:** I built the missing capability as `exec-stakeholder-update` and repointed the
reference at it.

### 2.4 Inconsistent frontmatter

Five skills were missing the `metadata` block (`category` / `icon`) that the other twelve
carry: `board-meeting-prep`, `customer-health-review`, `investment-research-pack`,
`monday-morning-exec-briefing`, `inbox-triage`.

**Action:** added, using an `executive` category for the Executive folder.

### 2.5 What was already correct

Worth saying explicitly, because it is not typical:

- Every referenced file that should exist, does — `references/scoring-model.md`,
  `references/triage-rules.md`, `references/output-format.md`, `reference.md`,
  `references/gap-checklist.md`, `references/pattern-guidance.md`,
  `references/verification.md`. No broken file paths anywhere.
- Every description is well inside the 1,024-character limit (longest: 819).
- Every skill name matches its folder name.
- The `_shared/executive-design-standard.md` header explicitly states it is *not* a skill
  and must never be invoked as one — exactly right, and rarely done.
- Anti-fabrication and no-performance-evaluation guardrails are consistent across the pack.

### 2.6 One thing I did not change, but you should consider

The Executive skills instruct the agent to read
`skills/Executive/_shared/executive-design-standard.md`. That path is correct only if the
pack is installed at the root of your skills folder with the `Executive/` folder intact. It
is the pack's only structural dependency — worth a line in your workshop setup instructions,
which is now in the pack `README.md`.

---

## 3. Capability gap analysis

I mapped the pack against what Cowork can actually reach. The existing 17 skills concentrate
almost entirely on **document generation from M365 evidence** — Word, PowerPoint, Excel, from
mail, Teams, transcripts and files. That is one capability family out of roughly eight.

| Capability | In the original pack | Why it matters to executives |
|---|---|---|
| Documents from evidence (docx/pptx/xlsx) | **Strong** — 11 skills | Core, well covered |
| Web research with date validation | Partial — 2 skills | Covered |
| **Event-driven automation** (`SetupEventTrigger`) | **Absent** | Nothing in the pack reacts to something happening |
| **Scheduled prompts** | **Thin** — mentioned in 4 skills, owned by none | No skill designs the automation estate or manages it |
| **Interactive apps** (App Builder, live data binding) | **Absent** | The single most impressive live demo available |
| **Power BI / semantic models / DAX** | **Absent** | Board numbers currently come from documents, not the warehouse |
| **Audio generation** (`PodcastGenerate`) | **Absent** | Commute time is the one slot executives actually have free |
| **Calendar as an actioned surface** | **Absent** | Skills read the calendar; none defends it |
| **Live authenticated web** (browser) | **Absent** | Everything behind a login, including internal web apps |
| **Power Platform connectors** | **Absent** | The bridge to non-Microsoft systems of record |
| **Batch automation** (tool scripts) | **Absent** | "For every… across all…" requests currently run one call at a time |
| Adaptive Cards / in-chat visuals | Absent | Minor; useful in live demo |
| Loop pages, image generation, SharePoint metadata | Absent | Situational |

The pattern is clear: **the pack produces artefacts on request; it does not yet run
anything on its own, react to anything, or reach outside Microsoft 365.** For a C-suite
audience that is the more compelling half of the story, because it is the half that removes
work rather than speeding it up.

---

## 4. The seven new Executive skills

All seven are written in your existing house style — same section order, same frontmatter
shape, same visual-standard block, same anti-fabrication and draft-only guardrails — and all
validate clean.

| New skill | Gap it closes | The executive sentence that triggers it |
|---|---|---|
| `exec-autopilot-triggers` | Event triggers, scheduled prompts, mail rules, auto-reply — and managing the estate | "Tell me the moment anything arrives from the CFO." |
| `exec-decision-cockpit` | App Builder + live data binding + Power Platform connectors | "Build me a dashboard my directs can actually update." |
| `board-metrics-from-powerbi` | Power BI semantic models, DAX, Verified Answers, reconciliation | "Get the board numbers out of Power BI — and prove them." |
| `exec-audio-briefing` | Audio generation, scripted for the ear, timed, schedulable | "Give me my week as an eight-minute listen for the drive in." |
| `exec-calendar-defence` | Calendar as an actioned surface: audit, protect, find, book, cover | "Where did my week go — and protect my Fridays." |
| `exec-live-web-desk` | Authenticated live web: portals, bookings, submissions, write-back | "Pull our order status from the supplier portal." |
| `exec-stakeholder-update` | Audience-targeted comms (also fixes the dangling reference) | "Write this for the board, and a different version for the org." |

Plus one new reference asset:

**`Executive/_shared/automation-patterns.md`** — the automation counterpart to your design
standard. It carries the mechanism-selection table (time → scheduled prompt; event → event
trigger; volume → tool script; mechanical mail → Outlook rule), the rules that actually bite
(one scheduled prompt per task; the prompt must be self-contained; prove it interactively
before installing), and the safety rules for unattended runs — above all, **draft, never
send**. The four existing skills that mention scheduling now have a single place that
defines how, so they cannot drift apart.

---

## 5. Further candidates, not built

Worth a second wave if the workshop lands well:

1. **`exec-deal-desk`** — pipeline hygiene from CRM via Power Platform connectors, with
   the cockpit as its front end. Closes the non-Microsoft system-of-record gap properly.
2. **`exec-inbox-sla`** — event-triggered: when a message from a top-20 contact goes
   unanswered past a threshold, surface it. Pairs `inbox-triage` with event triggers.
3. **`exec-org-listening`** — sentiment and theme tracking across Teams channels over
   time. Needs careful framing: themes and volumes only, never named individuals.
4. **`exec-decision-log`** — a durable, searchable record of decisions taken, extracted
   from transcripts. Answers "why did we decide that, and who was in the room".
5. **`exec-vendor-review`** — contract Q&A at portfolio scale, obligations and renewal
   dates extracted from agreements in SharePoint.
6. **`exec-quarter-close`** — an orchestrator that runs five existing skills in parallel
   and assembles one pack. Demonstrates multi-skill orchestration, which nothing currently does.

---

## 6. Recommended maintenance rhythm

- Run the skills validator over the pack before each distribution, and keep its output
  **outside** the distributed folders.
- Keep one skill per capability — resolve the `email-triage` / `inbox-triage` duplication.
- Every new Executive skill must: name its trigger phrases, name what it is *not* for and
  which skill owns that instead, paste the design standard into agent briefs rather than
  citing it, and end with a checklist, failure handling and guardrails.
- Re-check `_shared` paths whenever the folder structure moves — it is the pack's only
  structural dependency.
