# Cowork for Executives — Workshop Facilitator Guide

Audience: executives and C-suite managers · Duration: half day (3h 15m) · Group: 8–16
Pack: `Cowork_skills_reviewed.zip` — 24 skills, installed before the room opens

---

## The argument the workshop has to make

Most executives have already seen AI write an email. That is not the story. The story is:

1. **Evidence, not memory.** Every deliverable is built from what is actually in your mail,
   meetings, files and data — and it names its sources, and it names what it could not find.
2. **The artefact, not the answer.** A briefing pack, a scored workbook, a board deck — in
   your house style, ready to table.
3. **It runs without you.** Scheduled, triggered, and reporting into your drafts folder
   before you wake up.
4. **It reaches outside.** Power BI, the live web, interactive apps your team can use.

Run the day in that order. Points 3 and 4 are the ones that change minds, and they are the
ones the new skills cover.

---

## Demo assets — use these when attendees have nothing of their own

Attendees reliably have mail, calendar, Teams and transcripts. They frequently do **not**
have a Power BI report they can reach, a spreadsheet worth analysing, or a prior board
deck. Two synthetic assets cover that, and they are **deliberately consistent with each
other** — the commitments in the deck appear as open and overdue actions in the workbook,
and the Atlas slippage on slide 5 is the same slippage the milestones sheet evidences.
That is what lets one demo hand off to the next.

| Asset | Contents | Feeds |
|---|---|---|
| `Fabrikam-demo-data.xlsx` | Dashboard · Accounts (10) · Actions (20) · Milestones (18) · Risks & Issues (12) · Financials (360 rows, 24 months) · Raw_Export (flawed on purpose) · Evidence · README | Modules 3, 4, 6 |
| `Fabrikam-Q2-FY26-board-pack.pptx` | Last quarter's board pack, 26 June 2026, with five open commitments | Modules 2, 4 |

The vendor **Fabrikam** is fictional and the customers use Microsoft's standard fictional
names. Every artefact says "synthetic demo data" on its face — and **so should you**, each
time you open one.

The `Raw_Export` sheet is flawed on purpose: duplicate key, the same customer under two
ids, a blank row, `N/A` in a numeric column, thousands separators in text, three date
formats, inconsistent casing. It is the teaching material for `excel-analysis`. Do not
clean it.

Full degradation paths for every dependency — Power BI, transcripts, connectors, browser,
audio — are in `Executive/_shared/demo-fallbacks.md` in the pack.

### The Power BI fallback specifically

A semantic model cannot be generated. In order of preference:

1. **Publish one of Microsoft's official samples to a workspace before the session.** This
   is the only fallback with real DAX, a real schema and a real refresh timestamp.
   - Sample index — `https://learn.microsoft.com/en-us/power-bi/create-reports/sample-datasets`
   - Financial Sample workbook — `https://learn.microsoft.com/en-us/power-bi/create-reports/sample-financial-download`
   - Contoso Sales `.pbix` — `https://www.microsoft.com/en-us/download/details.aspx?id=46801`
   - Power BI Desktop samples on GitHub — `https://github.com/microsoft/powerbi-desktop-samples`
2. **No workspace at all:** run `board-metrics-from-powerbi` against the `Financials` sheet
   of the demo workbook via `excel-analysis`, and say plainly that this is a degradation.
3. **Name what the fallback loses** — Verified Answers, the model's agreed measures, and
   the real refresh timestamp. Those are the parts that make the board-numbers argument,
   so the gap is worth stating rather than glossing.

---

## Before the room opens

- Install the pack in each attendee's `Documents/Cowork/skills/` with the `Executive/`
  folder structure intact — the `_shared/` references are read by path.
- Put the two demo assets somewhere every attendee can open them.
- Confirm each attendee has at least 30 days of mail and calendar history, and at least one
  recorded meeting with a transcript. A skill with no evidence demos badly through no fault
  of its own.
- Identify one Power BI report per attendee — or publish a Microsoft sample to a shared
  workspace — for Module 4.
- Agree a "safe" customer or account name that can be said out loud.
- Pre-brief: **nothing sends**. Everything lands in Drafts. Say it early — it is the single
  biggest adoption blocker in a senior room.

---

## Module 1 — Ten minutes back before 9am (30 min)

**Case study.** *A CIO returns from three days of travel to 400 unread messages and a
9am board pre-read she has not seen.*

**Run live:** `monday-morning-exec-briefing`, then `email-inbox/inbox-triage`.

**The moment to point at:** the Gaps section. When the briefing says "I could not reach the
Sales channel", that is the credibility beat — it is the opposite of a system that makes
things up. Dwell on it.

**Discussion:** what would you want in your top five, that nobody currently tells you?

---

## Module 2 — The pack you did not have to ask anyone for (35 min)

**Case study.** *A COO has a steering committee at 14:00. The deck normally takes an
analyst a day and a half, and last quarter's commitments are in a transcript nobody reread.*

**Run live:** `board-meeting-prep` on a real meeting in the attendee's calendar.
**Fallback:** use `Fabrikam-Q2-FY26-board-pack.pptx` as the prior-quarter pack and chase
its slide 9 commitments against the workbook's Actions sheet.

**The moment to point at:** the likely-questions section, and the commitment status pulled
out of the previous meeting's transcript. "Last time you committed to X; here is what has
happened since, and here is what has not."

**Then show the design standard.** Open `Executive/_shared/executive-design-standard.md` on
screen. Explain that the deck looks like that because the standard is pasted into the brief,
not referenced. This is the moment the room understands that skills are *configuration*, not
magic — and it is what makes them willing to ask for their own.

---

## Module 3 — Where is the risk, and who owns it (30 min)

**Case study.** *A CRO believes the portfolio is healthy. Three accounts have not had a
meeting in nine weeks and nobody has said so out loud.*

**Run live:** `customer-health-review` → the Excel dashboard. Then `org-action-tracker`
against a real leadership meeting series. **Fallback:** the Accounts and Actions sheets of
`Fabrikam-demo-data.xlsx` — Northwind Traders (77 days since contact, 3 escalations,
sentiment 2.1) is the account the room should spot.

**Optional 5 minutes:** open the `Raw_Export` sheet and run `excel-analysis` on it. Finding
a duplicate key and the same customer under two ids, in a file someone would have reported
from, makes the point about unchecked data very quickly.

**The moment to point at:** an action whose owner reads `unassigned` and whose due date
reads `no date found`. Ask the room how many of those they think exist in their own forums.

**Guardrail to state explicitly:** this scores accounts, never people. Show the refusal in
`quarterly-evidence-pack` and `manager-weekly-team-pulse` — the pack declines to rank
individuals. Senior audiences ask about this within ten minutes; answer it before they do.

---

## Module 4 — Numbers you can defend in the room (25 min) · *new*

**Case study.** *A CFO is challenged on a growth figure in a board meeting. The number came
from a deck, which came from a spreadsheet, which someone exported in June.*

**Run live:** `board-metrics-from-powerbi` against a real report, or against a published
Microsoft sample. **Fallback:** the `Financials` sheet of `Fabrikam-demo-data.xlsx` —
360 rows across 24 months, 3 segments and 5 regions — and say it is a degradation.

**The moment to point at:** the numbers annex — every metric with its model, its measure
name, its filter context and its last refresh time. And the reconciliation slide, where two
reports disagree and the skill says so rather than picking one.

**Discussion:** which number in your last board pack could you not trace today?

---

## Module 5 — It runs without you (30 min) · *new, the centrepiece*

**Case study.** *A CEO wants to know the moment a named regulator or top-three customer
emails — and wants the Monday brief waiting at 07:00 without asking for it.*

**Run live:** `exec-autopilot-triggers`. Install one scheduled prompt and one narrowly
scoped event trigger, for real, for a volunteer.

**The four things to land:**
- **Time → schedule. Event → trigger.** Show the selection table in
  `Executive/_shared/automation-patterns.md`.
- **The instruction must be self-contained.** Read one out loud. Point out that "the usual
  accounts" would have drifted into nonsense by week three.
- **Unattended runs draft, never send.** Non-negotiable, and it is why they can say yes.
- **Show the estate, then turn one off.** Nothing builds trust in automation faster than
  watching it be removed in ten seconds.

**Optional flourish (5 min):** `exec-audio-briefing` — play 45 seconds of a real audio brief
built from the room's own data. It reliably gets the biggest reaction of the day.

---

## Module 6 — Beyond documents (25 min) · *new*

**Case study.** *A CTO's leadership team maintains the same risk register in four
spreadsheets, and reconciles them by email every Thursday.*

**Run live:** `exec-decision-cockpit` — build a small live app bound to a real SharePoint
list, and share it with one person in the room who then edits it on their own laptop.

**If time allows, 5 minutes of `exec-live-web-desk`** against an internal web app with no
connector. The point is not the site; the point is that "there's no connector for it" stops
being a reason.

---

## Module 7 — Build your own, in twenty minutes (30 min)

Each attendee names one recurring task they personally dread. In pairs, they write the four
things every skill in this pack has:

1. **What it does**, in one sentence.
2. **When to use it** — three phrases they would actually say out loud.
3. **When NOT to use it** — and which skill owns that instead.
4. **What "never" means here** — the fabrication, sending or privacy rule that must hold.

Then build two of them live in front of the room. Hand out the pack `README.md` conventions
list as the take-home template.

---

## Close (10 min)

- Each attendee leaves with the pack installed, one scheduled prompt running, and one skill
  of their own.
- Set a 30-day check-in — with `exec-autopilot-triggers`, on a schedule, naturally.
- Standing offer: send the task you dread, get a skill back.

---

## Facilitator notes

**What will go wrong, and what to say**

| Risk | Mitigation |
|---|---|
| A skill returns thin results because the attendee's history is sparse | Use a prepared account for the live run; let attendees run theirs in parallel |
| Someone asks it to rank their team | Perfect moment — show the refusal. It is a feature, and it is why Legal will sign off |
| A transcript is older than ~60 days and cannot be retrieved | Expected; say so plainly. It demonstrates the honest-gaps behaviour |
| Output looks like default Office | The design standard was not pasted into the brief. Fix live — it is a good teaching moment |
| "Can it just send it?" | Yes, on explicit instruction, in that turn. Never on a schedule. Explain why that line exists |

**Questions a C-suite room always asks**

- *Where does the data go?* Inside your tenant, under your existing permissions.
- *Can it see things I can't?* No. It has exactly your access, nothing more.
- *Does it make things up?* The skills forbid it and mark absent facts as gaps — show a
  real `No evidence found` on screen rather than asserting it.
- *What happens when it's wrong?* Every figure names its source, so it is checkable. That is
  the whole design.
- *Who maintains these?* Skills are text files you own and can edit. Show one.

**Sequencing advice.** If you only have 90 minutes, run Modules 1, 5 and 7. The briefing
earns attention, the automation earns the decision, and building their own earns adoption.
Modules 2, 3, 4 and 6 are the depth you add when you have the full half day.
