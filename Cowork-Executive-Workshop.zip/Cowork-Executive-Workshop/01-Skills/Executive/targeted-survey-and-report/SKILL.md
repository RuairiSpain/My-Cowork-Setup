---
name: targeted-survey-and-report
description: |
  Runs a targeted pulse survey end to end: resolves the audience, designs a short
  neutral question set, distributes it by personalised email or Teams, tracks
  responses in a workbook, then collects replies and reports results with charts
  and a findings write-up. Use when the user asks to "run a pulse survey",
  "survey my team about X", "survey these stakeholders", "send a questionnaire",
  "collect the survey responses", or "report on the survey results".
  Do NOT use for a single broadcast announcement with no questions, for scheduling
  meetings or polls inside a live meeting, or for HR-grade engagement surveys
  requiring formal anonymity guarantees and an official instrument.
metadata:
  category: research
  icon: PollHorizontal
---

## Purpose

Two operations in one skill: **A — Launch** a short pulse survey to a resolved
audience, and **B — Collect & report** the responses honestly, with the real
response rate and no extrapolation over silence.

## When to Use

- A quick read on team or stakeholder sentiment on a specific topic
- Follow-up wave of an earlier pulse, for a trend comparison
- Collating replies that have already come back from a survey you sent

## When NOT to Use

- One-way announcements with no questions
- In-meeting live polls
- Formal HR engagement or compliance surveys needing guaranteed anonymity
- Anything requiring profiling respondents by protected characteristics — refuse

## Inputs to Gather

Establish, asking only what is genuinely missing: the topic, the audience
definition, the channel (email vs Teams), the response deadline, whether this is
wave 1 or a follow-up, and whether the user wants drafts or explicit send.

| Need | Tool |
|---|---|
| Audience resolution | `me_profile-SearchPeople`, `GetDirectReportsDetails`, `GetOrgTree`, `GetMultipleUsersDetails` |
| Teams audience | `m365_teams-ListTeams`, `ListChannelMembers`, `ListChatMembers` |
| Distribution | `outlook-CreateDraftMessage` (default), `outlook-SendEmailWithAttachments` (explicit send), `m365_teams-PostChannelMessage`, `m365_teams-PostMessage` |
| Reply sweep | `outlook-ListMessages`, `outlook-GetMessage`, `m365_teams-ListChatMessages`, `ListChannelMessages`, `m365_search-SearchM365` |

## Operation A — Launch

1. **Resolve the audience.** Build an explicit recipient list (name, email,
   role/team) and show it to the user for confirmation. Never guess membership;
   if a name cannot be resolved, list it as unresolved.
2. **Design the question set.** 5–8 questions: mostly 1–5 scale (with the scale
   anchors stated, e.g. 1 = strongly disagree, 5 = strongly agree) plus exactly
   one open free-text question. Wording must be neutral and non-leading — no
   double-barrelled items, no presupposition. Show the set for approval.
3. **Create the tracking workbook** via `xlsx-agent` before sending:
   - **Audience sheet:** name, email, team, channel, sent date, response received
     (Y/N), response date.
   - **Questions sheet:** question ID, text, type, scale anchors, send date,
     response deadline, wave number.
4. **Distribute.** Default to **one personalised draft per recipient**
   (`outlook-CreateDraftMessage`) — never a single bulk To: line. Only when the
   user explicitly says to send: `outlook-SendEmailWithAttachments` per recipient,
   or `m365_teams-PostChannelMessage` / `PostMessage` for a Teams blast (show the
   exact text first). Each message states the purpose, the deadline, how to reply,
   and how responses will be reported.
5. **Record** sent dates and the deadline back into the workbook, and tell the
   user when to run Operation B.

## Operation B — Collect & Report

1. **Sweep replies** across the survey window from mail and Teams using the tools
   above. Match each reply to a respondent on sender identity; unmatched replies
   go to an `Unmatched` list rather than being assigned by guesswork.
2. **Parse** each response: per-question scores and free-text. If a response is
   partial, record the answered items only — never impute a missing score.
3. **Compute** the real response rate (responses ÷ audience), per-question mean
   and distribution. State N for every statistic. Never extrapolate from
   non-respondents, and caveat any question with N < 5 as indicative only.
4. **Theme the free text**: 3–5 themes with counts, plus representative quotes
   **anonymised** (no names, no identifying detail) unless the user explicitly
   asks for attribution.
5. **Build the results workbook** via `xlsx-agent`:
   - **Results sheet:** one row per respondent (or respondent ID), one column per
     question, free-text in its own column.
   - **Dashboard sheet:** bar chart of average score per question; response-rate
     KPI cell plus a doughnut/pie of responded vs not; a distribution chart of
     scores; and a trend chart across waves when a prior wave exists.
6. **Write up the findings** via `docx-agent` — headline result, method and
   response rate, per-question analysis with N, free-text themes with anonymised
   quotes, limitations, recommended actions. If the user only wants highlights,
   give a concise inline summary in chat instead and say the document was skipped.

## Deliverable Spec

Always delegate files: `xlsx-agent` for the tracking/results workbook,
`docx-agent` for the findings document. Briefs must contain the actual data, the
exact chart types listed above, and the stated response rate. Never hand-author an
Office file, and never fabricate a respondent, score or quote.

## Quality Bar / Verification Checklist

- [ ] Audience list confirmed by the user; unresolved names listed, not assumed
- [ ] 5–8 questions, scale anchors stated, exactly one open text item
- [ ] Question wording neutral — no leading or double-barrelled items
- [ ] Messages are personalised drafts by default; sends only on explicit instruction
- [ ] Actual response rate stated with numerator and denominator
- [ ] Every statistic carries its N; no imputation, no extrapolation over silence
- [ ] Quotes anonymised unless the user asked for attribution
- [ ] No profiling by protected characteristics anywhere
- [ ] Dashboard charts render; trend chart present only if a prior wave exists
- [ ] en-GB spelling throughout

## Failure Handling

- **Low response rate (<30%):** report it prominently as a limitation, present
  results as indicative, and offer a reminder wave (drafts by default).
- **Unmatched replies:** list them separately; ask the user to resolve rather than
  assigning them.
- **Free text too sparse to theme:** report the quotes as-is and say themes could
  not be derived.
- **No prior wave found:** omit the trend chart and say so; do not invent a baseline.
- **Tool/permission failure:** name the channel that could not be swept and mark
  that portion of the audience as uncollected, not as non-responding.

## Guardrails

- Default to DRAFTS; send or post only on an explicit instruction from the user.
- Never invent respondents, scores, dates or quotes.
- Never report a projected or "adjusted" response rate — only the actual one.
- Never attribute free-text quotes to named individuals unless asked.
- Never segment or profile respondents by protected characteristics.
