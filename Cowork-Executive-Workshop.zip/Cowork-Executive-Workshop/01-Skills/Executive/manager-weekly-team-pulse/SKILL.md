---
name: manager-weekly-team-pulse
description: |
  Builds a weekly team delivery and workload pulse for a manager from meetings,
  actions, Teams activity and files, producing a Word briefing plus an Excel
  workbook with time-series charts and a KPI dashboard. Use when the user asks to
  "prepare a team health summary", "weekly team pulse", "how is my team doing this
  week", or "where are the delivery risks in my team". Do NOT use to evaluate, rank
  or compare individual performance — this skill declines that. For evidence packs
  about a person use quarterly-evidence-pack; for new-joiner ramp use
  onboarding-30-60-90-review.
metadata:
  category: productivity
  icon: PeopleTeam
---

## Purpose

Give a manager one weekly view of **delivery and workload** across their direct
reports: what moved, what is at risk, where the meeting load is concentrated, and
what needs a decision. Team-level visibility only — never individual appraisal.

## When to use

- Friday or Monday review of the team's week.
- Preparing for a skip-level or a manager's own status update.
- Checking for workload hotspots or slipping commitments.

## When NOT to use

- Any request to rate, rank, score or compare people — decline and redirect.
- Evidence gathering for a performance cycle — use `quarterly-evidence-pack`.
- New-joiner ramp tracking — use `onboarding-30-60-90-review`.
- External market analysis — use `overnight-strategy-analyst`.

## Inputs to gather

| Source | Tool | What to extract |
|---|---|---|
| Team roster | `me_profile-GetDirectReportsDetails` | Names, UPNs, roles |
| Person lookup | `me_profile-SearchPeople`, `me_profile-GetUserDetails` | Resolve ambiguous names |
| Meetings | `outlook_calendar-ListCalendarView` | Subject, organiser, attendees, duration, start time |
| Transcripts | `graph-ListMeetingTranscripts`, `graph-GetMeetingTranscript` | Decisions and actions, where available |
| Mail | `outlook-ListMessages` | Commitments made, escalations, blockers |
| Teams | `m365_teams-ListChannelMessages`, `m365_teams-ListChatMessages` | Open threads, unanswered asks |
| Files | `sharepoint_onedrive-SearchDrive`, `m365_search-SearchM365` | Artifacts produced this week |
| Timezone | `outlook_calendar-GetUserDateAndTimeZoneSettings` | Correct week boundaries |

Window: Monday 00:00 to Sunday 23:59 of the reporting week, in the manager's timezone.

## Workflow

1. **Resolve the team.** `me_profile-GetDirectReportsDetails`. If it returns nobody,
   ask for the names rather than guessing.
2. **Set the window** using the manager's timezone; state the exact dates in outputs.
3. **Collect delivery signals** per person: meetings led or attended, artifacts
   created, threads owned, commitments made and closed. Record each with its source
   artifact name and date.
4. **Collect workload signals at team level:** total meeting hours per person per
   week, count of meetings outside standard working hours, back-to-back density.
   Report these as capacity facts, never as diligence or commitment judgements.
5. **Identify risks.** A risk is evidenced: a slipped date named in a mail, an
   unanswered escalation, an action open beyond its due date, a single point of
   failure across two workstreams. Each risk cites its evidence.
6. **Compare with prior weeks** where earlier runs or data exist, so the charts are a
   genuine time series. If only one week is available, say so and chart one point.
7. **Build the workbook.** Delegate to `xlsx-agent` (spec below).
8. **Build the briefing.** Delegate to `docx-agent` (spec below), referencing the
   workbook by file name.
9. **Present in chat**: three headline facts, the top risk, and any gaps.

## Deliverable spec

**Excel — brief to `xlsx-agent`:** workbook `Team Pulse — week of <date>.xlsx` with
- `Data` — tidy source rows: Person | Week | Meeting hours | Meetings after hours |
  Actions opened | Actions closed | Artifacts produced.
- `Meeting load` — line or stacked column **time series**: weekly meeting hours per
  team member across available weeks.
- `Actions` — time series of open vs closed actions per week.
- `Risks` — table: Risk | Workstream | Evidence (artifact + date) | Impact | Likelihood
  | Owner | Next step, with **conditional formatting** as a heat table on Impact and
  Likelihood (green/amber/red).
- `Dashboard` — KPI cells driven by formulas over `Data` (total meeting hours, average
  hours per person, % actions closed, count of red risks, week-on-week delta), plus
  the two charts embedded.
Formulas must be real Excel formulas referencing `Data`, not pasted constants.

**Word — brief to `docx-agent`:** `Weekly Team Pulse — <team>, week of <date>`,
styled with headings and tables: Executive summary (5 bullets) · Delivery highlights
(per workstream, each with evidence) · Risks and blockers (table, most severe first) ·
Workload observations (team-level capacity, no individual judgement) · Decisions
needed from the manager · Gaps and data limitations · Appendix: sources by artifact
name and date.

## Recurring schedule

Offer `host-SetupScheduledPrompt` for Fridays (e.g. 16:00 local, weekly), with a
prompt that names the team, the window and the two deliverables. Confirm the timezone
first and tell the user how to edit or remove the schedule.

## Quality bar / verification checklist

- [ ] Team resolved from `me_profile-GetDirectReportsDetails`, not assumed.
- [ ] Week boundaries stated explicitly in local time.
- [ ] Every highlight and risk cites a real artifact name and date.
- [ ] Charts are genuine time series, or single-point with the limitation stated.
- [ ] Dashboard KPIs are formulas over `Data`.
- [ ] No individual is rated, ranked, scored or compared.
- [ ] After-hours and meeting-load figures are framed as capacity, not behaviour.
- [ ] Missing data appears as a labelled gap, never as an inferred number.

## Failure handling

- **No direct reports returned:** ask for names; do not infer the team from mail.
- **Calendar or transcript access denied:** report the gap, continue with what is
  available, and mark affected sections "partial — calendar not accessible".
- **No prior weeks:** produce the workbook anyway with one data point and note that
  trends need a second run.
- **xlsx-agent or docx-agent fails:** retry once with a reduced spec; if it still
  fails, output the tables in chat and state clearly that the file was not created.

## Guardrails

- Never auto-send or post the pulse; show it for review before sharing with anyone.
- If a data source is unavailable, cannot be read or returns nothing, mark the section partial and say so; never infer a number.
- Always confirm the team list and the week window before building the files.
- **Delivery and workload visibility only.** Never evaluate, rank, score or compare
  individual performance, competence, attitude or potential. If asked, decline in one
  sentence and say that judgement sits with the manager and HR — then offer the
  factual, delivery-level view instead.
- Do not infer wellbeing, health, engagement or intent from activity data. After-hours
  activity is reported as a team-level workload signal to investigate with the person,
  never as evidence about them.
- Do not report on anyone outside the manager's direct reports.
- No fabricated names, numbers, dates or quotes; if the data is not there, say so.
