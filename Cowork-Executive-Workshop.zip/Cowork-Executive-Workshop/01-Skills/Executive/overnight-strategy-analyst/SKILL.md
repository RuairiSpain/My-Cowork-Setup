---
name: overnight-strategy-analyst
description: |
  Researches external announcements over a stated time window, validates publication
  dates, cross-references internal signals, and produces a sourced Word executive
  brief with impact, opportunities, threats and owned actions. Use when the user asks
  to "analyse the latest <topic> announcements and evaluate impact on our business",
  "overnight strategy brief", "what happened in <market> last week and what does it
  mean for us", or "competitive impact summary". Do NOT use for internal-only status
  reporting (use manager-weekly-team-pulse), for deep multi-week literature research,
  or for drafting a customer-facing pitch deck.
metadata:
  category: research
  icon: GlobeSearch
---

## Purpose

Turn a defined window of external news into a short, decision-ready executive brief
that a Cloud Solution Architect can send to leadership. Every external claim is
sourced; nothing is asserted from model pre-training as if it were current news.

## When to use

- A named topic, vendor, competitor or market needs an impact read for leadership.
- A recurring overnight or Monday-morning scan of a watch-list.
- Someone asks "what changed and what does it mean for us".

## When NOT to use

- Team delivery or workload reporting — use `manager-weekly-team-pulse`.
- Performance or evidence gathering about people — use `quarterly-evidence-pack`.
- Requests with no external component (purely internal summarisation).

## Inputs to gather

| Source | Tool | What to extract |
|---|---|---|
| External news | `host-web_search`, `host-web_fetch` | Headline, publisher, publication date, URL, key facts |
| Internal signals | `m365_search-SearchM365` | Existing docs, decks, mails mentioning the topic |
| Mail context | `outlook-ListMessages` | Threads where leadership already discussed the topic |
| Teams context | `m365_teams-ListChannelMessages`, `m365_teams-ListChatMessages` | Live reactions, customer chatter |
| Files | `sharepoint_onedrive-SearchDrive` | Prior briefs to avoid repeating known material |
| Audience | `me_profile-GetMyDetails`, `me_profile-GetManagerDetails` | Who the brief is for |

If the user did not state a window, default to the **last 7 days** and say so in the brief.

## Workflow

1. **Fix the scope.** Confirm topic(s), the time window (explicit dates), and the
   audience. Record the window in ISO dates — it governs every later filter.
2. **Search broadly, then narrow.** Run `host-web_search` with several distinct
   queries (vendor announcement, analyst reaction, customer/partner impact). Do not
   fan out redundant rewordings of one query.
3. **Verify every candidate.** `host-web_fetch` each promising URL and read the
   publication date from the page. **Discard anything outside the window**, anything
   undated, and anything that is a re-post without an original date. Keep a running
   table: title | publisher | date | URL.
4. **Cross-reference internally.** `m365_search-SearchM365` for the same keywords to
   find what the organisation already knows, already promised a customer, or already
   decided. Cite internal artifacts by exact file or subject name and date.
5. **Analyse.** For each confirmed item, write one factual "what happened" line and
   one "so what for us" line. Separate observation from inference and label inference
   as such ("assessment:", "if this holds, then …").
6. **Draft the brief** in the structure below, with a Sources section.
7. **Create the document.** Delegate to `docx-agent` with a concrete brief (see
   Deliverable spec). Never hand-author Office XML or markdown-as-docx.
8. **Distribution — draft by default.** Unless the user explicitly says "send":
   - Email: `outlook-CreateDraftMessage` with the document attached
     (`outlook-AddDraftAttachments` / `outlook-UploadAttachment`), then tell the user
     the draft is waiting in Drafts.
   - Teams: show the proposed post text in chat for approval; post with
     `m365_teams-PostChannelMessage` only after an explicit yes.
   Only on an explicit instruction to send may you use
   `outlook-SendEmailWithAttachments` or post directly.

## Deliverable spec

Brief to `docx-agent`: a styled Word executive summary, title
`<Topic> — Strategy Brief, <window>`, professional corporate styling, headings and
tables, 2–4 pages, sections in this order:

1. **Executive summary** — five bullets maximum, the decision-relevant facts only.
2. **What happened** — table: Date | Item | Source (hyperlinked publisher name).
3. **So what — impact on our business** — grouped by customer segment or practice.
4. **Opportunities** — each with the trigger event that creates it.
5. **Threats / watch items** — each with a rough likelihood and what would confirm it.
6. **Recommended actions** — table: Action | Owner | By when | Why now. Owners are
   real named people only where the user supplied them; otherwise write
   `Owner: TBC — to be assigned`.
7. **Sources** — numbered list, full URLs plus publication dates, and internal
   artifacts by exact name and date.

Optional companion: a leadership email body of ≤150 words summarising the top three
points and linking the attachment.

## Recurring overnight runs

Offer to schedule it. Use `host-SetupScheduledPrompt` with a prompt that restates the
watch-list, the window ("since the last run / last 24 hours"), the audience, and the
draft-not-send rule — for example a weekday 06:00 local run. Confirm the user's
timezone first with `outlook_calendar-GetUserDateAndTimeZoneSettings`. Tell the user
how to change or remove it (`host-GetScheduledPrompts`, `host-EditScheduledPrompt`,
`host-DeleteScheduledPrompt`).

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `docx-agent`. That agent cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste for this skill: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)**, **7 (Never)**.
- Do not paraphrase, round or substitute: exact hex values, fonts, point sizes, table banding, status pills and footer rules are executed literally.
- One callout/pull-quote box carries the single most important finding; cover page, navy heading bars and the page-number footer are mandatory.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Section 6 governs its subject line, bottom-line block and en-GB tone.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## Quality bar / verification checklist

- [ ] Every external claim has a URL and a publication date inside the window.
- [ ] No item retained whose date could not be verified on the page itself.
- [ ] No fact stated from pre-training as current news.
- [ ] Internal references cite the exact artifact name and date.
- [ ] Inference is labelled and separated from observation.
- [ ] Numbers, names, quotes and dates are copied, never reconstructed.
- [ ] Gaps are shown explicitly ("no credible source found for X in this window").
- [ ] Nothing was sent: a draft exists, or the user explicitly authorised sending.

## Failure handling

- **Search returns nothing in-window:** say so plainly, list the queries tried, and
  offer to widen the window. Never pad the brief with older material silently.
- **A source is paywalled or unfetchable:** cite the headline and publisher, mark it
  `unverified — could not open`, and do not summarise its content.
- **Internal search returns nothing:** report "no internal signals found" as a gap.
- **Conflicting reports:** present both with sources; do not pick a winner silently.
- **docx-agent fails:** retry once with a simplified brief; if it fails again, return
  the full content in chat so nothing is lost, and say the document was not created.

## Guardrails

- Never auto-send: show the email or Teams text for review before anything leaves.
- If a source, tool or search is unavailable or returns nothing, report the gap and continue; never fabricate to fill it.
- Draft by default; send only on an explicit instruction in the current turn.
- No fabricated names, figures, dates, quotes or URLs — ever. If unsure, omit.
- Do not attribute opinions to named individuals unless quoting a cited source.
- Do not paste large verbatim extracts from copyrighted articles; summarise and link.
- State the analysis is an assessment, not a commitment on behalf of the company.
