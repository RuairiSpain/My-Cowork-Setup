---
name: exec-calendar-defence
description: |
  Audits an executive's calendar against how they say they want to spend their time,
  then acts on it — protecting focus and thinking blocks, finding real slots across
  attendees, booking rooms, consolidating or declining low-value meetings, and
  setting travel cover with automatic replies. Use when the user says "my calendar
  is out of control", "protect my Fridays", "where did my week go", "find time for
  X with these people", "clear space before the board meeting", or "set my out of
  office for the trip".
  Do NOT use for preparing the content of a specific meeting (use board-meeting-prep),
  for team delivery reporting (use manager-weekly-team-pulse), or to judge whether
  a colleague's meeting was worthwhile as a performance matter.
metadata:
  category: executive
  icon: CalendarClock
---

# Executive Calendar Defence

## Purpose

Make an executive's calendar match their stated priorities — with evidence for where the
time actually goes, and concrete actions rather than advice.

## When to Use

- "Where did my week go?" — a time audit against stated priorities.
- Protecting recurring thinking, travel or family blocks.
- Finding a genuinely workable slot across senior diaries, with a room.
- Clearing runway before a board meeting, a launch or leave.
- Setting and clearing travel cover.

## When NOT to Use

- Preparing what goes *into* a meeting — `board-meeting-prep`.
- Reporting on team delivery — `manager-weekly-team-pulse`.
- Any assessment of whether a named person runs good meetings.

## Inputs to Gather

Confirm once and reuse: the executive's stated priorities for the quarter (in their own
words), their protected hours and time zone, the meetings that are untouchable, who may
book over them, and their travel dates.

| Source | Tool |
|---|---|
| The calendar itself | `outlook_calendar-ListCalendarView` (expands recurrences) |
| Time zone / working hours | `outlook_calendar-GetUserDateAndTimeZoneSettings` |
| Real availability across people | `outlook_calendar-FindMeetingTimes` |
| Rooms | `outlook_calendar-GetRooms` |
| Attendee resolution | `me_profile-SearchPeople`, `GetDirectReportsDetails`, `GetOrgTree` |
| Act on events | `CreateEvent`, `UpdateEvent`, `CancelEvent`, `DeclineEvent`, `ForwardEvent` |
| Travel cover | `outlook-SetAutoReply`, `GetAutoReplySettings`, `DisableAutoReply` |

## Workflow

1. **Get the priorities in the executive's own words first.** Everything below is
   measured against them. Without them this is just a meeting list.
2. **Pull the real calendar** for the audit window with `ListCalendarView` so recurring
   series are expanded into actual occurrences. Use the local times the tool returns
   verbatim — never re-derive time zones.
3. **Count only accepted events** for any density claim ("back to back", "sixty per cent
   of your week"). Tentative, declined and unanswered invitations are excluded and the
   exclusion is stated.
4. **Classify every hour** against the stated priorities: *On priority*, *Operational
   necessity*, *Could be delegated*, *Could be an email*, *Recurring with no recent
   decision*. Compute the split with a code tool, never mentally.
5. **Respect privacy in the write-up.** Events marked private or confidential, and
   personal or medical blocks, appear as "Private appointment" with their time only —
   never their subject — unless the executive asked about that event by name.
6. **Propose a small number of concrete moves**, each naming the specific event: protect,
   shorten, delegate, consolidate, decline, or leave alone. Never a generic principle.
7. **Act on the ones agreed.** Use `UpdateEvent` to change an existing meeting — never
   create a replacement and orphan the original. Declining an event the executive
   organises fails; use `CancelEvent` with the right scope instead. Flag any conflict the
   change creates, by name.
8. **Protect the blocks** with real recurring events, titled so colleagues understand
   them ("Strategy block — do not book"), and say who may still book over them.
9. **Set travel cover** with `outlook-SetAutoReply` for the exact dates, naming the
   deputy, and schedule or note how it gets turned off.
10. **Offer the recurring audit** per `Executive/_shared/automation-patterns.md` — e.g. a
    Friday 16:00 prompt that reports next week's split before it is too late to change it.

## Deliverable Spec

**(a) Inline time audit** — the split by category as percentages of accepted hours, the
three biggest drains named by event, and the gap between stated priorities and reality in
two sentences.

**(b) Action list** — one line per proposed move: the event by name, the move, the hours
returned, and its status once actioned (`Done`, `In progress`, `No evidence found`).

**(c) Workbook (only when the audit spans four weeks or more) — brief for `xlsx-agent`:**
Dashboard sheet with hours-by-category KPI cards and a stacked bar by week; Data sheet
with one row per occurrence (subject or `Private appointment`, date, duration, organiser,
category, response status); Evidence sheet naming the calendar window covered.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `xlsx-agent`. That agent cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste: **1 (Palette)**, **2 (Typography)**, **5 (Excel rules)**, **7 (Never)**; apply **6 (Email rules)** to any covering note yourself.
- Meeting-related email — a note to an organiser asking to shorten or delegate — is a DRAFT only (`outlook-CreateDraftMessage`).

## Quality Bar / Verification Checklist

- [ ] The executive's priorities are recorded in their own words and drive the classification
- [ ] Density and percentage claims count accepted events only, and say so
- [ ] Every percentage computed by tool, not mentally
- [ ] Private and personal events shown as time blocks only, never by subject
- [ ] Local times reproduced exactly as the calendar returned them
- [ ] Every proposed move names a specific event
- [ ] Existing meetings changed with `UpdateEvent`, not recreated
- [ ] Any conflict created by a change is surfaced by name
- [ ] Auto-reply has explicit start and end dates and a named deputy

## Failure Handling

- **No stated priorities available:** ask once, briefly. Do not infer priorities from
  meeting titles.
- **`FindMeetingTimes` returns nothing workable:** report the constraint honestly (whose
  diary blocks it), and offer the two least-bad options rather than inventing a slot.
- **No room available:** book the meeting online-only and say the room search failed.
- **Declining an organised event fails:** switch to `CancelEvent` with the correct scope
  and tell the executive what was cancelled.
- **Ambiguous event match:** prefer the closest title match, then the soonest, then the
  one the executive organises — and say which rule was applied.

## Guardrails

- Never accept, decline, cancel or move a meeting that was not explicitly agreed in the
  current turn.
- Never echo the subject of a private, confidential or personal event in a summary.
- Never assess whether a named colleague's meetings are well run — that is performance
  evaluation and is declined.
- Never send a note to an organiser; draft it and let the executive send.
- Never let a scheduled audit change the calendar on its own — it reports, the human acts.
