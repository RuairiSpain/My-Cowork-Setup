---
name: board-metrics-from-powerbi
description: |
  Turns the organisation's Power BI reports and semantic models into a board-ready
  numbers pack — querying the model directly with DAX, honouring Verified Answers,
  reconciling the figures, and producing a short executive deck and a one-page
  numbers annex where every metric names its model, its filter context and its
  as-at date. Use when the user says "get the board numbers out of Power BI",
  "what does the dashboard actually say", "build the metrics pack for the QBR",
  "reconcile these two reports", or pastes an app.powerbi.com report or dataset link.
  Do NOT use to build a Power BI report or model, for metrics that live in a
  spreadsheet rather than a semantic model (use xlsx-agent), or for meeting prep
  generally (use board-meeting-prep).
metadata:
  category: executive
  icon: DataTrending
---

# Board Metrics from Power BI

## Purpose

Let an executive quote a number in a board meeting and be able to say exactly where it
came from, what it was filtered by, and when it was last refreshed.

## When to Use

- Preparing a board, QBR or steering pack whose numbers must come from the warehouse.
- Two reports disagree and someone must say which is right, and why.
- "Just tell me the number" — where the number must be defensible afterwards.

## When NOT to Use

- Authoring or modelling in Power BI — this skill reads, it does not build.
- Metrics that only exist in a workbook or an email — that is `xlsx-agent` territory.
- Whole-meeting preparation, agenda and Q&A — `board-meeting-prep` owns that.

## Inputs to Gather

Confirm once: which report or semantic model is authoritative, the period and
comparison basis (QoQ, YoY, vs plan), the filter context that matters (region, segment,
product), the currency, and who is in the room.

| Need | Tool |
|---|---|
| **Load the `powerbi` skill FIRST** | it carries the tool workflow, DAX rules and Verified-Answers handling |
| Find the artefact | `pbi_fabricaihub-DiscoverArtifacts`, `ResolveReportIdFromUrl` |
| Report structure | `GetReportMetadata` |
| Model schema | `GetSemanticModelSchema` |
| The numbers | `ExecuteQuery` (DAX), `ValueSearch` |
| Internal context around the numbers | `m365_search-SearchM365`, `outlook-ListMessages` |

## Workflow

1. **Invoke the `powerbi` skill before touching any Power BI tool.** Its rules govern
   discovery, schema inspection, DAX and Verified Answers. This skill adds the executive
   packaging on top; it does not replace them.
2. **Fix the authoritative source.** If more than one report could answer, list the
   candidates and confirm which one the board treats as truth. Never average two sources.
3. **Read the schema before writing DAX.** Use the measures the model already defines —
   a measure the business has agreed beats one you invent, every time.
4. **Honour Verified Answers.** Where one exists for a metric, it wins.
5. **Capture the filter context with every figure**: period, region/segment, currency and
   the model's last refresh time. A number without its context is not usable in a board.
6. **Reconcile disagreements explicitly.** Where two reports differ, state both figures,
   name both sources, and explain the difference (different measure, different filter,
   different refresh) — or say plainly that the difference could not be explained.
7. **Compute nothing by hand.** Deltas, percentages and totals come from the model or
   from a code tool, never from mental arithmetic.
8. **Package** as a short deck plus a numbers annex (below), then offer a schedule
   (per `Executive/_shared/automation-patterns.md`) to refresh it before each board.

## Deliverable Spec

**(a) Executive deck — brief for `pptx-agent`.** Six to eight slides:
1. Title slide.
2. "The numbers say …" — one full-sentence conclusion, three KPI cards (big-number
   layout), each with its as-at date.
3–6. One slide per metric family: the trend as a native chart, the conclusion as the
   slide title, at most four supporting lines, source footnote naming model and refresh.
7. Reconciliation — any figure that differs from what the room has seen before, with the
   explanation. Omit only if there genuinely is none.
8. "What we recommend" — three to five lines, each with an owner and a date, or
   `No owner identified` / `No date agreed`.

**(b) Numbers annex — brief for `docx-agent`,** one page: a table of every metric quoted,
with columns Metric, Value, Period, Filter context, Source model / report, Measure name,
Last refresh. This is the page that survives the challenge in the room.

**(c) Inline:** the headline figures, plus an explicit list of metrics that could not be
sourced — `No evidence found` rather than an estimate.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `pptx-agent` and `docx-agent`. Those agents cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)** for the annex, **4 (PowerPoint rules)** for the deck, **7 (Never)**.
- Charts are native chart objects with direct data labels — never images of charts, never a screenshot of a Power BI visual.
- Reference Power BI artefacts by their bracketed alias in chat so the link renders.

## Quality Bar / Verification Checklist

- [ ] The `powerbi` skill was loaded before any Power BI tool was called
- [ ] The authoritative report/model was confirmed, not assumed
- [ ] Every figure carries period, filter context, currency and last-refresh time
- [ ] Model-defined measures used in preference to ad-hoc DAX; Verified Answers honoured
- [ ] Every derived number computed by tool, never mentally
- [ ] Disagreements between sources are stated and explained, or declared unexplained
- [ ] Every slide title is a conclusion, not a topic
- [ ] Metrics that could not be sourced are listed as gaps

## Failure Handling

- **DAX query fails:** simplify to the model's own measure and retry once; if it still
  fails, report the metric as unavailable rather than substituting a similar one.
- **Model not accessible:** name the artefact, say access was refused, and continue with
  the metrics that are reachable.
- **Stale refresh:** quote the figure with its real refresh timestamp and flag the
  staleness in the annex — never present a stale number as current.
- **No Verified Answer and several plausible measures:** show the measure names and ask
  which the board uses, once.

## Guardrails

- Never invent, interpolate or round a figure into something more convenient.
- Never combine figures from two models into one number.
- Never present a chart image in place of a native chart object.
- Never report a metric without its as-at date.
- Never use these figures to evaluate named individuals.
