# Executive Design Standard — reference asset (NOT a skill)

> **This file is a shared reference document, not a triggerable skill.** It has no
> frontmatter and no trigger description, and it must never be loaded or invoked as a
> skill. It is read by the Executive skills (`monday-morning-exec-briefing`,
> `board-meeting-prep`, `investment-research-pack`, `customer-health-review`,
> `overnight-strategy-analyst`, `manager-weekly-team-pulse`, `quarterly-evidence-pack`,
> `onboarding-30-60-90-review`, `org-action-tracker`, `customer-escalation-package`)
> and the relevant section is copied **verbatim** into the brief handed to
> `docx-agent`, `pptx-agent` or `xlsx-agent`, because those agents cannot see this file.

Purpose: every Executive deliverable is shown live to CEOs and CIOs. It must read as
premium consulting output — never default Office. The rules below are prescriptive:
execute them literally, no judgement calls, no substitutions.

---

## 1. Palette (exact hex — use these and nothing else)

| Role | Name | Hex | Use |
|---|---|---|---|
| Primary | Executive Navy | `#132B4D` | Title slides, section dividers, heading bars, table header rows, Excel header bands, chart primary series |
| Primary dark | Navy Deep | `#0B1B33` | Title-slide background, dark fills behind white text |
| Primary light | Navy Mist | `#E8EDF4` | Banded table rows, KPI card fills, subtle panels |
| Text | Warm Graphite | `#2E2E2E` | All body text, table body text |
| Text secondary | Graphite 60% | `#6B6B6B` | Captions, footnotes, source lines, axis labels |
| Accent (emphasis ONLY) | Teal | `#0E7C7B` | One emphasis per page/slide: pull-quote rule, callout border, a single highlighted data point, KPI figure |
| Rule / divider | Light Rule | `#D4D9E0` | Table gridlines, dividers, card borders |
| Page / sheet | White | `#FFFFFF` | Backgrounds |

**Status colours — reserved strictly for status, never decoration:**

| Status | Hex | Fill (pill/cell) | Text on fill |
|---|---|---|---|
| Good / Done / On track | `#1E7B34` | `#E4F1E7` | `#1E7B34` |
| Watch / In progress / At risk | `#B26A00` | `#FBEFDC` | `#B26A00` |
| Bad / Overdue / Off track | `#B3261E` | `#F9E3E1` | `#B3261E` |
| No evidence found / Unknown | `#6B6B6B` | `#EDEDED` | `#6B6B6B` |

Accent teal is emphasis only — it is never a status, never a background wash, and never
appears more than once per slide or twice per document page.

## 2. Typography (Segoe UI family throughout)

| Element | Font | Size | Weight | Colour |
|---|---|---|---|---|
| Slide title | Segoe UI Semibold | 28 pt | Semibold | `#132B4D` (white `#FFFFFF` on navy slides) |
| Slide subtitle / kicker | Segoe UI | 14 pt | Regular | `#6B6B6B` |
| Slide body / bullet | Segoe UI | 18 pt | Regular | `#2E2E2E` |
| Slide "big number" KPI | Segoe UI Semibold | 54 pt | Semibold | `#0E7C7B` |
| Slide source footnote | Segoe UI | 10 pt | Regular | `#6B6B6B` |
| Doc title (cover) | Segoe UI Light | 32 pt | Light | `#132B4D` |
| Doc H1 | Segoe UI Semibold | 18 pt | Semibold | white on `#132B4D` bar |
| Doc H2 | Segoe UI Semibold | 14 pt | Semibold | `#132B4D` |
| Doc H3 | Segoe UI Semibold | 12 pt | Semibold | `#2E2E2E` |
| Doc body | Segoe UI | 11 pt | Regular | `#2E2E2E`, line spacing 1.15, 6 pt after |
| Table header text | Segoe UI Semibold | 10 pt | Bold | `#FFFFFF` |
| Table body text | Segoe UI | 10 pt | Regular | `#2E2E2E` |
| Caption / footer / source note | Segoe UI | 9 pt | Regular | `#6B6B6B` |
| Excel sheet body | Segoe UI | 10 pt | Regular | `#2E2E2E` |

## 3. Word rules (docx-agent)

1. **Cover page**, always: document title (32 pt Light navy); one-line subtitle stating
   the audience (e.g. "Prepared for: the Board"); the date in en-GB long form
   (`24 September 2026`); and the line `Prepared by Copilot Cowork`. Nothing else on it.
2. **Navy heading bar** for every H1: full-width shaded paragraph, fill `#132B4D`,
   white Semibold 18 pt text, 6 pt padding above and below.
3. **Automatic table of contents** on any document longer than three pages, placed
   immediately after the cover, with a page break after it. Under three pages: no TOC.
4. **Tables**: header row fill `#132B4D` with white bold 10 pt text; banded body rows
   alternating `#FFFFFF` / `#E8EDF4`; gridlines `#D4D9E0` 0.5 pt; no vertical borders on
   the outer edge; first column left-aligned, numeric columns right-aligned; repeat the
   header row on page breaks.
5. **Status pills**: a one-cell shaded run with 2 pt padding and rounded appearance,
   text in bold 9 pt, using exactly these four labels and the section 1 status colours —
   `Done`, `In progress`, `No evidence found`, `Overdue`. No other status words.
6. **Callout / pull-quote box** — exactly one per document, carrying the single most
   important finding: full-width box, fill `#E8EDF4`, 3 pt left rule in accent teal
   `#0E7C7B`, text 12 pt Semibold graphite, no quotation marks unless quoting a real
   source verbatim.
7. **Footer** on every page except the cover: `Page X of Y` right-aligned, and a
   left-aligned source note (`Sources: see Sources & gaps`), both 9 pt `#6B6B6B`.
8. **Never**: clip art, stock imagery, gradients, shadows, decorative shapes, icons as
   ornament, coloured page borders, or any font other than Segoe UI.

## 4. PowerPoint rules (pptx-agent)

1. **16:9** (13.333 in × 7.5 in), always.
2. **Every slide title is a full-sentence conclusion, not a topic** — "Renewal risk is
   concentrated in three accounts", not "Renewal risk". Sentence case, no full stop.
3. **Title slide and section dividers**: full-bleed `#0B1B33` background, white Semibold
   title, `#6B6B6B`-free (use `#C9D2DE` for the subtitle on dark), a 3 pt teal rule under
   the title, and `Prepared by Copilot Cowork` plus the en-GB date bottom-left at 10 pt.
4. **Maximum four supporting lines per slide.** No sub-bullets beyond one level. If the
   content needs more, split the slide.
5. **Consistent content grid**: left-aligned text block starting 0.9 in from the left
   edge, top of body at 1.8 in, body width 11.5 in (or 6.8 in when paired with a visual
   on the right, which starts at 7.9 in). Identical on every content slide.
6. **Big-number KPI layout** (available as a layout, use where a single figure carries
   the message): the figure at 54 pt Semibold teal, a 14 pt graphite label above it, and
   one explanatory line of ≤ 12 words at 14 pt `#6B6B6B` below. Up to three KPI blocks
   side by side on one slide, each in a `#E8EDF4` card with a `#D4D9E0` 0.5 pt border.
7. **Charts are native PowerPoint chart objects** — never images of charts. No gridlines
   (or a single `#D4D9E0` horizontal set where a value scale is essential), no chart
   border, no background fill. **Direct data labels on the series**; remove the legend
   whenever a direct label can carry the meaning. Series colours: navy `#132B4D` first,
   `#6B87AD` second, teal `#0E7C7B` only for the point being emphasised.
8. **Source footnote on every slide carrying a figure**: 10 pt `#6B6B6B`, bottom-left,
   naming the artefacts by exact name and date.
9. **Final slide is always "What we recommend"**: three to five recommendations, each one
   line, each with an owner and a date where one is known — and `No owner identified` /
   `No date agreed` where one is not. Never invent either.
10. **Never**: clip art, gradients, shadows, 3-D effects, decorative shapes, emoji,
    transitions, or more than one accent colour on a slide.

## 5. Excel rules (xlsx-agent)

1. **No default grid look.** Turn sheet gridlines off on every sheet; the structure is
   carried by the table formatting, not by Excel's grid.
2. **Header row**: fill `#132B4D`, white bold 10 pt, row height 24, **frozen** (freeze
   panes below the header, and to the right of the label column on wide sheets).
3. **Banded rows** `#FFFFFF` / `#E8EDF4`; borders `#D4D9E0` 0.5 pt horizontal only.
4. **Column widths sized to content** — every column wide enough for its longest value;
   no truncation, no `####`, no wrapped headers.
5. **Explicit number formats**, never General: whole numbers `#,##0`; decimals `#,##0.0`;
   percentages `0.0%` (one decimal place); currency `£#,##0` (or the source currency's own
   symbol — never change currency); dates `dd mmm yyyy`; scores `0.0`.
6. **Conditional formatting**: status cells use the four section 1 status fills with
   matching text colour; risk scores use a three-band rule on the same palette
   (`#F9E3E1` high risk, `#FBEFDC` medium, `#E4F1E7` low) plus a solid-fill navy data bar
   where a ranked score column exists.
7. **Sheet order — Dashboard FIRST**, then Data, then Evidence, then any working sheets:
   - **Dashboard**: KPI cards across the top (each a merged block, `#E8EDF4` fill,
     `#D4D9E0` border, 28 pt Semibold teal figure with a 10 pt graphite label), and two
     or three **native Excel charts** below them — no gridline clutter, direct data
     labels, legend removed where a label will do, navy/teal series only.
   - **Data**: the full row-level table, one row per entity, formatted per rules 2-6.
   - **Evidence**: every source artefact listed by **exact name**, with its date, its
     type (email / meeting transcript / Teams message / document / web page) and the row
     or finding it supports. One artefact per row.
8. **Tab colours by role**: Dashboard `#0E7C7B`, Data `#132B4D`, Evidence `#6B6B6B`,
   working sheets `#D4D9E0` (and hidden where they are not for the audience).
9. **Never**: default blue-white table styles, merged cells inside data ranges, rainbow
   colour scales, 3-D charts, or a chart placed on top of data.

## 6. Email rules

1. **Subject states the conclusion**, not the topic — "Three accounts carry 80% of
   renewal risk — decision needed by Friday", not "Account review".
2. **"Bottom line" block first**: exactly three lines at the top, before anything else —
   what is happening, why it matters, what is being asked for.
3. **Short sections with bold leads** (`**What changed:**`, `**Impact:**`, `**Ask:**`),
   two to four sentences each.
4. **At most one table**, and only when a table genuinely beats prose.
5. **A single, clear ask** — one decision or one action, with the person and the date.
6. **Professional en-GB tone**: en-GB spelling and date format, no exclamation marks, no
   emoji, no filler openers, no hedging where evidence is solid.
7. **Draft only.** Every email is created as a draft (`outlook-CreateDraftMessage`) and
   never sent unless the user explicitly asks in the current turn.

## 7. Never (applies to every artefact, without exception)

- **Never fabricate** a figure, name, quote, date, owner or status. If it is not in the
  evidence, it does not appear.
- **Mark unknowns explicitly** as `No evidence found` / `No owner identified` /
  `No date agreed`, and list them in a Gaps section. An absent fact is a finding.
- **Never use emoji** in an executive artefact — document, slide, workbook or email.
- **Never leave placeholder or lorem text**, `TBD`, `[insert]`, sample rows or template
  scaffolding in a delivered file.
- Never use a font other than Segoe UI, or a colour outside sections 1 and 2.
- Never use clip art, stock photography, gradients, shadows or decorative shapes.
