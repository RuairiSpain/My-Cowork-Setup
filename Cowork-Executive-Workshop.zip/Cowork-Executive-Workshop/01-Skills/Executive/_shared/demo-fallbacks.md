# Demo Fallbacks — reference asset (NOT a skill)

> **This file is a shared reference document, not a triggerable skill.** It has no
> frontmatter and no trigger description. It is read when a skill is being demonstrated
> in a workshop and the attendee's own tenant does not contain the artefact the skill
> normally needs.

Workshop attendees reliably have **mail, calendar, Teams and meeting transcripts**. They
frequently do **not** have a Power BI report they can reach, a spreadsheet worth analysing,
a prior board deck, or a SharePoint list to bind an app to. This file gives each skill a
degradation path that keeps the demo honest.

**The rule that governs all of them:** a fallback is always announced. Say which source was
unavailable and which stand-in was used. A demo that quietly substitutes data teaches
exactly the wrong lesson about the tool.

---

## 1. The workshop demo assets

Two files ship with this pack's workshop materials. Both are **synthetic**: the vendor is
the fictional **Fabrikam**, and the customers use Microsoft's standard fictional names
(Contoso Retail, Northwind Traders, Woodgrove Bank, Adventure Works, Relecloud, Tailspin
Toys, Litware Inc, Proseware, Wide World Importers, Graphic Design Institute). No real
person, customer or figure is represented, and every artefact says so on its face.

| Asset | Contents | Feeds |
|---|---|---|
| `Fabrikam-demo-data.xlsx` | Dashboard · Accounts (10) · Actions (20) · Milestones (18) · Risks & Issues (12) · Financials (360 rows, 24 months × 3 segments × 5 regions) · Raw_Export (deliberately flawed) · Evidence · README | `customer-health-review`, `org-action-tracker`, `project-status-tracker`, `excel-analysis`, `exec-decision-cockpit`, `board-metrics-from-powerbi` |
| `Fabrikam-Q2-FY26-board-pack.pptx` | Last quarter's board pack, dated 26 June 2026, with five open commitments | `board-meeting-prep`, `brand-consistency`, `exec-stakeholder-update`, `cite-your-sources` |

The two are **deliberately consistent with each other**: commitments made in the Q2 deck
appear as open or overdue actions in the workbook, and the Atlas migration slippage shown
on slide 5 is the same slippage the milestones sheet evidences. That consistency is what
lets one demo hand off to the next.

The `Raw_Export` sheet is flawed on purpose — duplicate key, the same customer under two
ids, a blank row, `N/A` in a numeric column, thousands separators inside text, three
different date formats, and inconsistent casing. It is the teaching material for
`excel-analysis`. **Never clean it in the shipped file.**

---

## 2. Fallback by dependency

### Power BI is unavailable

The most common gap, and the one with no local substitute — a semantic model cannot be
created here.

1. **Preferred:** use Microsoft's official public samples. They are real semantic models,
   free, and safe to show:
   - Sample index: `https://learn.microsoft.com/en-us/power-bi/create-reports/sample-datasets`
   - Financial Sample workbook: `https://learn.microsoft.com/en-us/power-bi/create-reports/sample-financial-download`
   - Contoso Sales for Power BI (.pbix): `https://www.microsoft.com/en-us/download/details.aspx?id=46801`
   - Power BI Desktop samples on GitHub: `https://github.com/microsoft/powerbi-desktop-samples`

   Publish one to a workspace before the session. This is the only fallback that
   demonstrates real DAX, a real schema and a real refresh timestamp.
2. **If no workspace is available at all:** `board-metrics-from-powerbi` degrades to the
   `Financials` sheet of `Fabrikam-demo-data.xlsx`, analysed via `excel-analysis`. State
   the degradation explicitly: the skill is designed to query a semantic model, and what
   is being shown is the same discipline applied to a workbook. **Do not pretend a
   workbook is a semantic model.**
3. What is lost in the fallback, and should be said out loud: Verified Answers, the model's
   own agreed measures, and the real last-refresh timestamp. Those are exactly the parts
   that make the board-numbers argument, so name them as the gap.

### No spreadsheet worth analysing

Use `Fabrikam-demo-data.xlsx`. For `excel-analysis`, point at the `Raw_Export` sheet — it
demonstrates the profile-and-error-hunt path far better than clean data would.

### No prior board deck or meeting pack

Use `Fabrikam-Q2-FY26-board-pack.pptx` as the prior-quarter artefact. For
`board-meeting-prep`, treat its slide 9 commitments table as the previous meeting's
commitments and chase them against the workbook's Actions sheet.

### No SharePoint list or system of record to bind an app to

For `exec-decision-cockpit`:
1. **Preferred:** upload the `Accounts` or `Actions` sheet of the demo workbook to a
   SharePoint list first, then bind the app to that list — this demonstrates the real
   binding path end to end.
2. **Fallback:** bind directly to the workbook on OneDrive.
3. **Last resort:** build against the demo data and label the app, on its face, as demo
   data. Never leave a demo app looking like live production data.

### No meeting transcript in range

Transcripts are retained for roughly 60 days, so an older meeting simply will not be there.
Use a recent recurring meeting the attendee organised, or fall back to the Teams channel
and email evidence for the same meeting — and say that transcript coverage was the gap.
This is a genuinely good teaching moment: it is the honest-gaps behaviour, live.

### No Power Platform connector or permission to create one

`exec-decision-cockpit` and `integrate-me` both degrade to designing the integration and
naming the connector that would be used, without creating the connection. State clearly
that the connection was not made.

### Browser demo: no suitable authenticated site

`exec-live-web-desk` should never be demonstrated against an attendee's real bank, payment
or HR account. Use a public site with a live lookup (a carrier's parcel tracking page, a
public regulator register, a restaurant booking page taken up to — **but not through** —
the confirmation step). Stop before any irreversible action.

### Audio generation unavailable

`exec-audio-briefing` delivers the script alone. Read the first 30 seconds aloud from the
script — the structure is the point, and it survives the loss of the audio.

---

## 3. What a fallback must never do

- **Never present synthetic data as the attendee's own.** Every demo artefact says
  "synthetic demo data" on its face, and the presenter says it too.
- **Never fabricate a figure to make a demo land.** If the skill finds nothing, showing
  `No evidence found` is a better demo than a fabricated number — it is the single most
  important behaviour in the whole pack.
- **Never clean the `Raw_Export` sheet** in the shipped file.
- **Never demonstrate a skill against a real named individual's performance**, even with
  demo data in the room.
- **Never leave a demo automation installed** in an attendee's tenant at the end of the
  session. Show `host-GetScheduledPrompts` / `host-GetEventTriggers` and remove what was
  created — the removal is part of the demo.
