---
name: customer-health-review
description: |
  Reviews a portfolio of customer accounts by gathering engagement signals from email, Teams, meeting cadence and documents, scoring each account on engagement recency, escalation volume, sentiment and open commitments, then producing an advanced Excel workbook with a formula-driven dashboard, charts, per-account data and an evidence sheet, plus an inline summary of the top five at-risk accounts. Use when the user says "review our top customers and identify risks", "account health review", "which accounts are at risk", "customer health check", or asks to score or rank accounts by risk. Do NOT use for a single meeting's preparation (use board-meeting-prep), for the weekly executive briefing (use monday-morning-exec-briefing), or for research on a company we do not yet work with (use investment-research-pack).
metadata:
  category: executive
  icon: HeartPulse
---

# Customer Health Review

## PURPOSE

Turn scattered relationship signals into a ranked, evidence-backed view of which accounts are at risk and why. The deliverable is an **advanced Excel workbook** built by the **xlsx-agent** — formula-driven, charted, and traceable row by row to the message, meeting or document it came from.

## WHEN TO USE

- "Review our top customers and identify risks", "account health review", "which accounts are at risk".
- Before a portfolio review, QBR cycle, or after a quarter with several escalations.

## WHEN NOT TO USE

- Preparing one meeting → `board-meeting-prep`.
- Weekly situational awareness → `monday-morning-exec-briefing`.
- A company we do not yet work with → `investment-research-pack`.

## INPUTS TO GATHER

Establish the account list first: ask the user, or derive it from the most-corresponded external domains in the window and confirm the list before scoring. Default window: last 90 days, stated explicitly in the workbook.

| Signal | Tool | Use |
|---|---|---|
| Time zone | `outlook_calendar-GetUserDateAndTimeZoneSettings` | Window boundaries |
| Email per account | `outlook-ListMessages`, `m365_search-SearchM365` | Volume, recency, direction, escalation language |
| Teams per account | `m365_teams-ListChatMessages`, `m365_teams-ListChannelMessages` | Working-level tone and asks |
| Meeting cadence | `outlook_calendar-ListCalendarView` | Count and recency of meetings with the account's domain |
| Documents | `sharepoint_onedrive-SearchDrive` | Proposals, architecture docs, status reports and their last-modified dates |
| Contacts | `me_profile-SearchPeople` | Resolve who belongs to which account |

Evidence rule: every signal row keeps the exact artefact name, date, and a link where one exists.

## SCORING MODEL

Four components, 0-25 each, summing to a 0-100 health score (higher is healthier). Risk score = 100 − health. Definitions, thresholds and the sentiment rubric are in [references/scoring-model.md](references/scoring-model.md).

1. **Engagement recency** — days since the last meaningful two-way interaction.
2. **Escalation volume** — count and severity of escalations in the window.
3. **Sentiment of recent communications** — conservative rubric over the most recent 10 messages per account.
4. **Open commitments** — commitments we made that are open or overdue.

Bands: Healthy ≥75 · Monitor 55-74 · At risk 35-54 · Critical <35. All arithmetic lives in Excel formulas, never as typed constants.

## WORKFLOW

1. **Agree the account list and window.** Confirm both with the user before gathering.
2. **Gather per account** across email, Teams, calendar and files. Keep every evidence row: account, date, source type, exact artefact name, who, one-line extract, signal category, link.
3. **Derive the component inputs** per account: last interaction date, message counts by month, escalation count and severity, sentiment ratings for the last ten messages, open and overdue commitments with due dates.
4. **Check the evidence** — an account with too little data is marked *Insufficient data*, not scored low. This distinction is mandatory.
5. **Delegate the workbook** to the xlsx-agent with the brief below, supplying the data as clean tables.
6. **Verify the workbook** — recalculated values, charts render, conditional formatting applied, no hard-coded totals.
7. **Write the inline executive summary** — the top five at-risk accounts, one paragraph each: score, the two or three drivers, the evidence by exact name, and the recommended next action with an owner.

## DELIVERABLE SPEC — brief for xlsx-agent

Delegate; never hand-author the workbook. **All totals, scores, rankings and KPI cells must be formulas** referencing the Data and Signals sheets.

- **File name:** `Customer Health Review - <YYYY-MM-DD>.xlsx`

**Sheet 1 — Dashboard**
- Title block: review date, window covered, number of accounts, data sources used.
- KPI cells (formulas): accounts reviewed; accounts at risk or critical; total open escalations; total overdue commitments; mean health score; accounts with no contact in 30+ days.
- Ranked risk table, sorted by risk score descending: Account | Health score | Risk band | Engagement recency | Escalations | Sentiment | Open commitments | Last interaction | Top driver. Every numeric column references Data.
- Conditional formatting: colour bands on the health score (green ≥75, amber 55-74, orange 35-54, red <35) and a data bar on risk score.
- **Bar chart:** risk score by account, sorted descending.
- **Line chart:** engagement volume per month per account (interaction count by month) over the window.

**Sheet 2 — Data (one row per account)**
- Account | Domain | Owner | Window start | Window end | Last interaction date | Days since last interaction | Email count | Teams message count | Meeting count | Escalation count | Escalation severity (max) | Sentiment score | Open commitments | Overdue commitments | Component scores (four columns, each a formula) | Health score (formula summing components) | Risk score (formula) | Risk band (formula) | Data sufficiency flag.

**Sheet 3 — Signals (raw evidence)**
- Date | Account | Source type (Email/Teams/Meeting/Document) | Exact artefact name | Person | Extract (one line) | Signal category (Escalation/Commitment/Sentiment/Engagement) | Severity | Link.
- Filterable header row, frozen panes; the Data sheet's counts aggregate from this sheet with COUNTIFS/SUMIFS.

**Style:** clean executive formatting, frozen header rows, column widths set, dates in ISO format, no merged cells in data ranges, en-GB.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `xlsx-agent`. That agent cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste for this skill: **1 (Palette)**, **2 (Typography)**, **5 (Excel rules)**, **7 (Never)**.
- Do not paraphrase, round or substitute: exact hex values, fonts, number formats, conditional-formatting bands and tab colours are executed literally.
- Sheet order is Dashboard first (KPI cards + 2-3 native charts), then Data, then Evidence listing every source artefact by exact name; gridlines off, header row frozen and navy, rows banded, columns sized to content.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Section 6 governs its subject line, bottom-line block and en-GB tone.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## QUALITY BAR / VERIFICATION CHECKLIST

- [ ] Every score, total and KPI is a formula; no hard-coded totals anywhere.
- [ ] Every Signals row cites an exact artefact name and date; no invented quotes or figures.
- [ ] Dashboard ranking, bands and colours agree with the computed Data values.
- [ ] Both charts exist, are populated and are correctly labelled with axis titles.
- [ ] Accounts with thin evidence are flagged *Insufficient data*, not scored as at risk.
- [ ] Sentiment ratings are traceable to the specific messages rated.
- [ ] The inline summary names exactly five accounts (or fewer, with the reason stated) and each cites its evidence.
- [ ] The workbook opens, recalculates, and the reported path is correct.

## FAILURE HANDLING

- **No account list available** → derive candidates from external domain frequency, show the derived list, and get confirmation before scoring.
- **Thin data for an account** → mark *Insufficient data*; never let silence masquerade as either health or risk.
- **Sentiment is ambiguous** → rate neutral and record the ambiguity in the Signals extract; never infer emotion from tone alone.
- **A source is unavailable** → list it in the Dashboard sources block as not covered, and note the effect on scores.
- **xlsx-agent fails** → retry once with a reduced brief (Dashboard + Data first, charts second); if it fails again, deliver the ranked table inline as markdown and state clearly that the workbook was not created.
- **Sensitive personal content in a signal** → summarise neutrally, do not quote.

## GUARDRAILS

- Read-only over the user's data; no mail sent, no Teams post, no calendar change.
- No fabricated names, numbers, dates or quotes; gaps are marked explicitly.
- Scores are a prioritisation aid, not a judgement of people — never rank individuals, only accounts.
- Office files always come from the xlsx-agent, never hand-authored.
