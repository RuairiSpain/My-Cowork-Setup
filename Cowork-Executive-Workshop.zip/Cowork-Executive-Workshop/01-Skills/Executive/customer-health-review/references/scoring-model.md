# Customer Health Scoring Model

Four components, each scored 0-25. Health score = sum (0-100). Risk score = 100 − health.
Every component must be computed in Excel formulas on the Data sheet, referencing counts
aggregated from the Signals sheet. Never type a score as a constant.

## 1. Engagement recency (0-25)

Based on days since the last meaningful two-way interaction (a reply, a meeting attended, a
document exchanged — not a newsletter or an automated notification).

| Days since last interaction | Score |
|---|---|
| 0-7 | 25 |
| 8-14 | 20 |
| 15-30 | 15 |
| 31-60 | 8 |
| 61-90 | 3 |
| >90 or none in window | 0 |

## 2. Escalation volume (0-25)

Count escalations in the window and take the maximum severity.

| Escalations in window | Score |
|---|---|
| 0 | 25 |
| 1 low/medium | 18 |
| 1 high, or 2 low/medium | 12 |
| 2-3 with any high | 6 |
| 4+ , or any unresolved critical | 0 |

Severity guide: **Low** = routine complaint resolved in-thread · **Medium** = issue raised to the
account team with a deadline · **High** = raised above the working level, contractual, financial or
delivery-date impact · **Critical** = executive escalation, threat to renewal, or a live outage.

## 3. Sentiment of recent communications (0-25)

Rate the most recent ten inbound messages per account on a conservative three-point scale, then
map the average. Rate the **explicit content** only; never infer emotion from brevity or tone.

- Positive (+1): explicit thanks, approval, expansion intent, praise.
- Neutral (0): factual, transactional, or ambiguous.
- Negative (−1): explicit dissatisfaction, complaint, chasing, contractual pushback, frustration.

| Average rating | Score |
|---|---|
| ≥ +0.5 | 25 |
| +0.1 to +0.49 | 20 |
| −0.1 to +0.1 | 15 |
| −0.11 to −0.49 | 7 |
| ≤ −0.5 | 0 |

Fewer than three ratable messages → sentiment is **not scored**; set the account's data
sufficiency flag and exclude sentiment from the total, scaling the remaining three components
(health = sum of available components ÷ available maximum × 100).

## 4. Open commitments (0-25)

Commitments **we** made to the account and have not evidenced as complete.

| Open / overdue | Score |
|---|---|
| 0 open | 25 |
| 1-2 open, none overdue | 18 |
| 3+ open, none overdue | 12 |
| 1 overdue | 8 |
| 2+ overdue | 0 |

## Bands

| Health score | Band | Dashboard colour |
|---|---|---|
| ≥ 75 | Healthy | Green |
| 55-74 | Monitor | Amber |
| 35-54 | At risk | Orange |
| < 35 | Critical | Red |

## Data sufficiency

An account with fewer than five evidence rows in the window is marked **Insufficient data** and is
excluded from the ranked risk table's at-risk counts, listed separately instead. Absence of
evidence is not evidence of risk — and it is not evidence of health either.
