---
name: customer-escalation-package
description: |
  Builds a complete, evidence-cited customer escalation package for a SEV1/major
  incident: a Word incident report, a 6-slide executive deck, an Excel action
  tracker and a customer email DRAFT. Use when the user asks to "prepare the
  executive update for the SEV1", "build the escalation package", "customer
  escalation update", "put together the incident report for <customer>", or
  "we need an exec brief on this outage". Reconstructs the timeline from email,
  Teams and meeting transcripts, every entry timestamped and source-cited.
  Do NOT use for routine status reports or project updates (use the normal
  reporting flow), for a single escalation question needing one decision (use
  escalate-one-question), or for authoring engineering post-mortems with root
  cause analysis the sources do not support.
metadata:
  category: communication
  icon: Warning
---

## Purpose

Turn scattered incident evidence — mail threads, Teams chats and channels, meeting
transcripts — into one defensible escalation package for a customer and for internal
leadership. Everything is grounded: if a source does not say it, the package does not
claim it.

## When to Use

- A SEV1/SEV2 or major customer escalation needs an executive update
- Leadership asks for "the full package" — report, deck, actions, customer comms
- An ongoing incident needs a refreshed timeline and action status

## When NOT to Use

- Routine weekly status or project reporting — no incident, no package
- A single blocked decision — use `escalate-one-question`
- Deep engineering RCA where the evidence is in telemetry, not M365 artefacts
- Anything the user wants sent immediately without review — this skill drafts only

## Inputs to Gather

Ask once for: customer name, incident/ticket ID, severity, incident start time and
the user's time zone. Then collect evidence with:

| Source | Tool |
|---|---|
| Mail threads | `outlook-ListMessages`, `outlook-GetMessage` |
| Cross-workload search | `m365_search-SearchM365` (ticket ID, customer name) |
| Teams channels | `m365_teams-ListChannels`, `m365_teams-ListChannelMessages` |
| Teams chats | `m365_teams-ListChats`, `m365_teams-ListChatMessages` |
| Meeting transcripts | `graph-ListMeetingTranscripts`, `graph-GetMeetingTranscript` |
| Attached evidence | `sharepoint_onedrive-SearchDrive`, `ReadFileContent` |

Time-box the sweep to the incident window plus 24h either side.

## Workflow

1. **Scope.** Confirm customer, incident ID, severity, window and audience
   (customer-facing vs internal-only). If the incident ID is unknown, search on
   customer name and severity keywords and confirm the match with the user.
2. **Sweep evidence.** Run the tools above in parallel. Record for every item:
   exact artefact name (subject line / channel + message time / meeting title),
   author, and UTC + local timestamp.
3. **Build the timeline.** One row per material event: `timestamp | event |
   source`. Merge duplicates across workloads; keep the earliest attestation.
   Never infer an event that no source records.
4. **Classify impact.** Affected customer, services, users, duration, business
   impact — only as stated in sources. Anything unstated goes to Open Questions.
5. **Root cause / current understanding.** State what sources assert, labelled
   `Confirmed` or `Working hypothesis (per <source>)`. No speculation beyond that.
6. **Extract actions.** Owner, action, due date, status — from sources only.
   Unknown owner = `unassigned`; unknown date = `no date found`.
7. **Produce the four deliverables** via the agents below, in this order:
   report → deck → tracker → comms draft.
8. **Review gate.** Show the customer email draft text and the internal Teams
   update text in chat for approval. Do not send or post unless the user
   explicitly says "send" or "post".

## Deliverable Spec

Delegate every file — never hand-author Office documents.

**(a) Word incident report — `docx-agent`.** Brief it with the full grounded content
and these sections: Executive Summary (≤150 words), Timeline (table:
timestamp / event / source), Impact, Root Cause or Current Understanding,
Mitigations (done and in-flight), Next Steps, Open Questions. Ask for a styled
professional layout, heading hierarchy, customer + incident ID in the header, and
a "Sources" appendix listing every cited artefact by exact name.

**(b) Executive deck — `pptx-agent`.** Max 6 slides, one headline sentence per
slide: Situation & status (RAG), Timeline, Impact, What we have done, What happens
next, Asks/decisions. The timeline must be built as **real shapes and real text on
the slide, not a generated image**. RAG status shown as a coloured indicator with
a stated definition.

**(c) Excel action tracker — `xlsx-agent`.** Columns: ID, action, owner, source,
due date, status, RAG, last update. Conditional formatting on RAG and overdue
dates; a separate data sheet with open-actions-by-date and a burndown/time-series
line chart of open actions. Freeze panes, autofilter.

**(d) Customer communication — `outlook-CreateDraftMessage`.** A DRAFT only, to the
distribution the user names. Factual, no blame, no speculative cause, clear next
update time. Attach the Word report via `outlook-AddDraftAttachments` when the user
wants it attached. Internal Teams update: compose the text and show it for
approval; post with `m365_teams-PostChannelMessage` only on explicit instruction.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `docx-agent`, `pptx-agent` and `xlsx-agent`. Those agents cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)** for the incident report, **4 (PowerPoint rules)** for the deck, **5 (Excel rules)** for the action tracker, **7 (Never)**; apply **6 (Email rules)** to the customer email yourself.
- Do not paraphrase, round or substitute: exact hex values, fonts, point sizes, number formats and conditional-formatting bands are executed literally.
- Status colours are reserved for status only; every timeline entry stays timestamped and source-cited, and the deck ends on the "What we recommend" pattern.
- **The customer email is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## Quality Bar / Verification Checklist

- [ ] Every timeline row has a timestamp **and** a named source artefact
- [ ] No named individual is blamed; describe systems and teams, not people
- [ ] No root cause stated beyond what sources support; hypotheses labelled
- [ ] Gaps appear as "Open Questions", never as filled-in guesses
- [ ] No invented names, numbers, dates or quotes anywhere
- [ ] All four deliverables exist and are cross-consistent (same timeline, same actions)
- [ ] Customer email is a DRAFT; Teams update shown, not posted
- [ ] Deck ≤6 slides; timeline is shapes, not a picture
- [ ] Tracker chart renders and conditional formatting applied
- [ ] en-GB spelling and date format (DD Month YYYY)

## Failure Handling

- **Thin evidence:** say so plainly, produce the package with an explicit
  "Evidence gaps" section, and list what to retrieve next. Do not pad.
- **No transcripts available:** note that meeting evidence is missing and rely on
  mail/Teams; flag the limitation in the report.
- **Conflicting sources:** show both, attribute each, and raise it as an open question.
- **Tool/permission failure:** name the tool and source that could not be read and
  continue with what is available, marking the gap.
- **User asks to send immediately:** confirm the recipient list and the exact text
  once, then send; otherwise the default stays DRAFT.

## Guardrails

- Never send customer communication or post to Teams without explicit instruction.
- Never attribute fault to a named individual.
- Never state a root cause, customer impact figure or date that no source contains.
- Never hand-author .docx/.pptx/.xlsx — always delegate to the agent skills.
