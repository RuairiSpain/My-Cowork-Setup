---
name: onboarding-30-60-90-review
description: |
  Tracks a new joiner's ramp against 30/60/90-day milestones using meetings attended,
  artifacts produced, open commitments and enablement signals, and produces a styled
  Word manager report plus an Excel milestone tracker with a progress chart. Use when
  the user asks to "prepare an onboarding progress report for <name>", "30/60/90
  review", "how is the new joiner tracking", or "onboarding status for <name>".
  Readiness and ramp EVIDENCE only — never a performance rating, and absent evidence
  is reported as "no evidence found". Do NOT use for the performance cycle (use
  quarterly-evidence-pack) or weekly team status (use manager-weekly-team-pulse).
metadata:
  category: productivity
  icon: PersonAdd
---

## Purpose

Give a manager a factual view of how a new joiner is ramping: which onboarding
milestones have observable evidence behind them, where the gaps are, and what to focus
the next 30 days on. Evidence of ramp, not a verdict on the person.

## When to use

- A 30, 60 or 90-day checkpoint for a new team member.
- Preparing a manager's onboarding conversation.
- Checking whether enablement and connections are happening as planned.

## When NOT to use

- Performance-cycle evidence — use `quarterly-evidence-pack`.
- Weekly team delivery — use `manager-weekly-team-pulse`.
- Any request for a rating, a hire/no-hire signal or a probation recommendation.

## Inputs to gather

| Source | Tool | What to extract |
|---|---|---|
| Person | `me_profile-SearchPeople`, `me_profile-GetUserDetails` | Exact identity, role, manager |
| Team | `me_profile-GetDirectReportsDetails`, `me_profile-GetOrgTree` | Who they should be connecting with |
| Start date | earliest artifact across mail/calendar/Teams, or ask the user | Anchors every milestone window |
| Meetings | `outlook_calendar-ListCalendarView` | Onboarding sessions, 1:1 cadence, customer exposure |
| Transcripts | `graph-ListMeetingTranscripts`, `graph-GetMeetingTranscript` | Confirmed participation or ownership, where available |
| Mail | `outlook-ListMessages` | Commitments, introductions, enablement confirmations |
| Teams | `m365_teams-ListChatMessages`, `m365_teams-ListChannelMessages` | Channel joins, questions asked and answered |
| Files | `sharepoint_onedrive-SearchDrive`, `m365_search-SearchM365` | Documents and artifacts they produced |

## Workflow

1. **Resolve the person** with `me_profile-SearchPeople`. If more than one match, ask.
2. **Establish the start date.** Ask the user first; if they do not know, infer from
   the earliest observed artifact and **label it as inferred** in the report.
3. **Define the three windows** — days 1–30, 31–60, 61–90 from the start date — and
   state the calendar dates for each.
4. **Collect evidence per window:** meetings attended and their cadence (1:1s with the
   manager, team rituals, customer sessions), artifacts produced, commitments opened
   and closed, training or certification signals visible in mail and Teams.
5. **Map evidence to milestones.** Use the user's onboarding plan if they supply one;
   otherwise use the default ladder in `reference.md` and say which was used.
6. **Status each milestone** as exactly one of: **On track** (evidence found) ·
   **Needs attention** (partial or late evidence) · **No evidence found** (nothing
   retrievable — a data statement, not a judgement). Every status cites its artifact.
7. **Derive next-30-day focus areas** from gaps in evidence, phrased as suggested
   manager actions (e.g. "arrange an introduction to the partner team"), never as
   corrections to the person.
8. **Build the tracker** via `xlsx-agent`, then the **report** via `docx-agent`.
9. **Present in chat:** milestone counts by status, the inferred-vs-confirmed start
   date, and the gaps.

## Deliverable spec

**Excel — brief to `xlsx-agent`:** `Onboarding Tracker — <Name>.xlsx`
- `Milestones` — Phase (30/60/90) | Milestone | Status | Evidence (artifact + date) |
  Date evidenced | Owner, with conditional formatting on Status.
- `Progress` — a chart of milestones evidenced per phase (target vs evidenced),
  driven by formulas (e.g. `COUNTIFS`) over `Milestones`.
- `Summary` — KPI cells: total milestones, % with evidence, count "No evidence found",
  days elapsed since start — all formulas, no pasted constants.

**Word — brief to `docx-agent`:** `Onboarding Progress — <Name>, day <n>`, styled with
headings and tables:
1. Header: name, role, start date (marked *confirmed* or *inferred*), reporting date,
   and the line *"Ramp evidence only. This is not a performance assessment."*
2. **Status at a glance** — milestone table with the three statuses.
3. **30 / 60 / 90 sections** — per phase: what evidence exists, cited by exact artifact
   name and date.
4. **Ramp highlights** — factual: artifacts produced, sessions led, connections made.
5. **Gaps** — milestones with no evidence, stated neutrally with what would evidence
   them.
6. **Suggested focus for the next 30 days** — manager actions and enablement, not
   criticism.
7. **Evidence index** — every artifact cited, with name, date, source and link.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `docx-agent` and `xlsx-agent`. Those agents cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)** for the report, **5 (Excel rules)** for the tracker, **7 (Never)**.
- Do not paraphrase, round or substitute: exact hex values, fonts, point sizes, number formats and conditional-formatting bands are executed literally.
- Milestone status uses only the four standard labels — `Done`, `In progress`, `No evidence found`, `Overdue` — in the status colours; the tracker leads with a Dashboard sheet and its progress chart.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Section 6 governs its subject line, bottom-line block and en-GB tone.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## Quality bar / verification checklist

- [ ] Person resolved to a real identity; ambiguity queried.
- [ ] Start date confirmed by the user, or clearly labelled inferred.
- [ ] Phase windows stated as calendar dates.
- [ ] Every milestone status cites an artifact name and date, or says "no evidence found".
- [ ] No rating, score, comparison to peers, or probation/retention language.
- [ ] No adjectives of quality about the person.
- [ ] Excel KPIs and chart are formula-driven.
- [ ] Absence of evidence never phrased as failure, delay-by-fault or concern.

## Failure handling

- **Start date unknown and uninferable:** ask once; if still unknown, produce the
  report on elapsed-time-unknown basis and mark every phase boundary as provisional.
- **Person not found:** ask for the UPN or full name; never guess.
- **Source inaccessible:** mark affected milestones "no evidence found — <source> not
  accessible", which is a data limitation, not a status about the person.
- **Rating or probation judgement requested:** decline in one sentence and state that
  the assessment belongs to the manager and HR; offer the evidence view.
- **xlsx-agent / docx-agent fails:** retry once with a reduced spec; otherwise return
  the tables in chat and say clearly that the file was not created.

## Guardrails

- Never auto-send or post the report; show it for review before sharing.
- If the start date, a source or an artifact is missing or cannot be verified, say so explicitly; never fabricate a milestone or a date.
- Ramp and readiness evidence only — never a performance rating or a recommendation
  about employment.
- Never infer from, or reference, protected characteristics or personal circumstances.
- "No evidence found" is always a statement about the data, never about the person.
- No fabricated names, numbers, dates or quotes.
- Do not send or share the report; produce it for the requesting manager only unless
  explicitly instructed otherwise in the current turn.

See `reference.md` for the default milestone ladder and the status rubric.
