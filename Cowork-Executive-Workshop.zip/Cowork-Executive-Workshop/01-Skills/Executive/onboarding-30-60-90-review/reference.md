# Default 30/60/90 milestone ladder and status rubric

Use this only when the manager does not supply their own onboarding plan, and say in
the report which plan was used. Milestones are evidence targets, not obligations on
the new joiner.

## Days 1–30 — Orientation and access

| Milestone | What counts as evidence |
|---|---|
| Access and tooling in place | Mail/Teams activity, files created in the team's workspace |
| Manager 1:1 cadence established | Two or more recurring 1:1 events in the calendar |
| Team introductions | Meetings with named team members; Teams channel membership |
| Core onboarding / compliance enablement | Confirmation mails, training completion notices |
| Understanding of the patch | Notes, summaries or questions posted in team channels |

## Days 31–60 — Contribution begins

| Milestone | What counts as evidence |
|---|---|
| First owned deliverable | A document, deck or work item authored by the person |
| Customer or stakeholder exposure | Attendance at an external or cross-team session |
| Working cadence with the team | Regular participation in team rituals |
| Commitments taken and tracked | Commitments visible in mail or Teams with a due date |
| Role-specific enablement | Certification, lab or training signals |

## Days 61–90 — Independent delivery

| Milestone | What counts as evidence |
|---|---|
| Leads a session or workstream | Organiser of a meeting, or named owner in an artifact |
| Delivers an outcome end to end | Artifact plus a confirming message or transcript line |
| Broader network established | Threads or meetings with people outside the immediate team |
| Commitments closed | Evidence of completion, cited by artifact |
| Contributes back | Documentation, reusable asset or knowledge shared |

## Status rubric

- **On track** — at least one artifact, dated inside the phase window, directly
  evidences the milestone.
- **Needs attention** — partial evidence, or evidence dated after the phase window
  closed. State exactly what is partial.
- **No evidence found** — nothing retrievable. This is a statement about the data
  only. Never write it as "not done", "behind", "failed" or "a concern".

## Phrasing rules

- Describe artifacts and dates; do not characterise the person.
- Suggested focus areas are manager or enablement actions
  ("schedule an introduction to the partner team", "confirm lab access"),
  not instructions to the new joiner to improve.
- If the manager's own plan is supplied, mirror its milestone names exactly so the
  report lines up with their expectations.
