---
name: quarterly-evidence-pack
description: |
  Gathers factual, source-cited contribution evidence for named direct reports from
  mail, Teams, files and meetings, and produces one styled Word evidence pack per
  person with a blank Manager's Assessment section. Use when the user asks to
  "prepare review notes for my direct reports", "gather evidence for the performance
  cycle", "Connect / quarterly evidence pack", or "what did <name> deliver this
  quarter". EVIDENCE ONLY — it never rates, scores, ranks or compares people and
  declines any such request. Do NOT use for weekly delivery status (use
  manager-weekly-team-pulse) or new-joiner ramp (use onboarding-30-60-90-review).
metadata:
  category: productivity
  icon: DocumentBulletList
---

## Purpose

Collect what a person **verifiably did** in a period — projects shipped, documents
authored, meetings led, commitments completed, customer outcomes — each item citing
the artifact that proves it, so the manager can write their own assessment on solid
ground. Cowork gathers evidence. The judgement is the manager's and HR's.

## THE HARD RULE — read first

**Cowork gathers EVIDENCE ONLY.**

- It must never rate, score, rank, grade, compare or judge an employee's performance,
  competence, potential, attitude or impact level.
- It must never infer or reference anything connected to protected characteristics
  (age, sex, race, religion, disability, health, pregnancy, family status, sexual
  orientation, nationality, union membership, political opinion) — neither directly
  nor through proxies such as leave patterns or working hours.
- If the user asks for a rating, a ranking, a stack, a comparison between people, or
  a "who is strongest", **decline in one sentence**: that judgement belongs to the
  manager and HR. Then offer the factual pack for each person instead.
- **Evidence is factual and verifiable, or it is omitted.** No inference, no
  characterisation, no adjectives of quality.

## When to use

- Performance-cycle preparation for named direct reports.
- A quarterly or half-year contribution summary for one person.
- Reconstructing what was delivered before a promotion or role discussion.

## When NOT to use

- Weekly team status — use `manager-weekly-team-pulse`.
- New-joiner ramp — use `onboarding-30-60-90-review`.
- Anything requiring an opinion about a person.

## Inputs to gather

| Source | Tool | What to extract |
|---|---|---|
| Roster | `me_profile-GetDirectReportsDetails` | Confirm who reports to the user |
| Person | `me_profile-SearchPeople`, `me_profile-GetUserDetails` | Resolve exact identity and UPN |
| Mail | `outlook-ListMessages`, `outlook-GetMessage` | Commitments made and confirmed complete, customer outcomes |
| Teams | `m365_teams-ListChannelMessages`, `m365_teams-ListChatMessages` | Work shared, questions answered, threads led |
| Files | `sharepoint_onedrive-SearchDrive`, `m365_search-SearchM365` | Documents authored or substantially edited, with dates |
| Meetings | `outlook_calendar-ListCalendarView` | Sessions organised or presented |
| Transcripts | `graph-ListMeetingTranscripts`, `graph-GetMeetingTranscript` | Confirmed ownership of an action, where available |

Window: the review period the user names. If unstated, ask once — do not assume.

## Workflow

1. **Confirm scope:** the exact people and the exact period. Verify each person with
   `me_profile-SearchPeople`; if two people match, ask rather than guess.
2. **Collect per person, per source.** For every candidate item record: what happened
   · date · exact artifact name (subject line, file name, meeting title) · link if
   available · source system.
3. **Filter to evidence.** Keep only items where the artifact itself shows the person
   did the thing. Drop hearsay, drop anything where the person is merely a recipient
   or an attendee with no contribution visible.
4. **Classify** each item: Contribution · Completed commitment · Collaboration ·
   Customer outcome.
5. **Deduplicate** — one deliverable discussed in five mails is one item with the
   strongest artifact cited.
6. **List gaps explicitly.** Where a source was inaccessible or empty, record
   "no evidence found in <source> for <period>" — never a negative inference.
7. **Build one pack per person** via `docx-agent` (spec below). One file per person;
   never combine two people in one document.
8. **Hand over.** In chat, state the item counts per section and the gaps. Do not
   summarise the person; summarise the evidence.

## Deliverable spec

Brief to `docx-agent` — one styled Word document per person, file name
`Evidence Pack — <Name> — <period>.docx`, professional styling, headings and tables:

1. **Header** — Name, role, period covered, date generated, and the standing line:
   *"Factual evidence gathered by Cowork. No assessment, rating or comparison is made
   or implied. The assessment is the manager's."*
2. **Contributions** — table: Date | What was delivered | Evidence (exact artifact
   name) | Source. Factual verbs only.
3. **Completed commitments** — table: Commitment | Where it was made (artifact + date)
   | Where completion is shown (artifact + date).
4. **Collaboration footprint** — meetings led or presented, cross-team threads owned,
   documents co-authored; each with artifact name and date. Counts, not judgements.
5. **Customer outcomes** — only where an artifact records the outcome; quote the
   artifact rather than paraphrasing the result.
6. **Gaps** — sources checked that returned nothing, stated neutrally.
7. **Evidence index** — every cited artifact, with exact name, date, source and link.
8. **Manager's assessment** — heading plus a visibly empty ruled section labelled
   *"To be completed by the manager. Cowork does not assess performance."*

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `docx-agent`. That agent cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste for this skill: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)**, **7 (Never)**.
- Do not paraphrase, round or substitute: exact hex values, fonts, point sizes, table banding, status pills and footer rules are executed literally.
- Styling never adds emphasis the evidence does not support: no callout that reads as a judgement, and the manager's assessment section stays visibly empty.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Section 6 governs its subject line, bottom-line block and en-GB tone.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## Quality bar / verification checklist

- [ ] Every person resolved to a real identity; ambiguity queried, never guessed.
- [ ] Every item cites an exact artifact name and date that exists.
- [ ] No adjective of quality anywhere ("excellent", "strong", "limited").
- [ ] No rating, score, ranking or cross-person comparison in any form.
- [ ] No reference to or proxy for a protected characteristic.
- [ ] Gaps stated as gaps, never as shortcomings.
- [ ] Manager's Assessment section is present and empty.
- [ ] One document per person.

## Failure handling

- **Rating or comparison requested:** decline in one sentence, restate that the
  judgement belongs to the manager and HR, offer the factual packs.
- **Person not found or ambiguous:** ask; never proceed on a best guess.
- **A source is inaccessible:** record it in Gaps and continue.
- **No evidence found at all:** produce the pack with empty sections and a clear note
  that no artifacts were retrievable for the period — do not pad it.
- **docx-agent fails:** retry once; otherwise return the evidence tables in chat and
  state that the document was not created.

## Guardrails

- Never auto-send a pack; show it to the requesting manager for review before sharing.
- If an artifact cannot be verified, is missing or the source is unavailable, omit the item and record the gap; never fabricate evidence.
- Evidence only. No judgement, no rating, no ranking, no comparison — ever.
- No fabricated names, numbers, dates or quotes; quotes are copied verbatim from a
  cited artifact or omitted.
- Do not open or cite personal, HR, medical or private content, even if retrievable.
- Share a pack only with the manager who requested it; do not email or post it
  anywhere without an explicit instruction in the current turn.
