---
name: org-action-tracker
description: |
  Maintains a living leadership action register: extracts action items from
  recurring staff/leadership meeting transcripts, Teams channels and email,
  deduplicates against the existing register, updates owner, due date and status
  from later evidence, and publishes an Excel register plus a weekly summary.
  Use when the user asks to "track all leadership actions from our staff
  meetings", "update the action register", "what actions are overdue", "who owes
  what from last week's leadership meeting", or "send the weekly actions summary".
  Do NOT use for personal to-dos or commitments made in one-to-one chats, for
  incident action tracking inside an escalation package, or for project plans
  and timelines.
metadata:
  category: productivity
  icon: TaskListSquare
---

## Purpose

Keep one authoritative register of actions agreed in leadership forums, updated
from evidence rather than memory, and push a weekly summary that leads with what
is overdue.

## When to Use

- After a recurring leadership/staff meeting, to harvest new actions
- Ad hoc: "what is overdue?", "what is due this week?"
- On a weekly schedule, to refresh the register and distribute the summary

## When NOT to Use

- Personal task capture or one-to-one commitments — use the commitment/to-do flow
- Incident actions inside an escalation — `customer-escalation-package` owns those
- Project planning, milestones or Gantt-style scheduling

## Inputs to Gather

Confirm once and reuse: the meeting series name(s), the leadership Teams team and
channel(s), the distribution list for the summary, the register workbook location,
and the reporting week (Mon–Sun, user's time zone).

| Source | Tool |
|---|---|
| Existing register | `sharepoint_onedrive-SearchDrive` / `GetDriveItem` → read via `xlsx-agent` |
| Meeting transcripts | `graph-ListMeetingTranscripts`, `graph-GetMeetingTranscript`, `graph-GetMyRecentTranscripts` |
| Leadership channels | `m365_teams-ListChannels`, `m365_teams-ListChannelMessages` |
| Email threads | `outlook-ListMessages`, `outlook-GetMessage` |
| Cross-workload | `m365_search-SearchM365` (e.g. "action", "AI:", "owner", meeting title) |
| Owner resolution | `me_profile-SearchPeople`, `GetDirectReportsDetails` |

## Workflow

1. **Load the register.** Read the existing workbook (IDs, actions, owners,
   status). If none exists, start a new register and say so.
2. **Sweep new evidence** for the period since the last update, using the tools
   above. Capture the exact artefact name and timestamp for each candidate.
3. **Extract candidate actions.** An action is a commitment to do something with
   a doer. Capture: verbatim-derived action text, stated owner, stated due date,
   source meeting/thread + date.
4. **Deduplicate** against the register by semantic match on action text + owner.
   An existing match is an **update**, not a new row; only genuinely new
   commitments get a new ID (`ACT-###`, never reuse an ID).
5. **Resolve status from later evidence.** Search for follow-up mentions; set
   `Open`, `In progress`, `Blocked`, `Closed` and record `last evidence`
   (artefact name + date). If no later evidence exists, leave status unchanged
   and note the staleness.
6. **Fill gaps honestly.** No stated owner → `unassigned`. No stated due date →
   `no date found`. Never infer either from seniority, tone or convenience.
7. **Rebuild the workbook** via `xlsx-agent` (spec below).
8. **Compose the weekly summary** and deliver it as a DRAFT (see below).

## Deliverable Spec

Delegate all file creation — never hand-author the workbook.

**(a) Excel action register — `xlsx-agent`.** Brief with the full row data and:

- **Register sheet:** ID, Action, Owner, Source meeting/date, Due date, Status,
  Last evidence. Autofilter, frozen header, conditional formatting — overdue rows
  red, due-this-week amber, closed grey.
- **Dashboard sheet:** KPI cells (Open, Overdue, Closed this period, Unassigned);
  a bar chart of open actions by owner; a time-series line chart of open vs closed
  actions by week (backed by a weekly snapshot table so history accumulates).

**(b) Weekly summary — email or Teams, DRAFT by default.** Order strictly:
1. **Overdue** (owner, action, days overdue, last evidence)
2. **Due this week**
3. **Recently closed**
Then a one-line stat block (open / overdue / closed this period / unassigned).
Create it with `outlook-CreateDraftMessage`, attaching the workbook via
`outlook-AddDraftAttachments` when asked. For Teams, print the exact message text
in chat for approval; post with `m365_teams-PostChannelMessage` only when the user
explicitly says to post.

**Recurring schedule.** Offer to automate with `host-SetupScheduledPrompt` — e.g. a
Monday 08:00 local prompt: "Run the org-action-tracker weekly refresh for the
leadership staff meeting: sweep last week's evidence, update the register and
prepare the summary as a draft." Confirm cadence, time zone and that the scheduled
run still drafts rather than sends. Manage existing schedules with
`host-GetScheduledPrompts` / `EditScheduledPrompt` / `DeleteScheduledPrompt`.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `xlsx-agent`. That agent cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste: **1 (Palette)**, **2 (Typography)**, **5 (Excel rules)**, **7 (Never)**; apply **6 (Email rules)** to the weekly summary yourself.
- Do not paraphrase, round or substitute: exact hex values, fonts, number formats, conditional-formatting bands and tab colours are executed literally.
- Sheet order is Dashboard first (KPI cards + native charts), then Register/Data, then Evidence by exact artefact name; status uses only `Done`, `In progress`, `No evidence found`, `Overdue`.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Teams posts follow the same rule.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## Quality Bar / Verification Checklist

- [ ] Every register row cites a source meeting/thread by exact name and date
- [ ] No duplicate actions; IDs stable across runs and never reused
- [ ] No invented owner or due date — gaps read `unassigned` / `no date found`
- [ ] Status changes are backed by a named later artefact in `Last evidence`
- [ ] Dashboard KPIs reconcile with the Register sheet row counts
- [ ] Both charts render; conditional formatting applied
- [ ] Summary leads with overdue, then due-this-week, then recently closed
- [ ] Email is a DRAFT / Teams text shown for approval unless told otherwise
- [ ] en-GB spelling, dates as DD/MM/YYYY

## Failure Handling

- **No transcript for a meeting:** note the gap, harvest from chat/email instead,
  and list the meeting under "not covered this period".
- **Ambiguous owner ("the team will…"):** record `unassigned` and surface it in the
  summary as needing an owner.
- **Register file missing or unreadable:** ask where it lives; if genuinely absent,
  create a fresh register and state that history starts now.
- **Conflicting due dates:** take the latest stated date, cite it, and flag the
  conflict in the summary.
- **Tool failure:** name the unreachable source, continue with the rest, and mark
  the coverage gap explicitly rather than implying full coverage.

## Guardrails

- Never send email or post to Teams without an explicit instruction to do so.
- Never invent owners, dates, statuses or evidence.
- Never close an action without a cited source saying it is done.
- Never hand-author .xlsx — always delegate to `xlsx-agent`.
