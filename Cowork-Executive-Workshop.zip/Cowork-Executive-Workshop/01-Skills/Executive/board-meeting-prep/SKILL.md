---
name: board-meeting-prep
description: |
  Prepares a named board, steering committee or executive meeting by resolving it on the calendar, pulling prior meeting transcripts and notes, commitment status, open actions, related emails and documents, then producing a styled Word briefing pack, an executive PowerPoint of at most eight slides, and a likely-questions-and-answers section. Use when the user says "prepare me for tomorrow's board meeting", "board prep", "get me ready for the steering committee", "prep for my QBR", or names a specific upcoming meeting to be briefed on. Do NOT use for a general weekly catch-up (use monday-morning-exec-briefing), for company research (use investment-research-pack), or for account risk scoring (use customer-health-review).
metadata:
  category: executive
  icon: PersonBoard
---

# Board Meeting Prep

## PURPOSE

Turn one named upcoming meeting into a defensible preparation pack: what was agreed last time, what was promised and by whom, what is still open, what has changed since, what to say, and what will be asked. Every fact cites its source meeting, email or document **by exact name**. Word and PowerPoint deliverables are produced by the **docx-agent** and **pptx-agent**.

## WHEN TO USE

- "Prepare me for tomorrow's board meeting", "board prep", "get me ready for the steering committee".
- Any specific upcoming governance meeting: board, steerco, QBR, exec review, programme board.

## WHEN NOT TO USE

- General weekly situational awareness → `monday-morning-exec-briefing`.
- External company or market research → `investment-research-pack`.
- Portfolio-wide account health scoring → `customer-health-review`.
- Writing the minutes of a meeting that already happened → use the meetings/notes skills.

## INPUTS TO GATHER

| Signal | Tool | Notes |
|---|---|---|
| Time zone | `outlook_calendar-GetUserDateAndTimeZoneSettings` | Resolve "tomorrow" correctly |
| Target meeting | `outlook_calendar-ListCalendarView` | Match by subject/attendees; capture subject, start, attendees, body/agenda, `onlineMeeting.joinUrl` |
| Prior occurrences | `outlook_calendar-ListCalendarView` (past 90-180 days) | Same series or same subject; capture each `joinUrl` |
| Transcripts | `graph-ListMeetingTranscripts` → `graph-GetMeetingTranscript` | Per prior `joinUrl`; the primary evidence source |
| Recent transcripts fallback | `graph-GetMyRecentTranscripts` | When a `joinUrl` is missing |
| Notes & decks | `sharepoint_onedrive-SearchDrive`, `m365_search-SearchM365` | Prior minutes, decks, trackers, status reports |
| Related email | `outlook-ListMessages`, `m365_search-SearchM365` | Threads with attendees or the meeting subject |
| Teams discussion | `m365_teams-ListChatMessages`, `m365_teams-ListChannelMessages` | Side conversations and pre-reads |
| Attendees | `me_profile-GetMultipleUsersDetails`, `me_profile-SearchPeople` | Roles and seniority, to pitch the tone |

## WORKFLOW

1. **Resolve the meeting.** Use the time zone, then `outlook_calendar-ListCalendarView` over the relevant window. If more than one candidate matches, ask the user to pick — never guess. Record subject, date/time, organiser, attendee list and agenda text.
2. **Find prior occurrences.** Search back 90-180 days for the same series or subject. List each with its date and `onlineMeeting.joinUrl`.
3. **Pull transcripts.** For each prior occurrence: `graph-ListMeetingTranscripts` on the `joinUrl`, then `graph-GetMeetingTranscript`. Note where no transcript exists — that is a gap, not an absence of content.
4. **Extract commitments and decisions.** From transcripts and minutes, list every commitment (who promised what, by when) and every decision taken. Quote only text that is literally in the transcript.
5. **Verify status.** For each commitment, look for evidence of completion in email, Teams, files and the calendar. Status is one of: Done (with evidence), In progress (with evidence), No evidence found, Overdue. "No evidence found" is a legitimate answer — never assume Done.
6. **Collect open actions and changes since.** Anything raised since the last occurrence that the meeting must know about: risks, slips, wins, new asks.
7. **Build talking points.** For the user specifically: what to say, in what order, with the supporting evidence attached to each point.
8. **Anticipate questions.** Derive 5-8 likely questions from open actions, missing evidence, overdue commitments, attendee roles and any bad news. Draft a suggested answer for each, grounded in evidence, and say plainly where the honest answer is "we do not know yet".
9. **Delegate the Word pack** to the docx-agent (brief below).
10. **Delegate the deck** to the pptx-agent (brief below).
11. **Report inline**: meeting resolved (name, date, time), both file paths, the top three things the user must be ready to say, and all gaps.

## DELIVERABLE SPEC

### (a) Word briefing pack — brief for docx-agent

- **File name:** `Board Prep - <meeting subject> - <YYYY-MM-DD>.docx`
- **Sections:**
  1. Meeting at a glance — subject, date/time (user time zone), location/online, organiser, attendees with roles.
  2. Agenda — as circulated; if none exists, say so and propose one derived from open items, clearly labelled as proposed.
  3. Prior-commitment status table — Commitment | Owner | Made on (meeting + date) | Due | Status | Evidence (exact artefact name).
  4. Open actions — Action | Owner | Raised | Current state | Source.
  5. What has changed since the last meeting — short bullets, each sourced.
  6. Executive talking points for the user — 5-7 points, each one line plus its supporting evidence.
  7. **Likely Questions & Suggested Answers** — Q, suggested answer, supporting evidence, and a confidence marker (Evidenced / Partial / Unknown).
  8. Sources & gaps — every artefact used by exact name and date; every source that was expected but unavailable.
- **Style:** professional, en-GB, Segoe UI, tables for all status data, no decorative graphics.

### (b) Executive PowerPoint — brief for pptx-agent

- **File name:** `Board Prep - <meeting subject> - <YYYY-MM-DD>.pptx`
- **Maximum 8 slides.** Board-level discipline:
  - One headline takeaway per slide, written as a full sentence in the title — the slide's conclusion, not its topic.
  - No bullet walls: at most four short supporting lines per slide.
  - Exactly one chart in the deck (commitment status, or trend of the metric the meeting governs), built from real numbers only. If there are no real numbers, omit the chart and say so.
  - Suggested flow: 1 Purpose & ask · 2 Where we stand · 3 Since last meeting · 4 Commitment status (chart) · 5 Risks & mitigations · 6 Decisions requested · 7 Next steps & owners · 8 Appendix pointer.
  - Source attribution in the footer of any slide carrying figures.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `docx-agent` and `pptx-agent`. Those agents cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)** for the pack, **4 (PowerPoint rules)** for the deck, **7 (Never)**.
- Do not paraphrase, round or substitute: exact hex values, fonts, point sizes, the content grid and chart rules are executed literally.
- Slide titles are full-sentence conclusions; the deck ends on the "What we recommend" pattern; every slide carrying a figure carries a source footnote.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Section 6 governs its subject line, bottom-line block and en-GB tone.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## QUALITY BAR / VERIFICATION CHECKLIST

- [ ] The correct meeting was resolved, and its date/time is stated in the user's time zone.
- [ ] Every fact in both deliverables cites its source meeting, email or document by exact name.
- [ ] No quote appears that is not literally present in a transcript or message.
- [ ] Every prior commitment has a status, and unverified ones say "No evidence found".
- [ ] Deck is ≤8 slides, one takeaway sentence per title, at most one chart, no bullet walls.
- [ ] Likely Questions has at least five entries, each with a confidence marker.
- [ ] Gaps section lists meetings without transcripts and any unavailable source.
- [ ] Both files exist at the reported paths and open.

## FAILURE HANDLING

- **Meeting not found** → show the candidate meetings found in the window and ask the user to choose. Do not invent a meeting.
- **No prior occurrence / no transcript** → build the pack from email, documents and Teams only, and state the evidence limitation at the top of the pack and on the deck's final slide.
- **Transcript access denied** → record the gap explicitly with the meeting name and date; never substitute recollection or inference.
- **Conflicting evidence** (e.g. a commitment reported done in email but open in the tracker) → present both, cite both, and flag it as a question for the meeting.
- **docx-agent or pptx-agent fails** → retry once with a tightened brief; if it fails again, deliver that portion inline and state clearly which file was not created.

## GUARDRAILS

- Read-only: never accept, decline, move or cancel meetings, and never send mail or post to Teams.
- No fabricated names, numbers, dates or quotes; unknowns are written as explicit gaps.
- Transcript content is confidential: quote sparingly, never attribute a view to someone not recorded as saying it.
- Office files always come from docx-agent / pptx-agent, never hand-authored.
