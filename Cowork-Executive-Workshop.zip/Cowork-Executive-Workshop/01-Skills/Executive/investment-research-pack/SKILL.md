---
name: investment-research-pack
description: |
  Builds an executive research pack on a named company by combining cited public research from the web with internal signals about prior engagement found across email, Teams and files, then producing a styled Word briefing document and a 10-12 slide executive PowerPoint. Use when the user says "evaluate Company X and prepare an executive briefing", "M&A research pack", "prepare a research pack on <company>", "due diligence brief on <company>", "what do we know about <company>", or asks for a partner, acquisition or investment assessment. Do NOT use for internal meeting preparation (use board-meeting-prep), for the weekly briefing (use monday-morning-exec-briefing), or for existing-customer risk scoring (use customer-health-review).
metadata:
  category: executive
  icon: BuildingBank
---

# Investment Research Pack

## PURPOSE

Produce a decision-grade briefing on a named company: what it is, how it is positioned, what we already know about it internally, where the risks are, and what to do next. The differentiator is the internal layer — prior engagements, opportunities and conversations — set against cited public research. Word and PowerPoint deliverables come from the **docx-agent** and **pptx-agent**.

## WHEN TO USE

- "Evaluate Company X and prepare an executive briefing", "M&A research pack", "prepare a research pack on <company>".
- Partner evaluation, acquisition screening, investment thesis, pre-engagement due diligence.

## WHEN NOT TO USE

- Preparing for a specific internal meeting → `board-meeting-prep`.
- Weekly situational awareness → `monday-morning-exec-briefing`.
- Health scoring of existing accounts → `customer-health-review`.
- Regulated financial advice: this skill informs, it never recommends a securities transaction.

## INPUTS TO GATHER

Confirm the exact legal or trading name and, if ambiguous, the country and sector before searching.

**External (public):**

| Signal | Tool | Notes |
|---|---|---|
| Overview, news, filings, funding | `host-web_search` | Multiple focused queries: profile, financials/results, funding/ownership, leadership, competitors, risks/litigation |
| Primary sources | `host-web_fetch` | Fetch the company site, investor relations, annual report, regulator or registry pages. Prefer primary over secondary |

**Internal (tenant):**

| Signal | Tool | Notes |
|---|---|---|
| Cross-surface mentions | `m365_search-SearchM365` | Company name plus known aliases, subsidiaries and domain |
| Email history | `outlook-ListMessages` | Threads with the company's people or about it |
| Teams discussion | `m365_teams-ListChatMessages`, `m365_teams-ListChannelMessages` | Prior deals, delivery issues, opinions |
| Documents | `sharepoint_onedrive-SearchDrive` | Proposals, SOWs, architecture docs, QBR decks |
| Meetings | `outlook_calendar-ListCalendarView` | Cadence and recency of contact |
| People | `me_profile-SearchPeople` | Internal colleagues who own the relationship |

## WORKFLOW

1. **Disambiguate the company.** Confirm the exact name, and note aliases, subsidiaries and the primary web domain. If two plausible companies share a name, ask the user which one.
2. **Public sweep.** Run `host-web_search` across: company profile and size; financial and market posture (latest published results, funding, ownership); products and positioning; leadership; competitors; recent news; risk, regulatory and litigation signals. Capture, for each fact, the source URL, the publisher and the publication date.
3. **Verify at the primary source.** `host-web_fetch` the company's own site, investor relations or a registry page for anything that will appear as a figure. A figure with only a secondary source is labelled as such.
4. **Internal sweep.** `m365_search-SearchM365`, then email, Teams, files and calendar. Build a prior-engagement history: what we did, when, with whom, outcome, and the exact artefact name for each entry.
5. **Reconcile.** Note where internal knowledge contradicts or adds to public information — this is usually the highest-value content in the pack.
6. **Analyse.** Write the SWOT from evidence only (every entry traceable to a source), then the risk register (commercial, technical, delivery, regulatory, concentration, reputational) with likelihood and impact stated as an explicit judgement, labelled as judgement.
7. **Recommend next steps** — 3-5 concrete actions with owners where known, plus the questions that must be answered before any decision.
8. **Enumerate the gaps.** Anything that could not be established (private financials, unverified headcount, unknown ownership) is written as an explicit gap with what would resolve it.
9. **Delegate the Word document** to docx-agent, then **the deck** to pptx-agent (briefs below).
10. **Report inline**: a five-line verdict, both file paths, the three biggest risks, and the top gaps.

## DELIVERABLE SPEC

### (a) Word briefing — brief for docx-agent

- **File name:** `Research Pack - <Company> - <YYYY-MM-DD>.docx`
- **Sections:**
  1. Executive summary — what the company is, why it matters to us, the verdict in one paragraph.
  2. Company overview — legal name, HQ, founded, sector, size, ownership, leadership. Each line sourced.
  3. Financial & market posture — published figures only, each with source and as-at date; market position and competitors.
  4. Prior engagement history — table: Date | Activity | People involved | Outcome | Source artefact (exact name).
  5. SWOT — four quadrants, every entry carrying its source.
  6. Risk register — Risk | Category | Likelihood | Impact | Evidence | Mitigation.
  7. Recommended next steps — numbered, with owners and the decision each unblocks.
  8. Open gaps — what is unknown and how to find out.
  9. Sources — numbered list: external with full URL and access date; internal with exact artefact name and date.
- **Style:** professional, en-GB, Segoe UI, tables for all structured data, inline numeric source markers tying back to the Sources list.

### (b) Executive PowerPoint — brief for pptx-agent

- **File name:** `Research Pack - <Company> - <YYYY-MM-DD>.pptx`
- **10-12 slides**, executive register: one headline takeaway sentence per slide title, at most four supporting lines, charts only from real sourced figures.
- Suggested flow: 1 Title & verdict · 2 Company at a glance · 3 What they do / positioning · 4 Financial & market posture · 5 Competitive landscape · 6 Our history with them · 7 Opportunity thesis · 8 SWOT · 9 Risks & mitigations · 10 Recommended next steps · 11 Open questions & gaps · 12 Sources.
- Every slide carrying figures shows its source in the footer.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `docx-agent` and `pptx-agent`. Those agents cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)** for the briefing, **4 (PowerPoint rules)** for the deck, **7 (Never)**.
- Do not paraphrase, round or substitute: exact hex values, fonts, point sizes, the content grid and chart rules are executed literally.
- Slide titles are full-sentence conclusions; use the big-number KPI layout where one figure carries the message; source-footnote every slide with figures.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Section 6 governs its subject line, bottom-line block and en-GB tone.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## QUALITY BAR / VERIFICATION CHECKLIST

- [ ] **No fabricated figures.** Every external claim carries a source URL; every internal claim cites the artefact by exact name.
- [ ] Every figure states its as-at date and whether the source is primary or secondary.
- [ ] Unknowns appear as explicit gaps, never as estimates, ranges or "approximately".
- [ ] Judgements (SWOT entries, likelihood, impact, thesis) are visibly labelled as judgement, not fact.
- [ ] Prior-engagement history is complete for what the tenant search returned, and states the search terms used.
- [ ] The deck is 10-12 slides and every chart traces to a sourced figure.
- [ ] Both files exist at the reported paths and open.

## FAILURE HANDLING

- **Ambiguous company** → present the candidates with distinguishing detail and ask the user to choose.
- **Private company, little public data** → say so prominently, base the pack on what exists, and make the gaps section the honest centrepiece.
- **Conflicting figures between sources** → present both with their sources and dates; never average or pick silently.
- **Paywalled or unreachable source** → cite what the search result showed, mark it unverified, and do not quote beyond it.
- **No internal history found** → state "no internal engagement found" with the search terms used, rather than implying none exists.
- **docx-agent or pptx-agent fails** → retry once with a tightened brief; otherwise deliver that portion inline and say clearly which file was not created.

## GUARDRAILS

- Hard rule: never fabricate figures, dates, names or quotes. An unknown is a gap, always.
- No investment advice or valuation opinion; the pack presents evidence and options.
- Internal information stays internal: never send it outside the tenant, and never put customer-confidential detail into a pack destined for an external audience without saying so.
- Office files always come from docx-agent / pptx-agent, never hand-authored.
