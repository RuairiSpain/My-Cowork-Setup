---
name: brand-consistency
description: |
  Applies and enforces a house style across everything produced — palette,
  typography, tone of voice, terminology, naming and formatting conventions —
  either by styling a new artefact or by auditing an existing one and reporting
  every deviation. Use when the user says "make this on-brand", "does this match
  our house style", "apply our template to this", "check this against our brand
  guidelines", "these decks all look different", or "standardise how we write this".
  Do NOT use to create the artefact itself from scratch (use docx-agent,
  pptx-agent or xlsx-agent), to improve the writing's clarity (use writing-skills),
  or to verify factual accuracy (use cite-your-sources).
metadata:
  category: productivity
  icon: Color
---

# Brand Consistency

## Overview

Inconsistent output does not read as variety; it reads as nobody being in charge. This
skill holds one definition of house style and applies it — to a new artefact by writing
the rules into the brief, and to an existing one by auditing it deviation by deviation.

## When to Use

- Before an artefact goes to an external or executive audience.
- A set of documents or decks from different authors that must look like one thing.
- "Apply the template" — where the template exists but nobody follows it.
- Establishing a house style where none has been written down.

## When NOT to Use

- Creating the document, deck or workbook — the format agents own that.
- Making the writing clearer or shorter — `writing-skills`.
- Checking facts and sources — `cite-your-sources`.

## Core Instructions

### Step 1: Establish the standard, in writing

Use, in this order of preference: an existing written standard in the skills folder (for
executive work, `Executive/_shared/executive-design-standard.md`); the organisation's
template library via `sharepoint_onedrive-GetOrgTemplateLibrary`; or a recent artefact the
user names as correct. **If no standard exists, say so and offer to write one** — do not
invent a palette and present it as the house style.

### Step 2: Reduce it to explicit, executable rules

A standard is only useful if it can be executed without judgement: exact hex values, exact
font names and sizes, table and header treatments, number and date formats, the terms that
are always used and the ones never used. Vague guidance ("professional, modern") produces
nothing repeatable.

### Step 3: Paste the rules into the brief — never cite them

`docx-agent`, `pptx-agent` and `xlsx-agent` cannot see your reference files. Copy the
relevant sections **verbatim** into the brief you hand them. This is the single most
common cause of off-brand output.

### Step 4: Audit an existing artefact deviation by deviation

Open it (`host-InspectDocument`, `sharepoint_onedrive-ReadFileContent`) and report each
deviation with: where it is, what the rule says, what the artefact does, and the fix.
Not "the colours are off" — "slide 4 title is `#1F4E79`; the standard is `#132B4D`".

### Step 5: Cover voice as well as visuals

Terminology (the product's real name, not the internal shorthand), tone, spelling variant
(en-GB throughout this pack), date format, capitalisation of role and product names, and
the words the house does not use.

## Output

- Which standard was applied, and where it came from.
- For a new artefact: the exact rule block that was pasted into the brief.
- For an audit: a deviation table — location, rule, actual, fix — and a compliance count.
- Anything the standard does not cover, so the gap can be closed once rather than debated
  every time.

## Guardrails

- Never invent brand rules and present them as the organisation's standard.
- Never cite a reference file to a format agent instead of pasting its contents.
- Never substitute a "close enough" colour, font or format — exact values, executed literally.
- Never let brand styling change a fact, a figure or a caveat.
- Never apply decorative treatments the standard forbids — clip art, gradients, shadows, emoji.
- Never overwrite an original artefact without saying that a styled copy was produced.
