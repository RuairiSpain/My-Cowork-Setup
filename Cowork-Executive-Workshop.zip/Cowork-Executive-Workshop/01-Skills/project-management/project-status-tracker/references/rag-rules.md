# RAG Rules — reference asset (NOT a skill)

> Read by `project-status-tracker`. Applied literally: the rating is derived from these
> rules, never from judgement. The skill must name the specific rule that produced each
> rating. Edit this file to match your organisation's governance — the skill does not
> need changing when you do.

## Overall project rating

Assess in order. **The first rule that matches sets the rating** — do not average.

| Rating | Triggering conditions (any one) |
|---|---|
| **Red** | A milestone on the critical path has slipped and there is no agreed recovery plan · Forecast completion is more than 20 working days beyond baseline · Forecast cost exceeds approved budget · An issue rated High severity is open with no owner · A dependency has failed with no alternative identified |
| **Amber** | A milestone has slipped more than 10 working days but a recovery plan exists and is dated · Forecast is 5–20 working days beyond baseline · A High-severity risk is open with a mitigation that has not yet started · A required decision has been outstanding for more than 10 working days · Key resource is unavailable with no cover agreed |
| **Green** | All critical-path milestones forecast within 5 working days of baseline · No open High-severity issues · All open risks have owners and started mitigations · No decision outstanding beyond 10 working days |
| **No evidence found** | Insufficient evidence exists to place the project in any band. **This is a valid rating and must be used rather than defaulting to Green.** |

## Milestone status

| Status | Definition |
|---|---|
| `Done` | Completion evidenced by a named artefact — a confirmation mail, a sign-off, a meeting record. A date in a plan is not evidence. |
| `In progress` | Evidence of activity within the last 10 working days |
| `Overdue` | Forecast or baseline date has passed with no completion evidence |
| `No evidence found` | No evidence of activity or completion either way |

## Variance

`Variance (working days) = Forecast (or Actual) date − Baseline date`

Positive is late. Compute with a code tool, never mentally. Report in working days in the
user's locale. Where no baseline exists, report `No baseline` — never treat the current
forecast as the baseline.

## Risk and issue severity

| Severity | Test |
|---|---|
| **High** | Would move the overall rating to Red if it materialised, or already has |
| **Medium** | Would cause a milestone slip of 5–20 working days |
| **Low** | Absorbed within existing contingency |

Trend since last report: `New`, `Worsening`, `Stable`, `Improving`. A risk with no owner
is recorded as `No owner identified` and listed separately — unowned risks are a finding
in their own right.

## Re-baselining

A baseline changes only through a recorded approval. When it does, the report states: the
old baseline, the new baseline, the approver by name, and the date. An unapproved
re-baseline is itself a Red condition — it is how a project silently stops being late.

## Escalation thresholds

| Condition | Action |
|---|---|
| Red for the first time | Escalate to the sponsor in this report, by name |
| Amber for three consecutive reports | Treat as Red — sustained amber is a stalled project |
| Any milestone `No evidence found` for two consecutive reports | Escalate the reporting gap itself |
