---
name: project-status-tracker
description: |
  Produces a formal project status report — RAG rating derived from stated rules
  rather than feel, milestone progress against baseline, risks and issues with
  owners, and a change-since-last-report section — tracked over time so the trend
  is visible. Use when the user says "produce the project status report", "what's
  our RAG status", "weekly project update for the steering group", "is this project
  on track", or "build me a status tracker for these projects".
  Do NOT use for day-to-day chasing and unblocking (use project-coordinator), for a
  leadership action register (use org-action-tracker), or for team workload and
  delivery health (use manager-weekly-team-pulse).
metadata:
  category: productivity
  icon: DataBarVertical
---

# Project Status Tracker

## Overview

A RAG status that reflects how the project manager feels is worse than none, because it is
trusted. This skill derives the rating from stated rules, evidences every milestone, and
keeps the history so that "amber for the fourth week running" becomes visible.

## When to Use

- A recurring status report to a steering group, sponsor or portfolio review.
- A portfolio of projects needing one comparable view.
- "Are we actually on track?" — where the honest answer matters.

## When NOT to Use

- Chasing owners and unblocking work — `project-coordinator`.
- Leadership-forum actions — `org-action-tracker`.
- Team workload and delivery health — `manager-weekly-team-pulse`.

## Core Instructions

### Step 1: Establish the baseline

Milestones, dates and scope **as originally agreed** — from the plan, the charter or the
approval mail. Without a baseline there is no "on track", only "busy". If no baseline can
be found, say so and report progress in absolute terms instead.

### Step 2: Gather the real position

`m365_search-SearchM365`, `outlook-ListMessages`, `m365_teams-ListChannelMessages`,
transcripts via `graph-ListMeetingTranscripts`, and any plan or tracker in
`sharepoint_onedrive-SearchDrive`. Every milestone status cites the artefact and date that
evidences it.

### Step 3: Derive RAG from the rules in `references/rag-rules.md`

Read the rules file and apply it literally. State the rule that produced each rating
("Amber: a milestone has slipped more than 10 working days with a recovery plan"). A
rating without its triggering rule is not acceptable output.

### Step 4: Compare to last report

Load the previous report and produce a **change-since-last** section: what moved, what
slipped, what rating changed and why. This section is what the steering group actually
reads. First run: say it is the baseline report and history starts now.

### Step 5: Risks and issues, with owners

A **risk** might happen; an **issue** already has. Each carries an owner, a date, a
mitigation, and its trend since last report (`New`, `Worsening`, `Stable`, `Improving`).
Unowned entries read `No owner identified` — and that absence is itself reportable.

### Step 6: Build the tracker

Delegate to `xlsx-agent`: a Dashboard sheet (RAG by project, milestone burn-up, a
week-by-week RAG history strip), a Data sheet (one row per milestone with baseline date,
forecast date, actual, variance in days, status), a Risks & Issues sheet, and an Evidence
sheet naming every source artefact by exact name and date. Where the audience needs a
document, delegate the narrative to `docx-agent`.

## Output

- Overall RAG, with the specific rule that produced it.
- Milestones: baseline vs forecast vs actual, variance in days, each evidenced.
- Change since last report.
- Risks and issues with owners, dates and trend.
- The tracker workbook, and a narrative document where requested.
- An explicit gaps list: milestones with no evidence either way.

## Guardrails

- Never set a RAG rating by judgement — apply the rules file and name the rule.
- Never report green where a milestone has no supporting evidence; that is `No evidence found`.
- Never quietly re-baseline. A changed baseline is a reportable event with a named approver.
- Never invent a forecast date, an owner or a mitigation.
- Never soften an issue into a risk to improve the rating.
- Never rate or compare the people working on the project.
- Never hand-author the workbook — delegate to `xlsx-agent`.
