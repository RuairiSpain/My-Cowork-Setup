---
name: cite-your-sources
description: |
  Makes a finished artefact auditable — anchoring every figure, date and quotation to
  the exact section, page, slide, row or timestamp it came from, and building an
  evidence appendix that lists each source by its real name and date. Use when the
  user says "make this auditable", "add an evidence appendix", "cite this by section
  and page", "where exactly did each of these numbers come from", "the board will
  challenge this — can we back it", or "prepare this for review".
  Do NOT use to write new prose from sources (use source-grounded-writing), to
  verify a file was produced correctly (use inspect-artifact), or to research a
  topic from scratch (use research-scope).
metadata:
  category: research
  icon: DocumentBulletListClock
---

# Cite Your Sources

## Overview

"We got it from the report" is not a citation; it is a hope. This skill takes a finished
piece of work and makes every load-bearing claim traceable to a specific location in a
specific named source — so that when it is challenged in a meeting, the answer takes ten
seconds rather than two days.

## When to Use

- Anything going to a board, an auditor, a regulator or a customer under scrutiny.
- A document assembled from several sources where provenance has blurred.
- Preparing to defend a number someone else produced.
- Turning a draft's vague attributions into real anchors.

## When NOT to Use

- Writing new prose from sources — `source-grounded-writing`.
- Checking a generated file is correct and complete — `inspect-artifact`.
- Researching the topic in the first place — `research-scope`.

## Core Instructions

### Step 1: Extract the load-bearing claims

List every claim the argument actually rests on: figures, dates, names, quotations,
obligations, and any statement a reader could dispute. Ignore connective prose — it needs
no citation and citing it buries the ones that matter.

### Step 2: Anchor each claim to a location, not a document

A document name is not an anchor. Cite the **section, clause, page, slide, sheet and cell,
or transcript timestamp**. For a contract, cite the section that *defines* the term, not
merely one that repeats it. For a derived figure, name the source figure it comes from and
how it was derived.

### Step 3: Re-open the source and check

Do not cite from memory or from a prior summary. Re-read the source
(`sharepoint_onedrive-ReadFileContent`, `graph-GetMeetingTranscript`,
`outlook-GetMessage`, `host-InspectDocument`) and confirm the claim is actually there and
actually says that. This step is the whole skill.

### Step 4: Mark what cannot be anchored

Any claim with no locatable source is flagged in place — not quietly deleted, not smoothed
over. Three honest outcomes: `No source located`, `Source says something different`, or
`Derived — see method`. Each is more useful than a confident sentence with nothing behind it.

### Step 5: Build the evidence appendix

One row per source: exact name, author or sender, date, type (email / transcript /
document / workbook / web page / semantic model), and the claims it supports. Exact names
only — never a humanised paraphrase like "the Q4 summary".

## Output

- The artefact with anchored citations in place.
- An evidence appendix table, one row per source.
- A list of claims that could not be anchored, each with which of the three outcomes applies.
- A count: claims checked, claims anchored, claims unsupported.

## Guardrails

- Never cite a source you did not re-open in this run.
- Never invent a page, section, clause or timestamp to make a citation look complete.
- Never include a URL that did not appear verbatim in a tool result.
- Never delete an unsupported claim silently — flag it and let the user decide.
- Never put internal scaffolding — workspace paths, session or tool identifiers — into a
  delivered artefact. Readers see titles, authors, dates, sections, pages and real URLs only.
- Quoting from third-party web content stays within fair-use limits: short, attributed, never
  reproduced at length.
