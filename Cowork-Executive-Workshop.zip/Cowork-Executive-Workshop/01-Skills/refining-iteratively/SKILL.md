---
name: refining-iteratively
description: |
  Improves a draft or artefact over deliberate rounds — each pass fixing one named
  class of problem against explicit criteria, with what changed reported after every
  round and a stated point at which it is finished. Use when the user says "another
  pass on this", "keep improving it until it's right", "make this better", "iterate
  on this", "what would make this stronger", or "review and revise this a few times".
  Do NOT use to define the criteria in the first place (use definition-of-done), to
  copy-edit prose in a single pass (use writing-skills), or to check that a file was
  generated correctly (use inspect-artifact).
metadata:
  category: productivity
  icon: ArrowSync
---

# Refining Iteratively

## Overview

"Make it better" without criteria produces churn: each round changes different things and
nobody can tell whether it improved. This skill makes iteration deliberate — one problem
class per pass, judged against criteria agreed before the first round, with an explicit
stopping point.

## When to Use

- A deliverable that is close but not right, where the gap is not yet named.
- Work that must survive a hostile review.
- A draft the user has already changed three times without converging.
- Before something goes to an audience that will only look at it once.

## When NOT to Use

- Writing the acceptance criteria — `definition-of-done`.
- A single clarity edit — `writing-skills`.
- Verifying a generated file is complete and correct — `inspect-artifact`.

## Core Instructions

### Step 1: Get the criteria before the first pass

Refinement without criteria is redecoration. Either take the criteria from
`definition-of-done`, or write three to five testable ones now — each phrased so it can
fail. Show them, and do not begin until they are agreed.

### Step 2: One problem class per pass

Never mix. Run the passes in this order, because fixing structure invalidates polish:

1. **Substance** — is anything wrong, missing, unsupported or fabricated?
2. **Structure** — is it in the order the reader needs?
3. **Evidence** — does every claim trace to a named source?
4. **Clarity** — length, specifics, hedging.
5. **Presentation** — formatting, styling, house standard.

### Step 3: Report what changed after every pass

Each round ends with: what class was addressed, the three or four specific changes made,
which criteria now pass, and which still fail. A round with no reported change did not
happen.

### Step 4: Diminishing returns is a result

When a pass produces only preference-level changes, say so and stop. Continuing past that
point makes the work worse and burns the user's attention. State plainly: "this pass found
nothing substantive — I would stop here."

### Step 5: Guard against drift

Re-check against the original intent every second pass. Iteration quietly moves a
deliverable towards what is easy to improve and away from what it was for.

## Output

- The criteria, stated before the first pass.
- Per round: the problem class, the changes made, criteria passing and still failing.
- The final artefact.
- A stop statement: why it is finished, and what was deliberately left undone.

## Guardrails

- Never iterate without criteria — write them first, even quickly.
- Never mix problem classes in one pass.
- Never report a pass with no specific changes listed.
- Never introduce a new fact, figure or claim during refinement.
- Never let polish hide a substance problem found in pass one — substance is fixed first.
- Never continue past diminishing returns because more rounds were requested; say so and stop.
