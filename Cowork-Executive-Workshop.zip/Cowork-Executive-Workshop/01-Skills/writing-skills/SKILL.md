---
name: writing-skills
description: |
  Improves business prose without changing what it says — cutting length, putting
  the conclusion first, replacing abstraction with specifics, fixing structure, and
  removing hedging and filler. Use when the user says "tighten this up", "make this
  clearer", "this is too long", "rewrite this in plain English", "why does this read
  badly", or "make this sound less like a committee wrote it".
  Do NOT use to apply visual or brand styling (use brand-consistency), to write an
  update from evidence (use stakeholder-comms), to add citations (use
  cite-your-sources), or for creative or marketing copywriting.
metadata:
  category: communication
  icon: TextEditStyle
---

# Writing Skills

## Overview

Bad business writing is almost never a vocabulary problem. It is structural: the
conclusion arrives last, the specifics have been replaced by abstractions, and the writer
has hedged because they were not sure. This skill fixes those three things, in that order,
without altering the meaning.

## When to Use

- A draft that is twice as long as it needs to be.
- Something that has been through several hands and lost its point.
- Prose that says "we will explore opportunities to drive alignment".
- A message the user senses is not landing but cannot say why.

## When NOT to Use

- Visual, template or palette work — `brand-consistency`.
- Writing a new update from evidence — `stakeholder-comms`.
- Adding attribution — `cite-your-sources`.
- Marketing, advertising or creative copy.

## Core Instructions

### Step 1: Find the sentence that should be first

Read the draft and locate the conclusion — usually in the last paragraph, often in a
subordinate clause. Move it to the top. Most "unclear" writing is correctly ordered for
the writer's thinking and backwards for the reader's needs.

### Step 2: Cut by a third, then look again

Remove: filler openers ("I wanted to reach out"), throat-clearing context the reader
already has, restated points, adverbs doing an adjective's work, and any sentence that
would not be missed. Length is the most reliable proxy for unclear thinking.

### Step 3: Replace abstraction with specifics

"Improved performance" → the figure. "Shortly" → the date. "The team" → the name. Where
the specific genuinely is not known, say **that** — "the date is not yet agreed" is
information; "in due course" is not.

### Step 4: Remove hedging, or make the uncertainty explicit

Hedging usually means one of two things: the writer is unsure, or the writer is
protecting themselves. If unsure, say what is uncertain and what would settle it. If
protecting, delete it. Never both hedge and assert in the same sentence.

### Step 5: Fix structure last

One idea per paragraph. Bold leads where the reader will scan. A table only where it
genuinely beats prose. Short sentences for the load-bearing points — long ones lose the
thing they are carrying.

### Step 6: Check meaning survived

Compare the original and the edit claim by claim. If the edit says anything the original
did not — or drops a caveat the original carried — that is an error, not an improvement.
Show the user anything that changed in substance.

## Output

- The edited text.
- The before/after word count.
- The three or four structural changes made, each in one line ("moved the conclusion from
  paragraph four to the opening").
- Anything cut that was load-bearing enough to flag, so the user can put it back.
- Anything the original was ambiguous about, where the edit had to pick a reading.

## Guardrails

- Never change what the text claims, only how it reads.
- Never drop a caveat, condition or qualification that carried meaning.
- Never add a fact, figure, name or date that was not in the original.
- Never make bad news read as good news; clarity applies equally to what went wrong.
- Never replace the user's voice with a generic corporate register.
- en-GB spelling and date format; no emoji, no exclamation marks.
