# Cowork Skills Pack — Executive Edition

Personal Cowork skills for executive and C-suite work. Copy the folders into your
Cowork skills folder in OneDrive (`Documents/Cowork/skills/`), keeping the structure
below intact — the `Executive/_shared/` references are read by path.

## Structure

```
Executive/
  _shared/executive-design-standard.md   reference asset — visual standard (not a skill)
  _shared/automation-patterns.md         reference asset — automation rules (not a skill)
  <skill>/SKILL.md                       one folder per skill
definition-of-done/ escalate-one-question/ integrate-me/
research-scope/ source-grounded-writing/ email-inbox/inbox-triage/
```

`Executive/_shared/` holds three reference documents:

| File | What it governs |
|---|---|
| `executive-design-standard.md` | Palette, typography and the Word / PowerPoint / Excel / email rules |
| `automation-patterns.md` | Which automation mechanism to use, and the safety rules for unattended runs |
| `demo-fallbacks.md` | What each skill does when a dependency (Power BI, a workbook, a prior deck, a SharePoint list) is unavailable — used for workshops and first runs |

Files named `_shared/*.md` have no frontmatter on purpose: they are reference documents,
never triggerable skills. The Executive skills read them and paste the relevant sections
verbatim into the brief handed to `docx-agent`, `pptx-agent` or `xlsx-agent`, because
those agents cannot see the files.

## Executive skills

### Briefing and preparation
| Skill | What it does |
|---|---|
| `monday-morning-exec-briefing` | Two-page Word briefing from the last 7 days and the week ahead |
| `board-meeting-prep` | Word briefing pack + ≤8-slide deck + likely Q&A for a named meeting |
| `overnight-strategy-analyst` | Date-validated external scan with impact, threats and owned actions |
| `exec-audio-briefing` | The briefing as a timed spoken audio file for the commute |

### Customers and markets
| Skill | What it does |
|---|---|
| `customer-health-review` | Scored account portfolio with a formula-driven Excel dashboard |
| `customer-escalation-package` | SEV1 report, exec deck, action tracker and customer email draft |
| `investment-research-pack` | Cited public research + internal signals → Word brief and deck |
| `board-metrics-from-powerbi` | Board numbers straight from the semantic model, with filter context |

### Running the organisation
| Skill | What it does |
|---|---|
| `org-action-tracker` | Living leadership action register + weekly summary |
| `manager-weekly-team-pulse` | Team delivery and workload pulse (never individual performance) |
| `quarterly-evidence-pack` | Source-cited contribution evidence per direct report — evidence only |
| `onboarding-30-60-90-review` | New-joiner ramp against milestones — evidence, not a rating |
| `targeted-survey-and-report` | Pulse survey end to end: design, distribute, collect, report |
| `exec-stakeholder-update` | The same facts recast for board / leadership / org / customer |

### Time, tools and automation
| Skill | What it does |
|---|---|
| `exec-autopilot-triggers` | Scheduled prompts, event triggers, mail rules and travel cover |
| `exec-calendar-defence` | Time audit against stated priorities, then acts on the calendar |
| `exec-decision-cockpit` | Live interactive app bound to real data, shared with the team |
| `exec-live-web-desk` | Authenticated portals, bookings and form submissions on the live web |

## Craft skills (non-executive)

### Scoping and quality
| Skill | What it does |
|---|---|
| `clarify-the-ask` | Turns a vague request into a six-line brief, with an out-of-scope line |
| `definition-of-done` | Testable acceptance criteria before work starts, checked after |
| `refining-iteratively` | Deliberate improvement passes, one problem class at a time |
| `skill-creator` | Designs a new skill to this pack's conventions, with a trigger test |

### Evidence and research
| Skill | What it does |
|---|---|
| `context-gathering` | Systematic M365 sweep into a timeline, positions and gaps |
| `research-scope` | Sizes a research request before any searching starts |
| `research-synthesis` | Combines threads, surfaces contradictions rather than averaging |
| `source-grounded-writing` | Writes prose where every claim traces to a named source |
| `cite-your-sources` | Anchors claims to section, page, cell or timestamp; evidence appendix |
| `excel-analysis` | Profiles, error-checks and answers questions from a workbook or CSV |

### Communication and delivery
| Skill | What it does |
|---|---|
| `stakeholder-comms` | Audience-targeted team, project or partner update — draft only |
| `escalate-one-question` | Reduces a blockage to exactly one decision with the evidence |
| `writing-skills` | Tightens business prose without changing what it says |
| `brand-consistency` | Applies or audits house style — palette, typography, voice |
| `teams-connector` | Finds the conversation, summarises it, posts only on instruction |
| `email-inbox/inbox-triage` | Five-bucket inbox triage with reply drafts and a dated report |

### Delivery management
| Skill | What it does |
|---|---|
| `project-coordinator` | Chases owners, separates late from blocked, drafts the follow-ups |
| `project-management/project-status-tracker` | Rules-derived RAG, milestones vs baseline, tracked over time |
| `integrate-me` | Interactive integration design interview → grounded integration plan |

**A note on `email-triage`.** The original archive contained an empty folder of this name
alongside the complete `email-inbox/inbox-triage`. It has not been recreated: two skills
with near-identical names compete for the same trigger phrases and make routing unreliable
for both. `inbox-triage` owns inbox work.

## Conventions every skill in this pack follows

1. **Frontmatter**: `name` (matching the folder name exactly), a `description` that states
   what it does, when to use it with real trigger phrases, and when NOT to use it with the
   skill that owns that case instead, plus `metadata.category` and `metadata.icon`.
2. **Gather before generating** — evidence first, from the tools, never from the prompt alone.
3. **Never fabricate**. Missing facts read `No evidence found` / `No owner identified` /
   `No date agreed`, and are listed as gaps.
4. **Draft, never send**. Email is created with `outlook-CreateDraftMessage`; Teams text is
   shown for approval. Unattended runs are held to this more strictly, not less.
5. **Delegate file creation** to `docx-agent`, `pptx-agent` or `xlsx-agent` — never
   hand-author an Office file.
6. **No performance evaluation** of named individuals, in any skill, on any cadence.
7. **en-GB** spelling and date format throughout.
8. Every skill ends with a **quality bar checklist**, **failure handling** and **guardrails**.
