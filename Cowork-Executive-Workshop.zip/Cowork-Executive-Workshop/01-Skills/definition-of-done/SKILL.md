---
name: definition-of-done
description: |
  Turns a request into a short list of testable acceptance criteria before work
  starts, and checks a finished result against that list before it is called done.
  Use when user asks to "define done for this", "what does done look like",
  "write acceptance criteria", "set success criteria", "agree a definition of done",
  or "is this actually finished".
  Do NOT use for project plans, timelines or task breakdowns, and do NOT use it to
  judge an artefact's real contents — use inspect-artifact for that.
metadata:
  category: productivity
  icon: CheckmarkCircle
---

## Overview

Most delivery failures are agreement failures: nobody wrote down what "done"
meant, so the result gets declared complete while a requirement is still open.
This skill converts a request into a small set of criteria that can each be
checked as true or false, and gives a completion rule that cannot be satisfied
by assertion alone.

It produces criteria. It does not produce plans, estimates or schedules.

## When to Use

- Before starting work whose output will be judged by someone else.
- When a request contains several explicit requirements and one could be missed.
- When two people may disagree about whether something is finished.
- When a result is being handed back and needs a completion check.
- When a piece of work has already been revised more than once without landing.

## When NOT to Use

- A single deterministic operation with an obvious result ("what time is my 3pm?").
- Work with no meaningful success criteria — exploration, brainstorming, a chat.
- Producing a project plan, milestone list or timeline — that is a planning task.
- Judging whether a delivered file really contains what was claimed; use
  inspect-artifact instead — this skill defines the bar, that one tests against it.
- Raising a blocked item to a decision-maker; use escalate-one-question instead.

## Core Instructions

### Step 1: Recover the real requirements

Read the request and list every explicit requirement in the user's own words —
named sections, columns, audiences, formats, counts, deadlines. Where the request
references material you do not hold (a document, a thread, a meeting), retrieve it
first with the appropriate M365 tools rather than guessing at the requirement.

Separate what was **stated** from what you are **assuming**. Assumptions are listed
separately and labelled, never promoted into criteria silently.

### Step 2: Write each criterion so it can fail

A criterion is only useful if there is a result that would fail it. For each one, record:

| Field | Meaning |
|---|---|
| Criterion | What must be true, stated as an observable fact |
| Required | Mandatory, or desirable-but-optional |
| How checked | Deterministic (count, schema, arithmetic, presence) or judged |
| Evidence | What specifically demonstrates it — a section, a figure, a file |

Prefer deterministic checks wherever one exists. "The workbook has a Summary,
Detail and Assumptions sheet" is checkable; "the workbook is comprehensive" is not.
Rewrite any criterion containing *good*, *clear*, *robust*, *appropriate* or
*comprehensive* until it names the thing that would be observed instead.

Keep the list to 3-7 criteria. A longer list is usually one criterion restated.

### Step 3: State the completion rule

Done means, and only means:

```
every mandatory criterion passes
AND each one has its named evidence
AND no open question or approval remains outstanding
```

Optional criteria are reported, never used to claim completion.

### Step 4: Check a result against the list

When checking finished work, take each criterion in turn, name where it is
satisfied, and mark it pass, fail or unverified. **Unverified is not a pass.**
Do not accept a claim of completion as evidence of completion — point at the thing.

If anything is unresolved, say the work is incomplete and name exactly which
criteria are open. Never describe partially-finished work as done, and never
quietly reword a criterion so that it passes.

## Output

**Defining done** — a short table, nothing else:

```
Definition of done — <task>

| # | Criterion | Required | How checked | Evidence |
|---|-----------|----------|-------------|----------|
| 1 | ...       | Yes      | Deterministic | ... |

Assumptions: <listed, or "none">
Done when: all mandatory criteria pass with evidence.
```

**Checking a result** — the same table with a verdict column, then one line:
either "Done — all mandatory criteria pass" or "Not done — N open:" followed by
the open criteria. Keep the whole thing under a page.

## Guardrails

- Never invent a requirement the user did not state; label inferred items as assumptions.
- Never mark a criterion passed without naming the evidence for it.
- Never soften or reword a criterion to make a result pass.
- Never report work as done while a mandatory criterion is unverified.
- Criteria describe the output, not the effort spent producing it.
- Do not evaluate a person's performance — criteria apply to deliverables only.
- If the objective is too vague for any criterion to be written, say so and ask
  one focused question rather than producing criteria that cannot fail.
