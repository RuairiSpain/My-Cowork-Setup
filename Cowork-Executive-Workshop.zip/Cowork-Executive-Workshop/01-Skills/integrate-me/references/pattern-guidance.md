# Recommended-pattern guidance

Guidance, not rules. Use it to shape grounded options in the interview and to justify the
recommended architecture. **Confirm current capabilities, limits and quotas against
Microsoft Learn in the run** — never quote a figure from this file or from memory.

## Choosing the integration service

| Option | Fits when | Watch out for |
|---|---|---|
| **Azure Logic Apps** | Low-code orchestration, many connectors, long-running and stateful workflows, B2B/EDI via Integration Account | Per-action cost at high volume; connector-specific limits; Consumption vs Standard differ materially |
| **Azure Functions** | Custom code, lightweight transforms, event handlers, glue with bespoke logic | Cold start on Consumption; execution timeouts; you own the retry and idempotency logic |
| **Azure Service Bus** | Reliable queuing, ordering with sessions, transactions, dead-lettering, decoupling producer from consumer | Message size limits; needs a consumer design; not a pub/sub fan-out for huge volume |
| **Azure Event Grid** | Discrete event notification and reactive fan-out, low latency, many sources and handlers | At-least-once delivery — consumers must be idempotent; events are notifications, not payload carriers |
| **Azure Event Hubs** | High-throughput telemetry and streaming ingestion, replay from an offset | Partitioning and consumer-group design is a commitment; not a work queue |
| **Azure API Management** | Fronting APIs for governance: auth, throttling, versioning, quotas, developer portal, hybrid façade | Tier choice drives cost and VNet options; another hop to operate |
| **Azure Data Factory / Synapse pipelines** | Scheduled bulk data movement, ETL/ELT, backfill and historical migration | Not for low-latency; integration runtime placement matters for on-prem and private networking |
| **Power Automate / Power Platform connectors** | Business-user-owned automation, M365-centric flows, fast delivery, approvals | Ownership and licensing; throughput limits; weaker ALM than code-based options |
| **Microsoft Graph** | Anything M365: mail, calendar, Teams, files, users; change notifications for near-real-time | Subscriptions expire and must be renewed; throttling is per-resource; delta queries for sync |
| **Azure Integration Environments** | Grouping and governing related integration resources as one application | Confirm current availability and regional support before recommending |
| **Microsoft Dataverse** | A governed data layer with security model, relationships and business logic; Power Platform ecosystem | Licensing; API request limits; model the tables deliberately |
| **Azure Arc** | Estate spans on-premises or other clouds and needs consistent governance and management | Adds an operating model, not a data pipe |

## Shape-of-problem shortcuts

- **Event notification, react fast** → Event Grid (+ Functions or Logic Apps handler)
- **Guaranteed processing, order, retry** → Service Bus (+ consumer)
- **High-volume telemetry / streams** → Event Hubs
- **Scheduled bulk or historical backfill** → Data Factory
- **Orchestrate several systems with approvals** → Logic Apps
- **Expose or consume APIs across boundaries** → API Management in front
- **M365 data both directions** → Microsoft Graph, delta query for sync, change notifications for latency
- **Business-owned, low volume, fast** → Power Automate

## Cross-cutting defaults

- **Credentials:** managed identity first; Key Vault for anything that must be a secret; never a secret in
  configuration or code. Call out and justify any deviation.
- **Networking:** private endpoints where both ends support them; explicit egress allow-listing otherwise.
- **Reliability:** assume at-least-once delivery — design idempotent consumers, with dead-lettering and replay.
- **Observability:** correlation ID end to end, into Application Insights / Log Analytics, with alerts on
  dead-letter depth and failure rate.
- **Lifecycle:** infrastructure as code (Bicep or Terraform) and a versioned interface contract from day one.
