# Gap and edge-case checklist

Working list for the discovery loop. **Select only the areas relevant to the named
services** — this is a menu to pick from, not a script to read out. Ask one topic at a
time via `core-AskUserQuestion`, with grounded options and a "not needed / skip" option.

Rough priority order: identity → data and sync semantics → reliability → networking →
observability → lifecycle → operations → compliance → cutover. Adjust to the topic.

## 1. Identity and authentication
- Microsoft Entra ID app registration: who owns it, which tenant
- Managed identity vs service principal vs client secret vs certificate
- Delegated vs application permissions; acting as a user vs as the service
- Least-privilege scopes — the minimum permission set that works
- Token lifetime, refresh, and what happens when a secret or certificate expires
- Guest / B2B users, and external identities on the third-party side

## 2. Authorisation and data boundaries
- RBAC model: which roles can read, write, configure
- Tenant isolation; single-tenant vs multi-tenant design
- Data residency and sovereignty (EU / Spain), where data is processed and stored
- Microsoft Purview, DLP policies, sensitivity labels and whether labels must survive the hop

## 3. Networking
- Public endpoints vs private endpoints
- VNet integration; subnet and address-space availability
- Firewall rules and egress IP allow-listing on both sides
- Hybrid and on-premises connectivity: ExpressRoute, VPN, on-premises data gateway
- DNS resolution, including private DNS zones
- TLS versions, certificates and pinning

## 4. Data
- Schema and interface contract; who owns it and how it is published
- Mapping and transformation rules; reference data and lookups
- Volume, message rate, payload size limits, batching strategy
- Large files and attachments — chunking, staging storage
- PII and sensitive fields: minimisation, masking, encryption
- Encoding, character sets, time zones, date formats, currency and units

## 5. Sync semantics
- Real-time vs batch vs event-driven; push vs pull
- Webhooks and Microsoft Graph change notifications, including subscription renewal
- Polling frequency where polling is unavoidable
- Ordering guarantees; idempotency keys; duplicate detection
- Delta / watermark strategy and how it recovers after an outage
- Conflict resolution when both sides change the same record
- Deletes and tombstones — hard vs soft delete propagation

## 6. Reliability
- Retries with exponential backoff and jitter
- Throttling and HTTP 429 handling; honouring Retry-After
- Documented service limits and quotas (look them up — never from memory)
- Dead-letter queues and poison-message handling
- Circuit breakers, timeouts, bulkheads
- Partial failure and compensating actions
- Expected SLA of each dependency and the composite SLA

## 7. Error handling and observability
- Structured logging and what must never be logged
- Correlation IDs flowing end to end
- Application Insights / Log Analytics workspace, retention, cost of ingestion
- Alerting: what pages someone, what is a ticket, what is a dashboard
- Dashboards and health checks
- Runbooks for the top failure modes; replay and reprocessing procedure

## 8. Environments and lifecycle
- Dev / test / prod separation; test tenants and sandbox instances of the third party
- Infrastructure as code: Bicep or Terraform; what stays click-ops and why
- CI/CD pipelines, approvals, deployment strategy
- Secrets in Azure Key Vault; rotation
- Configuration management and per-environment settings
- API versioning and breaking-change policy; deprecation and sunset

## 9. Operations
- Ownership: which team runs it day two
- Support model, hours, escalation path to the third party
- Cost model and estimate; the main cost drivers
- Capacity and scale: peak load, growth, scale limits
- Disaster recovery, RPO and RTO, region failover
- Backup of state, queues and configuration

## 10. Compliance and governance
- Audit logging: what, where, retained for how long
- Data retention and deletion; GDPR rights (access, erasure, portability)
- Approvals required: architecture review, security review, change advisory
- Records of processing, DPIA, third-party risk assessment

## 11. Migration and cutover
- Coexistence period: both systems live at once, and who is authoritative
- Backfill of historical data; volume, window and throttling impact
- Cutover plan and rollback plan; the point of no return
- User communications and training; support readiness
