---
name: integrate-me
description: |
  Runs an interactive integration design interview for Azure, Microsoft 365 and
  third-party systems, then produces a grounded integration plan. Use when the user
  says "integrate me with ...", "I need to integrate X with Y", "design an integration
  for ...", "integration plan for ...", "connect <system> to <system>", or "what's the
  best way to integrate ...". Surfaces gaps and edge cases one at a time via
  core-AskUserQuestion and keeps going until the user says stop or finish.
  Do NOT use for writing or debugging code for an integration that is already designed,
  for general Azure how-to questions with no integration scope, or for simple connector
  setup the user just wants executed — do that work directly instead.
metadata:
  category: analysis
  icon: PlugConnected
---

## Overview

An integration design interview. The user names a topic ("integrate me with ServiceNow",
"connect Dataverse to SAP"). This skill grounds itself in Microsoft Learn documentation,
then works the topic through a question-driven discovery loop — surfacing gaps and edge
cases one at a time — and finally produces a structured integration plan with a decisions
register, a phased delivery plan and real, retrieved citations.

Audience: a Cloud Solution Architect. Language: plain, business-readable **en-GB**.

## When to Use

- "Integrate me with <system>" / "I need to integrate A and B"
- "Design an integration for ..." / "Integration plan for ..."
- "Connect <system> to <system>" / "What's the best way to integrate ...?"
- The user wants the *design* thought through, not just executed

## When NOT to Use

- Writing, debugging or refactoring code for an integration that is already designed — just write the code
- General Azure how-to questions with no integration scope — answer directly
- A simple connector setup the user wants executed now — execute it
- Producing the final Word document — hand that to the **docx-agent** (see Output)

## Quick Start

```
User: "Integrate me with ServiceNow for incident sync"
1. Restate scope in 1-2 lines, confirm briefly
2. Ground: web_search / web_fetch Microsoft Learn for the named services
3. Loop: one gap at a time via core-AskUserQuestion (1-2 questions, ≤4 options)
4. Repeat until the user says stop / finish / that's enough
5. Produce the integration plan (inline markdown by default)
```

## Core Instructions

### Step 1: Restate the scope
Restate the integration in one or two lines: source system, target system, direction, and
the business outcome as you understand it. Ask for a quick confirmation — one line, not a
questionnaire. If the user corrects you, adopt the correction and move on.

### Step 2: Ground before asking
Before the first question, use `web_search` and `web_fetch` against Microsoft Learn and the
Azure service documentation for the services named (and the likely integration services).
Retrieve: supported integration patterns, authentication options, service limits, quotas,
throttling behaviour and regional/data-residency notes.

Record the exact page **title** and **URL** of everything retrieved — these become the
References section. Ground every subsequent question and recommendation in what was
retrieved. Never assert a limit, quota, price or feature availability from memory; look it
up, and if it cannot be retrieved, say so.

### Step 3: Gap and edge-case loop (the heart of the skill)
Walk [references/gap-checklist.md](references/gap-checklist.md), selecting only the areas
relevant to the named services — never blindly ask all of them. Then, repeatedly:

1. Pick the next highest-impact gap or edge case. **Propose gaps the user has not
   mentioned** — that is the value of this skill; do not wait to be asked.
2. Ask it with `core-AskUserQuestion` — **never a plain-text question**. Keep each round
   small: 1-2 questions, maximum 4 options each. Options must be concrete and grounded in
   the documentation retrieved in Step 2 (name the actual service, auth method or limit),
   and must always include a "Not needed / skip" option.
3. Record the answer as a decision: in scope / out of scope / deferred, plus its
   implication for the design.
4. Move to the next gap. One topic at a time — never dump a wall of questions.

Use [references/pattern-guidance.md](references/pattern-guidance.md) to shape the options
and to form the architecture recommendation as the picture firms up.

### Step 4: Stop signal
The loop continues **until the user says stop** — "stop", "finish", or an obvious
equivalent ("that's enough", "done", "wrap it up", "just give me the plan"). On that signal
stop asking immediately and go to Step 5. If `core-AskUserQuestion` returns empty answers
(the user cancelled), treat that as a stop signal too.

The user may stop at any point, including after the first question, and must still receive
a usable plan from whatever was gathered — everything unanswered goes under
"Open questions".

### Step 5: Produce the deliverable
Write the plan using the Output structure below.

## Output

Default: deliver the plan **inline as markdown**. If the user asks for a document or file,
or the plan is long and they want to share it, route to the **docx-agent** to produce a
Word document (pass it the full plan text and the intended audience).

Structure, in this order:

1. **Scope and objectives** — restated, including what was explicitly ruled **out** during the interview
2. **Current state and assumptions**
3. **Recommended target architecture and integration pattern** — with rationale and the alternatives considered
4. **Decisions register** — a table: Gap / edge case | Answer (in scope / out of scope / deferred) | Implication
5. **Phased delivery plan** — phases only where the work warrants them (e.g. Phase 0 discovery/PoC, Phase 1 MVP, Phase 2 hardening, Phase 3 scale and operate); each with outcomes, key tasks, exit criteria and rough effort
6. **Risks and mitigations**
7. **Open questions / decisions still needed** — including every checklist area not covered
8. **References** — every Microsoft Learn or Azure documentation page used, with the exact page title and real URL taken **verbatim** from a search or fetch result in this run

## Guardrails

- **One topic at a time.** Never present a 20-question wall.
- **Always use `core-AskUserQuestion`** for questions in the loop; always include a "not needed / skip" option.
- **Ground everything.** Never assert service limits, quotas, pricing or feature availability from memory — retrieve them.
- **Never fabricate a citation.** Only cite pages actually retrieved by a search or fetch in this run; if nothing was retrievable for a point, say so rather than inventing a URL or title.
- Never invent product names, SKUs or prices.
- Managed identity plus Key Vault is the default credential recommendation; call out any deviation explicitly.
- Plain, business-readable language; **en-GB** spelling throughout.
- Respect "stop" instantly, at any point, and still deliver a usable plan.
