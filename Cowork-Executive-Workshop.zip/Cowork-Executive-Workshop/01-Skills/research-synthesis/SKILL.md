---
name: research-synthesis
description: |
  Combines several research threads, documents or reports into one answer —
  reconciling where they agree, surfacing where they contradict each other rather
  than averaging them, weighting sources by quality and recency, and stating what
  none of them settles. Use when the user says "pull this research together",
  "synthesise these findings", "these reports disagree — what's the actual answer",
  "what's the through-line across all of this", or "summarise everything we found".
  Do NOT use to decide how much research to do (use research-scope), to run the
  research itself (use the deep research agent), or to write a single-source
  summary (use source-grounded-writing).
metadata:
  category: research
  icon: Merge
---

# Research Synthesis

## Overview

Synthesis is not summarising several things in a row. It is deciding what is true across
them — which means the contradictions are the most valuable part, and averaging them away
is the most common way to destroy the work.

## When to Use

- Several parallel research threads have returned and need one answer.
- Two or more reports, analyst notes or internal documents disagree.
- A long-running topic where evidence has accumulated from many directions.
- Before a decision that several people have researched separately.

## When NOT to Use

- Sizing the research before it starts — `research-scope`.
- Doing the research — the deep research agent.
- One source, one summary — `source-grounded-writing`.

## Core Instructions

### Step 1: Inventory the inputs before reading for content

List every input: what it is, who produced it, its date, and its method or basis. Two
sources that share an origin are one source — a finding repeated in four articles that all
cite the same study is one data point, not four.

### Step 2: Extract claims, not summaries

Reduce each input to its specific claims — a figure, a direction, a cause, a
recommendation — each tagged with its source and date. Summaries cannot be compared with
each other; claims can.

### Step 3: Cluster: agreement, tension, orphan

- **Agreement** — multiple independent sources, same claim. Say how many, and that they
  are independent.
- **Tension** — sources conflict. This is the section that earns the work.
- **Orphan** — one source only. Report it as such; a single-source claim is not a finding.

### Step 4: Work the contradictions rather than resolving them away

For each tension, explain *why* the sources differ: different period, different
definition, different population, different method, different incentive. Then either state
which is better supported **and why**, or state plainly that the evidence does not settle
it. **Never split the difference to produce a tidy number.**

### Step 5: Weight explicitly

Recency, independence, method, and proximity to the subject. Say how you weighted, so the
reader can disagree with the weighting rather than the conclusion.

### Step 6: State what none of it answers

The open questions, and — where it matters — what evidence would settle them. This is
usually the most actionable paragraph in the output.

## Output

- **What the evidence supports** — the through-line, with the number of independent sources.
- **Where sources disagree** — each contradiction, why it exists, and what you conclude or
  cannot conclude.
- **Single-source claims**, flagged as such.
- **What remains open**, and what would resolve it.
- **Source inventory**: every input by exact name, producer and date, with its weighting.

## Guardrails

- Never average conflicting figures into a single number.
- Never present a repeated claim from one origin as corroboration.
- Never drop an inconvenient source because it complicates the story.
- Never assert a conclusion the inputs do not carry — "the evidence does not settle this"
  is a valid and often correct answer.
- Never quote third-party sources at length; short attributed quotations only.
- Never mix internal M365 evidence with public research without labelling which is which.
