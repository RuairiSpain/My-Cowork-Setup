---
name: escalate-one-question
description: |
  Turns a stuck or blocked piece of work into a short escalation that asks for
  exactly one decision, with the evidence and options needed to answer it in one
  reply. Use when user asks to "escalate this", "I'm stuck on this", "write an
  escalation", "flag this to my manager", "we need a decision on this", or "ask
  them the one question we need answered".
  Do NOT use for routine status updates, announcements or broad stakeholder
  messaging; use stakeholder-comms instead.
metadata:
  category: communication
  icon: ArrowTrendingLines
---

## Overview

A bad escalation lists everything that went wrong and asks for help. A good one
asks a single answerable question and supplies exactly what the reader needs to
answer it without a meeting. This skill produces the second kind.

The test: could the recipient reply with one sentence and unblock the work?
If not, the escalation is not finished.

## When to Use

- Work has stopped and further attempts will not move it.
- Progress needs a judgement, a permission or information you cannot obtain.
- Two credible options exist and the choice is not yours to make.
- A constraint, budget, deadline or limit has been reached.
- Repeated attempts have produced the same failure.

## When NOT to Use

- A periodic status update with no decision attached; use stakeholder-comms instead.
- An announcement to a broad audience; use stakeholder-comms instead.
- The answer is retrievable from email, Teams, files or the calendar — look it up
  first; an escalation for something discoverable wastes the reader's attention.
- The blocker has not been diagnosed yet — find out what is actually wrong first.
- Acceptance criteria are what is missing; use definition-of-done instead.

## Core Instructions

### Step 1: Gather before escalating

Search first. Check recent email, Teams, files and meeting notes with
`m365_search-SearchM365` for a prior decision or an existing answer. An escalation
that could have been resolved by a search costs credibility.

Identify the right recipient with `me_profile-SearchPeople` or
`me_profile-GetManagerDetails` — the person who can actually decide, not the
nearest senior name.

### Step 2: Reduce it to one question

Write the decision as a single sentence, ending in a question mark, answerable
by choosing between named options. Then check it:

- Is it **one** question, not several joined by "and"?
- Can it be answered in one reply, without a meeting?
- Is the answer a **decision**, not a status?
- Would a one-word answer actually unblock the work?

If several things are open, escalate the one that blocks the others and hold the
rest. Two questions in one message reliably get one answer.

### Step 3: Give only the context needed to answer it

Four short elements, nothing else:

1. **What is blocked** — the work and its consequence, in one line.
2. **Why it is stuck** — the specific cause, with evidence: what was tried, what
   happened, the actual error, figure, constraint or limit that was hit.
3. **Options** — two or three, each with its trade-off in a clause.
4. **Your recommendation** — pick one and give the reason in a sentence.

Recommending is not deciding. Always recommend; it makes the reply cheap.

### Step 4: State what happens if there is no answer

Give the date the decision is needed and the consequence of silence — what stops,
slips or defaults. Without this, the escalation has no urgency and will queue.

### Step 5: Send it the right way

Email via `outlook-SendEmailWithAttachments` for anything needing a record or a
considered answer; Teams via `m365_teams-PostMessage` for a same-day decision.
If the user asked not to send, or asked for a draft, produce the draft with
`outlook-CreateDraftMessage` and stop.

Show the full text to the user before sending — an escalation lands on a senior
person's desk once, and the wording is the user's to own.

**When something cannot be resolved:** if the recipient search returns several
plausible people, present the candidates and let the user pick rather than
guessing at who decides. If it returns nobody, or if the supporting evidence is
missing and cannot be retrieved, do not fabricate a figure, a date or an impact —
draft the escalation with the gap marked as `[needs: …]` and say which part is
unverified. If a send fails, say so plainly and keep the draft; never report an
escalation as sent unless the tool confirmed it.

## Output

Under 150 words in the body. Subject names the decision, not the problem —
"Decision needed: vendor for the Q4 migration", not "Migration issues".

```
Subject: Decision needed by <date> — <the decision>

<What is blocked, one line.>

Why it's stuck: <specific cause with evidence.>

Options:
A. <option> — <trade-off>
B. <option> — <trade-off>

My recommendation: <A or B>, because <one reason>.

If I don't hear by <date>, <what happens by default>.
```

## Guardrails

- Exactly one question. If a second one is drafted, hold it for the next message.
- Never escalate without saying what was already tried and what it produced.
- Never attribute a blocker to a named individual's performance; describe the
  situation, the dependency or the decision — not the person.
- Ground every fact in something retrieved; never fabricate an impact figure, a
  date or a quotation — if it is missing, mark the gap and say it is unverified.
- Always show the drafted message to the user before it is sent.
- If the decision-maker cannot be identified, ask who rather than guessing.
- Always include a recommendation, and always mark it as a recommendation.
- Never imply a decision has been made, or that silence counts as approval.
- Honour a do-not-send instruction absolutely: draft it and stop.
- Keep it short. Length reads as unresolved thinking, and delays the answer.
