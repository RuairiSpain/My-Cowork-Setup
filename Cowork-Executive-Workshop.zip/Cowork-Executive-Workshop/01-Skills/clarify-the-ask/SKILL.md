---
name: clarify-the-ask
description: |
  Turns a vague or overloaded request into a scoped brief before any work starts —
  separating the real goal from the stated task, resolving what can be looked up,
  and asking only the questions whose wrong answer would waste the work. Use when
  the user says "help me scope this", "I'm not sure what I'm actually asking for",
  "is this brief clear enough", "what do you need from me to do this", "tighten
  this request before I send it", or hands over a request that could mean three
  different things.
  Do NOT use to write acceptance criteria for work already scoped (use
  definition-of-done), to size a research effort (use research-scope), or to gather
  the background material itself (use context-gathering).
metadata:
  category: productivity
  icon: QuestionCircle
---

# Clarify the Ask

## Overview

Most rework comes from a request that was understood differently by the two people
involved. This skill makes the misunderstanding visible in two minutes, before anyone
spends a day on it — by restating the ask, looking up what is knowable, and asking only
the questions that genuinely change the work.

## When to Use

- A request that could reasonably produce three different deliverables.
- Before briefing someone else — a colleague, an agency, an agent.
- A request the user received and is not sure how to interpret.
- When the stated task and the underlying goal look different.

## When NOT to Use

- The scope is clear and what is needed is testable criteria — `definition-of-done`.
- Sizing how much research a question deserves — `research-scope`.
- Actually collecting the background — `context-gathering`.
- A simple factual question — just answer it.

## Core Instructions

### Step 1: Restate it in one sentence, and show the restatement

Write: *"You want <deliverable> so that <outcome>, for <audience>, by <when>."* Show it.
Most ambiguity surfaces the moment someone reads their own request back to them.

### Step 2: Separate the task from the goal

The stated task is what they asked for; the goal is what changes if it works. Where they
diverge, say so — "you asked for a deck, but the outcome you described is a decision from
one person, which is an email". Offer the cheaper route, do not impose it.

### Step 3: Look up everything that is knowable

Before asking anything, resolve what the tools can answer — who the audience is
(`me_profile-SearchPeople`), when the deadline meeting is
(`outlook_calendar-ListCalendarView`), what already exists on the topic
(`m365_search-SearchM365`, `sharepoint_onedrive-SearchDrive`). **A question you could
have answered yourself is a cost you imposed on the user.**

### Step 4: Ask only load-bearing questions, and at most three

A question is load-bearing if a wrong guess means the work is thrown away. Everything else
gets a stated default instead: "I'll assume the last quarter unless you say otherwise."
Ask with `core-AskUserQuestion`, grounded options only — never a free-text "which one?"
when a lookup could offer concrete candidates.

### Step 5: Write the brief, and name what is out of scope

Six lines maximum: deliverable, audience, outcome, deadline, the constraints that bind,
and — the line most briefs are missing — what is explicitly **not** being done.

## Output

- The one-sentence restatement.
- Any divergence between task and goal, with the cheaper route offered.
- The assumptions being made, each stated as a default the user can overturn.
- At most three questions, only where a wrong guess wastes the work.
- The six-line brief, including an explicit out-of-scope line.

## Guardrails

- Never ask what a tool can answer.
- Never ask more than three questions; prefer a stated default to a question.
- Never re-ask something already settled in this task.
- Never rewrite the user's goal into something more convenient to deliver.
- Never start the work inside this skill — it produces a brief, not a deliverable.
- Treat an empty answer as a cancellation: acknowledge briefly and proceed on the defaults.
