# Verification reference

Loaded only when a draft is being checked. The SKILL.md body carries the workflow;
this file carries the detail.

## Source hierarchy

Rank candidate sources before quoting any of them. Higher tiers win outright on a
conflict; note the conflict rather than averaging it.

| Tier | Examples |
|---|---|
| 1. Primary / first-party | The contract, filing, invoice, transcript, telemetry, the vendor's own product documentation, the author's own post |
| 2. Official secondary | Standards bodies, regulators, peer-reviewed work, official release notes |
| 3. Reputable reporting | Established publications with named authors and dated corrections |
| 4. Commentary | Blogs, summaries, aggregators, forum answers — usable for orientation, not as the cited authority |
| 5. Unattributable | Undated pages, no named author, content farms, SEO summaries of tier 1 material |

Search ranking is not authority. A well-optimised tier 4 summary routinely
outranks the tier 1 page it was written from; cite the tier 1 page.

**Recency matters differently by claim type.** Prices, versions, org structure,
headcount and policy go stale fast — check the date and say how old the figure is.
Definitions, historical events and contract terms do not.

## Claim decomposition

Break the draft into atomic claims. One claim = one thing that could independently
be true or false. A sentence often holds several.

> "Revenue grew 12% to $4.2M in Q3, driven by the enterprise segment."

decomposes to:

1. Q3 revenue was $4.2M — *checkable against the source figure*
2. That is 12% growth — *recompute from the prior-period figure*
3. Growth was driven by the enterprise segment — *causal; needs the source to say it*

Claim 3 is the one that most often turns out to be the writer's inference dressed
as the source's finding.

## The check, in order

Cheap and deterministic first — most defects are caught before any judgement is needed.

1. **Locator exists.** The cited section, page, sheet or slide is really in the source.
2. **Locator says it.** Re-read that specific passage. A citation pointing at the
   right document and the wrong section is still wrong.
3. **Quotes match.** Compare character-for-character against the source text.
4. **Numbers recompute.** Every total, percentage, delta, average and ratio, via a
   code tool, against the stated inputs. Show the comparison when it disagrees.
5. **Defining vs repeating.** For a defined term or value, the citation points at
   the section that establishes it, not a later one that restates it.
6. **Dates and units.** Currency, fiscal vs calendar period, timezone, thousands
   vs millions. A correct number in the wrong unit is a wrong claim.
7. **Causal language.** "Because", "driven by", "as a result of" — does the source
   assert the causation, or only the correlation?
8. **Attribution of positions.** If the text says a person or org holds a view,
   the source must show them holding it — not someone else describing them.
9. **Scope creep.** The source said "in EU markets"; the draft says "globally".
10. **Judgement pass.** Only now: does the claim fairly represent the source in
    context, or does it survive checks 1-9 while still misleading?

## Common failure patterns

| Pattern | What it looks like |
|---|---|
| Retrofitted citation | Draft written from memory, sources found afterwards to match |
| Plausible bridge | A gap between two supported facts filled with a reasonable-sounding sentence |
| Confident rounding | "About 15%" where the source says 11.3% |
| Laundering | A tier 4 summary cited as though it were the tier 1 source it paraphrased |
| Silent staleness | A 2019 figure presented in the present tense |
| Borrowed certainty | The source hedges ("may", "is expected to"); the draft asserts |
| Orphan quote | Quoted text with no locator, or a locator that does not contain it |
| Averaged conflict | Two sources disagree; the draft splits the difference instead of reporting both |

## Handling disagreement between sources

Do not resolve it silently. Name each source, state what each says, and say which
is higher in the hierarchy and why. If they are the same tier, report the
disagreement as the finding — it usually is one.

## When there is nothing to ground against

If retrieval returns nothing usable, the correct output is a statement that the
question cannot be answered from available sources, plus what was searched and
where else the user might look. Do not produce a draft built on illustrative or
representative content. A short honest gap is worth more than a page of fluent
reconstruction, and it is the only output the reader can safely act on.
