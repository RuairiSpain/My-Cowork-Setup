---
name: source-grounded-writing
description: |
  Writes and reviews factual prose where every claim traces to a named source,
  unsupported statements are marked rather than smoothed over, and "not in the
  sources" is an allowed answer. Use when user asks to "write this from the
  sources", "make sure every claim is backed", "add citations to this",
  "fact-check this draft", "which of these claims are unsupported", or
  "write a grounded summary".
  Do NOT use for creative or persuasive writing, or for verifying that a file
  was produced correctly; use inspect-artifact instead.
metadata:
  category: writing
  icon: DocumentBulletListClock
---

## Overview

Language models optimise for plausibility, not truth, and standard evaluation
rewards a confident guess over an honest abstention — so fluent fabrication is
the default failure mode, and a more capable model is a more convincing one.
This skill counters that with four layers, each fixing a different failure:

| Layer | Fixes |
|---|---|
| Grounding | the fact was never available |
| Citation | nobody noticed the claim was wrong |
| Abstention | it guessed, because guessing pays |
| Verification | the wrong claim reached the reader anyway |

Applies to prose the reader will act on: summaries, briefs, analyses, answers
drawn from documents, and reviews of someone else's draft.

## When NOT to Use

- Creative, persuasive or marketing writing where claims are not the point.
- Checking that a deliverable was correctly produced; use inspect-artifact instead.
- Defining what finished means for a task; use definition-of-done instead.
- Casual conversation, brainstorming, or opinion the user asked you for directly.
- Running a multi-source investigation to gather the facts in the first place;
  use deep-research instead, then write up its findings with this skill.
- Storing findings as durable notes; use knowledge-note instead.

## Core Instructions

### Step 1: Retrieve before writing, never after

Gather sources first — `m365_search-SearchM365`, `sharepoint_onedrive-ReadFileContent`,
`outlook-GetMessage`, `web_search` / `web_fetch` — and write only from what came
back. Never draft from memory and then hunt for citations to justify it;
retrofitted citations attach to claims that were invented first.

Rank sources before trusting them. Prefer primary and first-party material
(the contract, the filing, the vendor's own documentation, the meeting
transcript) over commentary about it. Content that ranks well is not thereby
authoritative — an SEO-optimised summary loses to a lower-ranked official page.
See [references/verification.md](references/verification.md) for the full hierarchy.

### Step 2: Write claim-by-claim, each one attributable

Every substantive claim — figure, date, name, quantity, causal statement,
attribution of a position to a person — carries its source inline, by the
smallest reader-facing locator that identifies it: section, heading, page,
slide, sheet, sender and date, or a real URL that appeared in tool output.

Never invent a locator, and never cite a section that merely repeats a value in
place of the one that defines it.

### Step 3: Mark what is not supported — do not smooth it

Three labels, used explicitly in the draft:

- **Supported** — a named source says this.
- **Inferred** — reasoning from supported facts. Say so, and show the step.
- **Unverified** — no source found. Mark `[unverified]` or leave a bracketed
  gap such as `[needs: Q3 figure]`. Never fill it with a plausible value.

**Abstention is a correct outcome, not a failure.** "The sources do not cover
this" beats a confident sentence, always. If the sources cannot answer the
question at all, say that as the answer.

### Step 4: Verify the draft against the sources before delivering

Decompose the finished draft into individual claims and check each one
separately — deterministic checks first (does the quote match the source text?
does the arithmetic recompute? does the cited section exist and say this?),
judgement second. Recompute every total, percentage and delta with a code tool
rather than by eye.

Do this as a distinct pass over the finished text, not while drafting.
Checking attribution and generating prose at the same time is how unsupported
claims survive. The checklist is in
[references/verification.md](references/verification.md).

### Step 5: Report what the check found

Deliver the prose, then state plainly: how many claims were checked, how many
are unverified, and which sources carried the weight.

## Output

The draft itself, with inline attribution, followed by a short block:

```
Grounding check
Claims checked: N · Supported: N · Inferred: N · Unverified: N
Unverified: <list each, or "none">
Sources used: <exact names>
Not covered by the sources: <what the user asked that could not be answered>
```

Never omit this block because everything passed — "0 unverified" is the
information the reader needs.

## Guardrails

- Never state a fact you did not retrieve. No figure, date, name, quote or URL
  from memory, and never a URL that did not appear verbatim in tool output.
- Never attach a citation to a claim that was written before the source was read.
- Mark unverified claims in the text itself, not only in a summary the reader may skip.
- Prefer "the sources do not say" over any plausible-sounding reconstruction.
- Recompute every number with a code tool; never do the arithmetic yourself.
- If retrieval returns nothing usable, say so and stop — do not substitute
  representative, illustrative or sample content for real source material.
- Distinguish "the source says X" from "X is true" when sources disagree; report
  the disagreement and name who says what rather than picking a winner silently.
- Reproduce third-party text within quoting limits; summarise rather than copy.
- Internal scaffolding — tool names, session identifiers, workspace paths —
  never appears in a citation. Readers get titles, sections, dates and real URLs.
