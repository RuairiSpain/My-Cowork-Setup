# Cowork for Executives — Workshop Exercise Manual

Eight labs · approximately 3 hours 15 minutes including discussion

---

## How to use this manual

Each lab has the same shape:

| Section | What it is for |
|---|---|
| **Business case** | Why this matters to someone in your job |
| **What the skill connects to** | Which of your data it reads, and anything outside your organisation |
| **Before you start** | Whether you need a demo file |
| **Steps** | What to do, in order |
| **What good looks like** | How to tell it worked |
| **Discuss** | One or two questions for the room |

**Step 1 of every lab is to read the skill and its guide.** Do not skip it. You will be
asked in the discussion what the skill refused to do and why, and the answer is in what
you read.

**Rules for every lab:**

- Nothing sends. Emails go to your **Drafts**. Teams messages are shown for approval.
- If a skill says it could not find something, that is a correct result. Note it and move on.
- If you are stuck for more than three minutes, ask your facilitator.

**Do you need the demo data?** Labs 3, 4 and 5 need a business file. If you do not have a
suitable real one, copy `04-Demo-Data/` into `Documents/Cowork/` before you begin. Labs 1,
2, 6, 7 and 8 use your own email, calendar and meetings and need no demo file.

---

# Lab 1 — What you need to know this week

**Skill:** `monday-morning-exec-briefing` · **20 minutes**

## Business case

You spend the first hour of most weeks reconstructing what happened in the last one —
scrolling mail, opening channels, checking who needs an answer. That hour produces nothing
and it happens 48 times a year. This lab replaces it with a two-page briefing built from
what is actually in your account.

## What the skill connects to

- Your email from the last seven days
- Your Teams chats and channels
- Your calendar for the week ahead
- Files you or your team changed recently

Nothing leaves your organisation. Nothing is sent.

## Before you start

No demo file needed. This uses your real account.

## Steps

1. Open `01-Skills/Executive/monday-morning-exec-briefing/SKILL.md`. Read **Purpose**,
   **When to Use** and **Guardrails**.
2. Open `02-Guides/Cowork-exec-skills-trigger-guide.md`. Read the section on briefing skills.
3. In Cowork, type: **`Prepare my executive briefing for this week.`**
4. Wait for it to finish. It reads several days of history, so allow two to three minutes.
5. Open the Word document it produced.
6. Find the **Gaps** section. Read what it says it could not reach.
7. Type: **`Which of these needs a decision from me this week, and who is waiting?`**

## What good looks like

- A two-page Word document, in your OneDrive.
- Five things to know, each naming a real email, meeting or message.
- A Gaps section that names anything it could not reach.
- No invented names, numbers or dates.

## Discuss

- What is in your top five that nobody currently tells you?
- The Gaps section named something it could not see. Would you rather it had guessed?

---

# Lab 2 — Where your week actually went

**Skill:** `exec-calendar-defence` · **25 minutes** · **contains an automation**

## Business case

Most executives can state their top three priorities for the quarter, and most cannot say
what share of their time those priorities actually received. This lab measures the gap, in
your own calendar, and then acts on it.

## What the skill connects to

- Your calendar, including recurring meetings expanded into real occurrences
- Your working hours and time zone
- Colleagues' free/busy information when finding a slot
- Meeting rooms, if you ask it to book one

Private and personal appointments are shown as time blocks only. It never repeats the
subject of a medical or personal entry into a summary.

## Before you start

No demo file needed. This uses your real calendar.

## Steps

1. Open `01-Skills/Executive/exec-calendar-defence/SKILL.md`. Read **Purpose**,
   **When to Use** and **Guardrails**.
2. Write down your top three priorities for this quarter, in your own words. You will be
   asked for them.
3. In Cowork, type: **`Where did my week go? My priorities this quarter are [your three].`**
4. Read the split it gives you. Note the percentage on your top priority.
5. Type: **`Which three meetings cost me the most time against those priorities?`**
6. Type: **`Protect two hours every Friday morning for strategy work, starting next week.`**
7. Confirm the calendar entry when prompted.

## Now the automation

Steps 3 to 6 were **normal Cowork activity**: you asked, it answered, it finished. The next
step is different — you are installing something that will run on its own, in future,
without you asking.

8. Type: **`Set this up to run every Friday at 4pm and tell me next week's split before it's too late to change it.`**
9. Read back what it proposes before confirming. Check it contains: the day, the time, your
   time zone, and what it will produce.
10. Confirm it.
11. Type: **`What have you got running for me?`**

## What good looks like

- A percentage split of your accepted hours against your stated priorities.
- Three meetings named specifically, not a general observation.
- A recurring calendar block, created.
- A scheduled task that appears when you ask what is running.

## Discuss

- What was the gap between your stated priority and the hours it received?
- **What changed when you moved from step 6 to step 8?** In step 6 you asked and it acted
  once. In step 8 you installed something that will act again next week, and the week
  after, whether or not you are thinking about it.
- Notice the Friday audit **reports**; it does not move your meetings on its own. Why is
  that the right line?

---

# Lab 3 — Where the risk actually is

**Skill:** `customer-health-review` · **25 minutes**

## Business case

Account risk is usually visible weeks before anyone says it out loud, in signals nobody
aggregates: how long since the last real conversation, how many escalations are open, how
the tone has changed. This lab scores a portfolio on those signals and produces the
workbook you would otherwise ask someone to build.

## What the skill connects to

- Email and Teams conversations with each account
- Meeting frequency and recency from your calendar
- Documents and commitments relating to those accounts

If you use the demo data instead, it reads only that file.

## Before you start

**You need a business file for this lab.**

- **If you have real account data** you are comfortable showing in a room — a customer
  list, a portfolio spreadsheet — use it.
- **If you do not:** copy `04-Demo-Data/Fabrikam-demo-data.xlsx` into `Documents/Cowork/`.
  It contains ten fictional accounts with contact recency, escalation counts and sentiment
  already in it.

## Steps

1. Open `01-Skills/Executive/customer-health-review/SKILL.md`. Read **Purpose**,
   **Scoring Model** and **Guardrails**.
2. Open the scoring detail at
   `01-Skills/Executive/customer-health-review/references/scoring-model.md`. Read how the
   four components are weighted.
3. In Cowork, type one of these:
   - Using your own data: **`Review our top accounts and tell me which are at risk.`**
   - Using the demo file: **`Review the accounts in Fabrikam-demo-data.xlsx and tell me which are at risk.`**
4. Open the workbook it produced. Start on the **Dashboard** sheet.
5. Find the account with the longest gap since the last conversation.
6. Type: **`Why is that account scored the way it is? Show me the evidence.`**
7. Type: **`Which accounts have an open commitment with no owner?`**

## What good looks like

- A workbook with a dashboard first, then the account data, then an evidence sheet.
- Every score traceable to the four components, not a single opaque number.
- At least one field reading **No evidence found** rather than a guess.
- The evidence sheet naming real sources by name and date.

## Discuss

- The account it flagged — did you already know, or is this the first time it has been
  stated?
- How many commitments in your own business currently have no named owner?

### Optional, 5 minutes — the data nobody checked

1. Open the **Raw_Export** sheet of the demo workbook. It is a realistic messy export.
2. Type: **`Analyse the Raw_Export sheet and tell me what's wrong with it.`**
3. Compare what it found against what you spotted by eye.

---

# Lab 4 — Numbers you can defend

**Skill:** `board-metrics-from-powerbi` · **25 minutes**

## Business case

A number in a board pack usually arrives via a deck, from a spreadsheet, from an export
somebody ran weeks ago. When it is challenged, nobody in the room can say what filter was
applied or when the data was last refreshed, and the decision is deferred. This lab
produces figures that carry their own evidence.

## What the skill connects to

- Your Power BI reports and the data models behind them
- The organisation's agreed measures and any verified answers
- Internal email and Teams context around those numbers

## Before you start

**Choose one:**

- **You have a Power BI report you can open.** Use it. Have the link ready.
- **You do not.** Copy `04-Demo-Data/Fabrikam-demo-data.xlsx` into `Documents/Cowork/` and
  use its **Financials** sheet — 24 months of revenue across three segments and five
  regions.

**If you use the spreadsheet, say so out loud during the lab.** It is a deliberate
step-down: a spreadsheet has no agreed measures, no verified answers and no refresh
timestamp, which are exactly the things this skill exists to surface. Knowing what the
fallback loses is part of the lesson.

## Steps

1. Open `01-Skills/Executive/board-metrics-from-powerbi/SKILL.md`. Read **Purpose**,
   **Workflow** and **Guardrails**.
2. In Cowork, type one of these:
   - With Power BI: **`Get the board numbers out of [paste your report link] for the last two quarters.`**
   - With the spreadsheet: **`Using the Financials sheet in Fabrikam-demo-data.xlsx, give me revenue and margin by segment for the last four quarters, with the source for every figure.`**
3. Find the **numbers annex** — the one-page table of every figure quoted.
4. Pick one figure. Check it shows: the period, the filter applied, and where it came from.
5. Type: **`What period and filter is that figure using, and when was the data last refreshed?`**
6. Type: **`Is there anything here you could not source?`**

## What good looks like

- Every figure carrying its period, its filter and its source.
- A reconciliation note if two sources disagree — stating both, not picking one.
- Any metric it could not source listed explicitly.
- No figure rounded or adjusted to be more convenient.

## Discuss

- Take the last board pack you presented. Which number in it could you trace to source
  today, in under a minute?
- If you used the spreadsheet fallback: what did you lose compared with a real data model?

---

# Lab 5 — Does this look like us?

**Skill:** `brand-consistency` · **20 minutes**

## Business case

Material that goes out under your name from six different people looks like it came from
six different companies. That is not a design problem; it reads as nobody being in charge.
This lab shows a standard being enforced rather than circulated.

## What the skill connects to

- The house style file inside the skills folder
- Your organisation's template library, if it has one
- The document or deck you point it at

## Before you start

**You need a slide deck for this lab.** Copy `04-Demo-Data/` into `Documents/Cowork/`. You
will use two files that contain **identical content** presented very differently:

- `Fabrikam-Q2-FY26-board-pack.pptx` — built to the standard
- `Fabrikam-Q2-FY26-board-pack-OFFBRAND.pptx` — deliberately broken, for this lab

## Steps

1. Open `01-Skills/brand-consistency/SKILL.md`. Read **Overview**, **Core Instructions**
   and **Guardrails**.
2. Open `01-Skills/Executive/_shared/executive-design-standard.md`. Skim sections 1, 2 and
   4 — the colours, the fonts and the slide rules.
3. Open both decks side by side. Spend two minutes listing what you think is wrong with
   the off-brand one.
4. In Cowork, type: **`Check Fabrikam-Q2-FY26-board-pack-OFFBRAND.pptx against our executive design standard and list every deviation.`**
5. Compare its list with yours.
6. Type: **`Which of those matter most to a board audience, and why?`**
7. Type: **`What would you change about the slide titles specifically?`**

## What good looks like

- A deviation list giving the slide, the rule, what the deck does, and the fix.
- Specific values, not impressions — a named colour and font, not "the colours are off".
- Slide titles identified as a problem: topics rather than conclusions.
- Placeholder text such as `TBD` flagged.

## Discuss

- Both decks contain exactly the same figures. Which one would you rather defend?
- You found some deviations by eye. How many did it find that you missed?

---

# Lab 6 — Say it once, four ways

**Skill:** `exec-stakeholder-update` · **20 minutes**

## Business case

A decision that affects several audiences usually gets communicated four times by four
people, and the versions disagree. The disagreement, not the decision, is what people
remember. This lab produces every version from one set of facts.

## What the skill connects to

- Email, Teams and meeting records for the decision you name
- Documents relating to it
- Your organisation's directory, to resolve who the audience actually is

Everything it produces is a **draft**.

## Before you start

No demo file needed. Pick a real decision or change from the last few months — a
reorganisation, a date that moved, a supplier change, a policy update.

## Steps

1. Open `01-Skills/Executive/exec-stakeholder-update/SKILL.md`. Read **Purpose**,
   **Workflow** and **Guardrails**.
2. In Cowork, type: **`Write an update for my leadership team about [your decision].`**
3. Read the first three lines. Check they say what is happening, why it matters, and what
   is being asked.
4. Type: **`Now write the version for everyone in the organisation.`**
5. Put the two side by side. They should not read like edits of each other.
6. Type: **`Now the version for our customers.`**
7. Look for a line reading **No date agreed** or **No owner identified**. Note where it is.
8. Open your Drafts folder. Confirm the messages are there and none has been sent.

## What good looks like

- A subject line stating the conclusion, not the topic.
- Three genuinely different versions from one set of facts.
- Anything unknown named as unknown, rather than filled in.
- Everything in Drafts. Nothing sent.

## Discuss

- The line reading "No date agreed" — is that a gap in the tool, or a gap in the decision?
- Which version would have caused you a problem if it had gone to the wrong audience?

---

# Lab 7 — It runs without you

**Skill:** `exec-autopilot-triggers` · **30 minutes** · **this whole lab is an automation**

## Business case

Everything so far has been you asking and Cowork answering. That still requires you to
remember to ask. This lab removes that: work that arrives on a schedule, and work that
reacts the moment something happens — while you are asleep, travelling, or in a board
meeting.

## The distinction this lab exists to teach

| | Normal activity | Automation |
|---|---|---|
| **Starts** | When you ask | On a time, or when something happens |
| **You are** | Present | Absent |
| **Runs** | Once | Until you stop it |
| **Can send?** | Yes, if you say so in the moment | **Never.** It drafts and waits |

The third row is why automations are worth setting up. The fourth is why they are safe.

## What the skill connects to

- Your email, calendar and Teams, to know what recurs and who matters
- Your existing scheduled tasks, automated rules and away settings
- Anything the automated task itself will read when it runs

## Before you start

No demo file needed. Decide two things in advance:

- **One thing you want on a schedule** — for example your Monday briefing.
- **One person or topic worth interrupting you for** — a named colleague, a top customer,
  a regulator.

## Steps

1. Open `01-Skills/Executive/exec-autopilot-triggers/SKILL.md`. Read **Purpose**,
   **Workflow** and **Guardrails**.
2. Open `01-Skills/Executive/_shared/automation-patterns.md`. Read section 1 — the table
   that decides which mechanism fits which job.
3. In Cowork, type: **`What have you got running for me already?`**
4. Type: **`I want my executive briefing ready at 7am every Monday.`**
5. **Read the instruction it proposes back to you before confirming.** Check it names the
   day, the time, your time zone, what it produces, and that it will draft rather than send.
6. Confirm it.
7. Type: **`Tell me whenever [named person or topic] emails me.`**
8. Check the condition it proposes is narrow enough. If it would fire ten times a day, say
   so and ask it to narrow the condition.
9. Confirm it.
10. Type: **`Show me everything you have running for me now.`**
11. Type: **`Turn off the second one.`**
12. Confirm it is gone.

## What good looks like

- A written-out instruction you can read and understand before anything is installed.
- A time zone stated explicitly.
- A trigger condition narrow enough to be useful rather than noisy.
- A list you can see on demand, and something removed from it in seconds.

## Discuss

- Step 5 read the instruction back to you. Why does an unattended task need to spell out
  things you would never say to a person — the time zone, the exact accounts, what to do
  if a source is unreachable?
- What would you want interrupting you for, and what definitely not?
- **Nothing you installed can send.** Does that change what you would be willing to
  automate?

### Facilitator note

Have every attendee remove any trigger created in this lab before leaving the room. The
removal is part of the lesson.

---

# Lab 8 — Build your own

**Skill:** `skill-creator` · **30 minutes**

## Business case

The seventeen skills in this pack were built by someone who had the same problem twice.
The task you personally dread is the one worth turning into a skill, and nobody else can
identify it for you.

## What the skill connects to

- How you have asked for this work before, in your own words
- Existing skills, to check the new one does not collide with them

## Before you start

No demo file needed. Think of one recurring task you dread. The best candidates are
monthly or weekly, take over an hour, and follow roughly the same shape each time.

## Steps

1. Open `01-Skills/skill-creator/SKILL.md`. Read **Overview** and **Core Instructions**.
2. Open `01-Skills/README.md`. Read the **Conventions** list at the end — the eight rules
   every skill in this pack follows.
3. Write four things on paper, in your own words:
   - What it does, in one sentence.
   - Three phrases you would actually say to ask for it.
   - When it should **not** be used.
   - The one thing it must never do.
4. In Cowork, type: **`Turn this into a skill: [describe your task].`** Then give it the
   four things you wrote.
5. Read the skill it produces. Check the trigger phrases are ones you would genuinely say.
6. Type: **`Give me three prompts that should trigger this and two that should not.`**
7. Test one of the prompts that **should not** trigger it. Confirm it does not.
8. Save the skill into your Cowork skills folder.

## What good looks like

- Trigger phrases in your language, not a formal description of the task.
- A clear statement of when not to use it, pointing at another skill.
- Guardrails including at minimum: never invent facts, never send without asking.
- A prompt that correctly does **not** trigger it.

## Discuss

- What made you choose that task over the others you dread?
- Step 7 checked it does **not** fire. Why does that matter as much as the ones that do?

---

# Close

Before you leave:

1. Confirm you have at least one automation running that you want to keep.
2. Remove any test triggers from Lab 7.
3. Confirm your own skill from Lab 8 is saved in `Documents/Cowork/skills/`.
4. Note one task you will bring back for a second wave.

## Quick reference — what triggers what

| Say this | Get this |
|---|---|
| "Prepare my executive briefing" | `monday-morning-exec-briefing` |
| "Where did my week go?" | `exec-calendar-defence` |
| "Which accounts are at risk?" | `customer-health-review` |
| "Get the board numbers out of Power BI" | `board-metrics-from-powerbi` |
| "Check this against our house style" | `brand-consistency` |
| "Write an update for leadership" | `exec-stakeholder-update` |
| "Tell me whenever X happens" | `exec-autopilot-triggers` |
| "Turn this into a skill" | `skill-creator` |
| "What have you got running for me?" | `exec-autopilot-triggers` |
