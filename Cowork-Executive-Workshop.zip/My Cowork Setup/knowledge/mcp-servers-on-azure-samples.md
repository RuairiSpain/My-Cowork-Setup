# MCP servers on Azure — code and configuration

Updated 2026-09-20 · Confidence: high · Companion to [mcp-servers-on-azure.md](mcp-servers-on-azure.md)

Every block below is reproduced as published on Microsoft Learn. Sources and
last-updated dates are at the bottom.

## 1. Microsoft Learn MCP Server client config

Endpoint `https://learn.microsoft.com/api/mcp` — streamable HTTP, no auth, free.
(Learn MCP developer reference, 2025-12-03)

```json
{
  "microsoft.docs.mcp": {
    "type": "http",
    "url": "https://learn.microsoft.com/api/mcp"
  }
}
```

Tools: `microsoft_docs_search` (query), `microsoft_docs_fetch` (url),
`microsoft_code_sample_search` (query, optional language).
Call `list_tools` on every initialization — the surface may change.
Experimental: `?maxTokenBudget=2000` truncates search responses;
`https://learn.microsoft.com/api/mcp/openai-compatible` for Deep Research models.

## 2. Azure Functions — host a remote MCP server

(Tutorial: Host an MCP server on Azure Functions, 2026-06-03)

Local storage setting in `local.settings.json`:
`"AzureWebJobsStorage": "UseDevelopmentStorage=true"`

Self-hosted (MCP SDK) servers need the preview feature flag:

```shell
az functionapp config appsettings set --name <function-app-name> \
  --resource-group <resource-group-name> \
  --settings "AzureWebJobsFeatureFlags=EnableMcpCustomHandlerPreview"
```

Python self-hosted apps also need `PYTHONPATH=/home/site/wwwroot/.python_packages/lib/site-packages`.

Get the server domain:

```shell
az functionapp show --name <FUNCTION_APP_NAME> --resource-group <RESOURCE_GROUP_NAME> \
  --query "defaultHostName" --output tsv
```

Client URLs: MCP extension server →
`https://<FUNCTION_APP_NAME>.azurewebsites.net/runtime/webhooks/mcp`;
self-hosted server → `https://<FUNCTION_APP_NAME>.azurewebsites.net/mcp`.

`.vscode/mcp.json` with key-based auth:

```json
{
  "servers": {
    "remote-mcp-server": {
      "type": "http",
      "url": "https://${input:functionapp-domain}/runtime/webhooks/mcp",
      "headers": { "x-functions-key": "${input:functions-key}" }
    }
  },
  "inputs": [
    { "type": "promptString", "id": "functions-key",
      "description": "Functions App Key", "password": true },
    { "type": "promptString", "id": "functionapp-domain",
      "description": "The domain of the function app.", "password": false }
  ]
}
```

Keys live in the portal under Functions → App keys: system key `mcp_extension`
(MCP extension server) or host key `default` (self-hosted).

Disable key auth before enabling built-in OAuth:

```shell
# MCP extension server
az functionapp config appsettings set --name <APP_NAME> --resource-group <RESOURCE_GROUP> \
  --settings "AzureFunctionsJobHost__extensions__mcp__system__webhookAuthorizationLevel=Anonymous"

# Self-hosted server
az functionapp config appsettings set --name <APP_NAME> --resource-group <RESOURCE_GROUP> \
  --settings "AzureFunctionsJobHost__customHandler__http__DefaultAuthorizationLevel=anonymous"
```

(Equivalent to `system.webhookAuthorizationLevel` / `http.DefaultAuthorizationLevel`
in `host.json`, but without republishing.)

Protected resource metadata (preview):

```shell
az functionapp config appsettings set --name <function-app-name> \
  --resource-group <resource-group-name> \
  --settings "WEBSITE_AUTH_PRM_DEFAULT_WITH_SCOPES=<scope>"
```

Manual Entra setup: add identity provider Microsoft → new single-tenant app
registration; under Additional checks allow only specific client applications and
add the VS Code client ID **`aebc6443-996d-45c2-90f0-388ff96faa56`**; App Service
auth = Require authentication, unauthenticated requests → HTTP 401, token store on.
Preauthorize the same client ID under Expose an API, scope
`api://<app-id>/user_impersonation`.

.NET MCP extension tool (NuGet `Microsoft.Azure.Functions.Worker.Extensions.Mcp`,
`builder.EnableMcpToolMetaData()` in `Program.cs`) — pattern from the .NET blog
sample, 2025-04-16:

```csharp
[Function(nameof(SaveSnippet))]
[BlobOutput(BlobPath)]
public string SaveSnippet(
    [McpToolTrigger(SaveSnippetToolName, SaveSnippetToolDescription)] ToolInvocationContext context,
    [McpToolProperty(SnippetNamePropertyName, PropertyType, SnippetNamePropertyDescription)] string name,
    [McpToolProperty(SnippetPropertyName, PropertyType, SnippetPropertyDescription)] string snippet)
{
    return snippet;
}
```

## 3. Azure API Management — expose and govern

Portal path: APIs → MCP Servers → + Create MCP server → Expose an API as an MCP
server. Endpoint shape:
`https://<apim-service-name>.azure-api.net/<api-name>-mcp/mcp`.
(Expose REST API as MCP server, 2026-04-30)

Inbound policy — rate limit plus a custom trace:

```xml
<inbound>
  <base />
  <rate-limit-by-key calls="5" renewal-period="30"
      counter-key="@(context.Request.IpAddress)"
      remaining-calls-variable-name="remainingCallsPerIP" />
  <trace source="My MCP" severity="information">
    <message>My MCP trace info</message>
    <metadata name="agent-id" value="@(context.Request.Headers.GetValueOrDefault(&quot;agent-id&quot;, &quot;n/a&quot;))" />
</inbound>
```

Global-scope policies evaluate before MCP-server-scope policies.

Subscription-key client config (Secure access to MCP servers, 2026-09-11):

```json
{
  "name": "My MCP Server",
  "type": "remote",
  "url": "https://my-api-management-instance.azure-api.net/my-mcp-server",
  "transport": "streamable-http",
  "headers": { "Ocp-Apim-Subscription-Key": "<subscription-key>" }
}
```

Entra token validation:

```xml
<validate-azure-ad-token tenant-id="your-entra-tenant-id" header-name="Authorization"
    failed-validation-httpcode="401"
    failed-validation-error-message="Unauthorized. Access token is missing or invalid.">
  <client-application-ids>
    <application-id>your-client-application-id</application-id>
  </client-application-ids>
</validate-azure-ad-token>
```

Forward the caller token to the backend:

```xml
<set-header name="Authorization" exists-action="override">
  <value>@(context.Request.Headers.GetValueOrDefault("Authorization"))</value>
</set-header>
```

Outbound OAuth via credential manager:

```xml
<get-authorization-context provider-id="your-credential-provider-id" authorization-id="auth-01"
    context-variable-name="auth-context" identity-type="managed" ignore-error="false" />
<set-header name="Authorization" exists-action="override">
  <value>@("Bearer " + ((Authorization)context.Variables.GetValueOrDefault("auth-context"))?.AccessToken)</value>
</set-header>
```

Troubleshooting (from the same page): 401 from backend → Authorization header not
forwarded, add `set-header`. Works in APIM but fails in the agent → wrong base URL
or missing token. Streaming fails with diagnostics on → disable response-body
logging at All APIs scope.

## 4. Microsoft Foundry agents — MCP tool

(Connect agents to Model Context Protocol servers, 2026-08-26)

Tool fields: `server_url`, `server_label` (unique per agent), `allowed_tools`
(optional allow list), `require_approval` (`always` default | `never` |
`{"never":[tool,…]}` | `{"always":[tool,…]}`), `project_connection_id`.

Python — prompt agent with an MCP tool and approval handling:

```python
from azure.identity import DefaultAzureCredential
from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import PromptAgentDefinition, MCPTool
from openai.types.responses.response_input_param import McpApprovalResponse, ResponseInputParam

PROJECT_ENDPOINT = "your_project_endpoint"
MCP_CONNECTION_NAME = "my-mcp-connection"

project = AIProjectClient(endpoint=PROJECT_ENDPOINT, credential=DefaultAzureCredential())
openai = project.get_openai_client()

tool = MCPTool(
    server_label="api-specs",
    server_url="https://api.githubcopilot.com/mcp",
    require_approval="always",
    project_connection_id=MCP_CONNECTION_NAME,
)

agent = project.agents.create_version(
    agent_name="MyAgent7",
    definition=PromptAgentDefinition(
        model="gpt-5-mini",
        instructions="Use MCP tools as needed",
        tools=[tool],
    ),
)
```

Approval round-trip: a response output item of type `mcp_approval_request` is
answered with `McpApprovalResponse(type="mcp_approval_response", approve=…,
approval_request_id=item.id)` sent via `openai.responses.create(input=input_list,
previous_response_id=response.id, …)`.

Background mode for long-running tools:

```python
response = openai.responses.create(
    extra_body={"agent_reference": {"name": AGENT_NAME, "type": "agent_reference"}},
    input="Run the long-running task and summarize the result.",
    background=True,
)
while response.status in ("queued", "in_progress"):
    sleep(5)
    response = openai.responses.retrieve(response.id)
```

Toolbox connections (`azd ai`), auth variants:

```bash
PROJECT_ENDPOINT="https://<account>.services.ai.azure.com/api/projects/<project>"
azd ai project set $PROJECT_ENDPOINT

# No auth — public MCP server (e.g. Microsoft Learn)
azd ai connection create my-mcp-conn --kind remote-tool \
  --target https://learn.microsoft.com/api/mcp --auth-type none

# Custom header (e.g. GitHub PAT)
azd ai connection create my-mcp-conn --kind remote-tool \
  --target https://api.githubcopilot.com/mcp/ --auth-type custom-keys \
  --custom-key "Authorization=******"

# OAuth — Foundry-managed app
azd ai connection create my-mcp-conn --kind remote-tool \
  --target https://api.githubcopilot.com/mcp --auth-type oauth2 \
  --connector-name foundrygithubmcp

# Project managed identity
azd ai connection create my-mcp-conn --kind remote-tool \
  --target https://<resource>.cognitiveservices.azure.com/language/mcp \
  --auth-type project-managed-identity --audience https://cognitiveservices.azure.com
```

Other `--auth-type` values: `user-entra-token` (with `--audience`),
`agentic-identity`, and `oauth2` with your own app registration
(`--authorization-url --token-url --client-id --client-secret --scopes`).
Foundry-managed OAuth connector names include `foundrydatabricksmcp`,
`foundrygithubmcp`, `foundryinfobipmcp`, `foundrylsegmcp`, `foundrymorningstarmcp`,
`foundryneonmcp`, `foundrypipedreammcp`, `foundryvercelmcp`.

Toolbox YAML and creation:

```yaml
description: MCP server tools
connections:
  - name: my-mcp-conn
```

```bash
azd ai toolbox create my-toolbox --from-file my-toolbox.yaml
```

Toolbox MCP endpoints: production
`{project_endpoint}/toolboxes/{name}/mcp?api-version=v1`; version-pinned
`{project_endpoint}/toolboxes/{name}/versions/{version}/mcp?api-version=v1`.

First OAuth call returns a consent error — expected, open the URL once:

```json
{ "error": { "code": -32006, "message": "User consent is required. Please visit: https://..." } }
```

Private MCP: Azure Container Apps with internal-only ingress
(`--internal-only true`) on a dedicated MCP subnet delegated to
`Microsoft.App/environments`; requires Standard agent setup with BYO VNet.

## Sources

| Page | URL | Last updated |
|---|---|---|
| Microsoft Learn MCP Server overview | learn.microsoft.com/training/support/mcp | 2026-05-22 |
| Microsoft Learn MCP Server developer reference | learn.microsoft.com/training/support/mcp-developer-reference | 2025-12-03 |
| Tutorial: Host an MCP server on Azure Functions | learn.microsoft.com/azure/azure-functions/functions-mcp-tutorial | 2026-06-03 |
| Overview of MCP servers in Azure API Management | learn.microsoft.com/azure/api-management/mcp-server-overview | 2026-09-11 |
| Expose REST API as MCP server (APIM) | learn.microsoft.com/azure/api-management/export-rest-mcp-server | 2026-04-30 |
| Secure access to MCP servers in APIM | learn.microsoft.com/azure/api-management/secure-mcp-servers | 2026-09-11 |
| Connect agents to MCP servers (Foundry) | learn.microsoft.com/azure/foundry/agents/how-to/tools/model-context-protocol | 2026-08-26 |
| Build MCP Remote Servers with Azure Functions (.NET Blog — the C# trigger sample) | devblogs.microsoft.com/dotnet/build-mcp-remote-servers-with-azure-functions/ | 2025-04-16 |

All pages accessed 2026-09-20.
