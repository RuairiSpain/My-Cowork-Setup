# Knowledge base

Last updated: 2026-09-20

## Topics

- [mcp-servers-on-azure.md](mcp-servers-on-azure.md) — What is true about building
  and governing remote MCP servers on Azure: transports, Functions hosting, API
  Management, Foundry agent MCP tool, gotchas. Updated 2026-09-20.
- [mcp-servers-on-azure-samples.md](mcp-servers-on-azure-samples.md) — Verbatim
  code and configuration for the above: Learn MCP client JSON, Functions app
  settings and `mcp.json`, APIM policy XML, Foundry Python/`azd ai` samples.
  Updated 2026-09-20.
- [foundry-hosted-agents.md](foundry-hosted-agents.md) — Containerised agents on
  Foundry Agent Service: protocols, session/isolation model, versioning, sandbox
  sizes, permissions, gotchas. Updated 2026-09-20.
- [foundry-hosted-agents-samples.md](foundry-hosted-agents-samples.md) — Verbatim
  code for the above: C#/Python hosts, azd commands, azure.yaml connection
  placeholders, REST management, endpoint shapes, error codes. Updated 2026-09-20.

## Open questions

- Whether Azure Function Apps or App Service work as *private* MCP hosts for
  Foundry agents — Learn says they "might work but aren't internally validated".
  [unverified]
- Whether the Agent Framework hosting page ships a GA Go hosting package — the
  language selector lists Go, but its samples were not retrieved. [unverified]
