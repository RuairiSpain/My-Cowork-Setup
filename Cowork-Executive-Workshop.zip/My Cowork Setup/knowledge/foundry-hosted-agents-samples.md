# Foundry hosted agents — code and configuration

Updated 2026-09-20 · Confidence: high

Verbatim samples for [foundry-hosted-agents.md](foundry-hosted-agents.md). All
reproduced as published on Microsoft Learn; pages and dates listed at the bottom.

## Install (Agent Framework hosting page, 2026-09-03)

.NET CLI:

```
dotnet add package Microsoft.Agents.AI.Foundry.Hosting --prerelease
dotnet add package Azure.AI.Projects --prerelease
```

Python 3.10 or later:

```
pip install --pre agent-framework-foundry agent-framework-foundry-hosting azure-identity
```

Azure Developer CLI extension:

```
azd ext install azure.ai.agents
```

Note: the quickstart page uses a different extension id — `azd ext install
microsoft.foundry` with azd 1.27.1 or later. The two pages differ; check which
applies to your azd version.

## Responses protocol host — C# (Agent Framework hosting page)

```csharp
using Azure.AI.AgentServer.Core;
using Azure.AI.Projects;
using Azure.Identity;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Foundry.Hosting;

var projectEndpoint = new Uri(Environment.GetEnvironmentVariable("FOUNDRY_PROJECT_ENDPOINT") ?? throw new InvalidOperationException("FOUNDRY_PROJECT_ENDPOINT is not set."));
var deployment = Environment.GetEnvironmentVariable("AZURE_AI_MODEL_DEPLOYMENT_NAME") ?? "gpt-4o";

AIAgent agent = new AIProjectClient(projectEndpoint, new DefaultAzureCredential())
    .AsAIAgent(
        model: deployment,
        instructions: "You are a helpful AI assistant.",
        name: "my-agent");

var builder = AgentHost.CreateBuilder(args);
builder.Services.AddFoundryResponses(agent);
builder.RegisterProtocol("responses", endpoints => endpoints.MapFoundryResponses());
var app = builder.Build();
app.Run();
```

## Invocations protocol host — C# (Agent Framework hosting page)

```csharp
using Azure.AI.AgentServer.Core;
using Azure.AI.AgentServer.Invocations;
using Microsoft.Agents.AI;

var builder = AgentHost.CreateBuilder(args);

builder.Services.AddSingleton<AIAgent, MyAgent>();
builder.Services.AddInvocationsServer();
builder.Services.AddScoped<InvocationHandler, MyInvocationHandler>();

builder.RegisterProtocol("invocations", endpoints => endpoints.MapInvocationsServer());
var app = builder.Build();
app.Run();
```

## Responses handler — Python (deploy page, 2026-09-11)

```python
from azure.ai.agentserver.responses import (
    CreateResponse,
    ResponseContext,
    ResponsesAgentServerHost,
    TextResponse,
)

app = ResponsesAgentServerHost()

@app.response_handler
async def handler(
    request: CreateResponse,
    context: ResponseContext,
    _cancellation_signal,
):
    user_input = await context.get_input_text() or ""
    return TextResponse(context, request, text=f"Echo: {user_input}")
```

## Local run and invoke (Agent Framework hosting page)

```bash
mkdir my-hosted-agent && cd my-hosted-agent
azd ai agent init -m <path-to-agent.manifest.yaml>

export FOUNDRY_PROJECT_ENDPOINT="https://<account>.services.ai.azure.com/api/projects/<project>"
export AZURE_AI_MODEL_DEPLOYMENT_NAME="<your-model-deployment>"

azd ai agent run
azd ai agent invoke --local "Hello!"
```

Agent host starts on `http://localhost:8088`.

```bash
curl -X POST http://localhost:8088/responses \
  -H "Content-Type: application/json" \
  -d '{"input": "Hello!"}'
```

PowerShell equivalent:

```powershell
(Invoke-WebRequest -Uri http://localhost:8088/responses -Method POST -ContentType "application/json" -Body '{"input": "Hello!"}').Content
```

Local protocol tests (deploy page):

```http
POST http://localhost:8088/responses
Content-Type: application/json

{ "input": "Where is Seattle?", "stream": false }
```

```http
POST http://localhost:8088/invocations
Content-Type: application/json

{ "message": "Hello!" }
```

## Deploy (Agent Framework hosting + deploy pages)

```bash
azd provision
azd deploy
```

Or both at once: `azd up`. Verify with `azd ai agent show`. Live console logs:
`azd ai agent monitor`. Tear down: `azd down`.

## Quickstart scaffold (quickstart page, accessed 2026-09-20)

```bash
azd ext install microsoft.foundry
azd auth login
azd ai agent init -m "https://github.com/microsoft-foundry/foundry-samples/blob/main/samples/python/hosted-agents/agent-framework/responses/01-basic/azure.yaml" --deploy-mode code
cd agent-framework-agent-basic-responses
azd provision
azd ai agent run
```

## azure.yaml — connection placeholder for secrets (deploy page)

```yaml
services:
  my-agent:
    host: azure.ai.agent
    env:
      MODEL_DEPLOYMENT_NAME: gpt-5-mini
      GITHUB_TOKEN: ${{connections.agent-secrets.credentials.github_token}}
```

```python
import os
token = os.environ["GITHUB_TOKEN"]
```

Placeholder form is `${{connections.<name>.<path>}}` where `<path>` is
`credentials.<field>`, `target`, or `metadata.<field>`. For `ApiKey` and
`AppInsights` connections the field is always `key`; for `CustomKeys` it is the key
name you supplied. A GET on the version returns the literal `${{...}}` text.

## REST management (manage page, accessed 2026-09-20)

```bash
ACCOUNT_NAME="<your-foundry-account-name>"
PROJECT_NAME="<your-project-name>"
AGENT_NAME="<your-agent-name>"
BASE_URL="https://${ACCOUNT_NAME}.services.ai.azure.com/api/projects/${PROJECT_NAME}"
API_VERSION="v1"
RESOURCE="https://ai.azure.com"
```

`--resource` is required on every `az rest` call to Foundry data-plane endpoints.

```bash
az rest --method GET \
  --url "${BASE_URL}/agents?api-version=${API_VERSION}" \
  --resource "${RESOURCE}"
```

List versions including drafts (preview): add `&include_drafts=true`.

Create a new version:

```bash
az rest --method POST \
  --url "${BASE_URL}/agents/${AGENT_NAME}/versions?api-version=${API_VERSION}" \
  --resource "${RESOURCE}" \
  --body '{ "definition": { "kind": "hosted", "container_configuration": { "image": "myregistry.azurecr.io/my-agent:v2" }, "cpu": "1", "memory": "2Gi", "protocol_versions": [ {"protocol": "responses", "version": "1.0.0"} ] } }'
```

Token for direct HTTP (deploy page):

```bash
TOKEN=$(az account get-access-token --resource https://ai.azure.com --query accessToken -o tsv)
```

## Endpoint shapes (concepts page)

- Responses: `{project_endpoint}/agents/{name}/endpoint/protocols/openai/responses`
- Invocations: `{project_endpoint}/agents/{name}/endpoint/protocols/invocations`
- Invocations (WebSocket): `wss://{account}.services.ai.azure.com/api/projects/{project}/agents/{name}/endpoint/protocols/invocations_ws?api-version=v1`
- A2A: `{project_endpoint}/agents/{name}/endpoint/protocols/a2a`

Session binding (sessions page): Responses takes `agent_session_id` as a **request
body field** (or use `conversation`, which autobinds); Invocations takes it as a
**query parameter** `?agent_session_id=<id>`.

## Protocol libraries (deploy page)

| Protocol | Python package | .NET package | Endpoint |
|---|---|---|---|
| Responses | `azure-ai-agentserver-responses` | `Azure.AI.AgentServer.Responses` | `/responses` |
| Invocations | `azure-ai-agentserver-invocations` | `Azure.AI.AgentServer.Invocations` | `/invocations` |
| Invocations (WebSocket) | `azure-ai-agentserver-invocations` | `Azure.AI.AgentServer.Invocations` | `/invocations_ws` |

## Platform-injected environment variables (deploy page)

`FOUNDRY_PROJECT_ENDPOINT`, `FOUNDRY_PROJECT_ARM_ID`, `FOUNDRY_AGENT_NAME`,
`FOUNDRY_AGENT_VERSION`, `FOUNDRY_AGENT_SESSION_ID` (hosted containers only),
`APPLICATIONINSIGHTS_CONNECTION_STRING`.

## Deployment error codes (deploy page)

| Code | HTTP | Fix |
|---|---|---|
| `image_pull_failed` | 400 | Verify image URI; project MI needs Container Registry Repository Reader; ACR `azureADAuthenticationAsArmPolicy` must be enabled |
| `SubscriptionIsNotRegistered` | 400 | Register the subscription provider |
| `InvalidAcrPullCredentials` | 401 | Fix managed identity or registry RBAC |
| `UnauthorizedAcrPull` | 403 | Provide correct credentials or identity |
| `AcrImageNotFound` | 404 | Correct image name/tag or publish the image |
| `RegistryNotFound` | 400/404 | Fix registry DNS or network reachability |

## Gaps

- The deploy page's Python, .NET and JS/TS SDK tabs describe the steps but the
  fetched rendering did not include their full code blocks — Python/C#/TS
  `create_version` samples are **not captured here**. [unverified]
- No Dockerfile is published on the deploy page; only the linux/amd64 build flag.
- Go samples from the Agent Framework hosting page were not retrieved. [unverified]

## Sources

| Page | URL | Last updated |
|---|---|---|
| Foundry Hosted Agents (Agent Framework) | learn.microsoft.com/agent-framework/hosting/foundry-hosted-agent | 2026-09-03 |
| Deploy a hosted agent | learn.microsoft.com/azure/foundry/agents/how-to/deploy-hosted-agent | 2026-09-11 |
| Hosted agents in Foundry Agent Service | learn.microsoft.com/azure/foundry/agents/concepts/hosted-agents | 2026-09-11 |
| Manage hosted agents | learn.microsoft.com/azure/foundry/agents/how-to/manage-hosted-agent | accessed 2026-09-20 |
| Manage hosted agent sessions | learn.microsoft.com/azure/foundry/agents/how-to/manage-hosted-sessions | accessed 2026-09-20 |
| Quickstart: Deploy your first hosted agent | learn.microsoft.com/azure/foundry/agents/quickstarts/quickstart-hosted-agent | accessed 2026-09-20 |
