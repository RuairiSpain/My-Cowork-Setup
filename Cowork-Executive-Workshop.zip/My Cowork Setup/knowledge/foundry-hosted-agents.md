# Foundry hosted agents

Updated 2026-09-20 · Confidence: high

## What is true

- Hosted agents are containerised agentic apps on Foundry Agent Service: your own
  code as a container image, pushed to Azure Container Registry, pulled by the
  platform, given a dedicated Entra agent identity and a dedicated endpoint.
  (Microsoft Learn, "Hosted agents in Foundry Agent Service", last updated 2026-09-11)
- Microsoft Foundry Hosted Agents is **GA**. The Python
  `agent-framework-foundry-hosting` integration is **prerelease**.
  (Learn, "Foundry Hosted Agents", Agent Framework, last updated 2026-09-03)
- Isolation: "Hosted agents run in per-session VM-isolated sandboxes." Each session
  has a persistent `$HOME` and `/files`, restored on resume. (concepts page)
- Protocols: **Responses** (OpenAI-compatible `/responses`, platform-managed
  history/streaming/background), **Invocations** (arbitrary JSON, you own state),
  **Invocations (WebSocket)** (`/invocations_ws`, voice/bidirectional). Also
  Activity (Teams/M365 bridge, automatic from Responses) and A2A. One container can
  expose several. Learn's advice: "Not sure? Start with Responses." (concepts page)
- Language support: **Python and C# only** for the container. The JS/TS SDK is a
  deployment caller — "there's no Node.js Hosted agent runtime."
  (Learn, "Deploy a hosted agent", last updated 2026-09-11)
- Sandbox sizes: 0.5 vCPU/1 GiB, 1 vCPU/2 GiB, 2 vCPU/4 GiB. Disk budget up to
  20 GiB at ≥1 vCPU, ~20% reserved for system. (concepts page)
- Lifecycle: idle timeout configurable **2–60 min, default 15**; session state
  persisted on deprovision; **session permanently deleted after 30 days** of
  inactivity. Billing is CPU+memory across active sessions. (concepts page)
- Versions are immutable snapshots (image, CPU/memory, env vars, protocols). An
  endpoint serves **one version at a time**; traffic splitting is not supported.
  (concepts page)
- Permissions: **Foundry Project Manager** at project scope to deploy. The
  `Azure AI Developer` role "is insufficient for Hosted agent scenarios."
  (Learn, "Hosted agent permissions reference", last updated 2026-09-19)
- Region list includes **Spain Central**, West Europe, UK South/West. (concepts page)

## Gotchas

- Image must be **x86_64 (linux/amd64)** — build with `docker build --platform
  linux/amd64 .` on Apple Silicon. (deploy page)
- Private (network-secured) ACR only for Foundry projects created **after
  2026-06-25**; earlier projects need the registry reachable publicly. (deploy page)
- Containers serve on **port 8088** locally; in production the Foundry gateway
  routes, so no public port is needed. `/readiness` is provided by the protocol
  library. (deploy page)
- The `FOUNDRY_*` env prefix is reserved — don't redeclare platform-injected vars
  in `azure.yaml`. (deploy page)
- Reusing the same `agent_session_id` does **not** replay prior messages under
  Responses — threading comes from `previous_response_id` or a conversation ID.
  (Learn, "Manage hosted agent sessions")
- For Invocations, the platform reads `agent_session_id` **from the query string
  only**; body fields and `x-agent-session-id` headers pass through untouched.
  (sessions page)
- Foundry RBAC roles were renamed (Azure AI User → Foundry User, etc.); role IDs
  unchanged, old names still visible in places. (deploy page)
- Right-size from App Insights: if sustained peaks exceed ~70% of allocation, raise
  the next version; billing multiplies by concurrency. (concepts page)

## Not established

- Whether the Go tab of the Agent Framework hosting page carries a GA Go hosting
  package — the language selector lists Go, but I did not retrieve its samples.
  [unverified]
- Current pricing rates — Learn points to the Foundry pricing page without figures.
  [unverified]

## Sources

| Page | URL | Last updated |
|---|---|---|
| Hosted agents in Foundry Agent Service | learn.microsoft.com/azure/foundry/agents/concepts/hosted-agents | 2026-09-11 |
| Deploy a hosted agent | learn.microsoft.com/azure/foundry/agents/how-to/deploy-hosted-agent | 2026-09-11 |
| Foundry Hosted Agents (Agent Framework) | learn.microsoft.com/agent-framework/hosting/foundry-hosted-agent | 2026-09-03 |
| Hosted agent permissions reference | learn.microsoft.com/azure/foundry/agents/concepts/hosted-agent-permissions | 2026-09-19 |
| Manage hosted agents | learn.microsoft.com/azure/foundry/agents/how-to/manage-hosted-agent | accessed 2026-09-20 |
| Manage hosted agent sessions | learn.microsoft.com/azure/foundry/agents/how-to/manage-hosted-sessions | accessed 2026-09-20 |
| Quotas, limits and regions | learn.microsoft.com/azure/foundry/agents/concepts/limits-quotas-regions | accessed 2026-09-20 |

Code and configuration: see
[foundry-hosted-agents-samples.md](foundry-hosted-agents-samples.md).
