# MCP servers on Azure

Updated 2026-09-20 · Confidence: high · Code and config: [mcp-servers-on-azure-samples.md](mcp-servers-on-azure-samples.md)

## What is true

- MCP is JSON-RPC 2.0. Remote servers use Streamable HTTP at `/mcp`; the older
  HTTP+SSE transport (`/sse` + `/messages`, protocol 2024-11-05) is deprecated.
  (Microsoft Learn, "Overview of MCP servers in Azure API Management", updated 2026-09-11)
- **Microsoft Learn MCP Server**: `https://learn.microsoft.com/api/mcp`, streamable
  HTTP, no auth, free. Tools: `microsoft_docs_search`, `microsoft_docs_fetch`,
  `microsoft_code_sample_search`. Browser access returns 405.
  (Learn, "Microsoft Learn MCP Server developer reference", updated 2025-12-03)
- **Azure Functions** hosts remote MCP servers two ways: the MCP extension
  (trigger-based, all Functions languages, GA) and self-hosted MCP-SDK servers as
  custom handlers (**preview**, C#/Python/TypeScript only).
  (Learn, "Tutorial: Host an MCP server on Azure Functions", updated 2026-06-03)
- **API Management** exposes a managed REST API as an MCP server, or fronts an
  existing MCP server, on Developer/Basic/Standard/Premium and the v2 tiers.
  (Learn, "Overview of MCP servers in Azure API Management", updated 2026-09-11)
- **Foundry Agent Service** attaches a remote MCP endpoint as an `mcp` tool
  (`server_url`, `server_label`, `allowed_tools`, `require_approval`,
  `project_connection_id`); `require_approval` defaults to `always`.
  (Learn, "Connect agents to Model Context Protocol servers", updated 2026-08-26)

## Gotchas

- APIM supports MCP **tools only** — no resources, no prompts — and not in workspaces.
- Never touch `context.Response.Body` in an MCP server policy, and set Frontend
  Response payload bytes to 0 at All APIs scope: both buffer the response and
  break MCP streaming.
- Foundry non-streaming MCP tool calls time out at **100 seconds**; use background
  mode (gpt-5.4/5.5) for longer work.
- Functions endpoint path differs by hosting mode: MCP extension =
  `/runtime/webhooks/mcp`, self-hosted = `/mcp`.
- One-click built-in MCP auth in the portal turns key-based access off.
- MCP Inspector against APIM: use version 0.9.0.
- Treat tool descriptions and results from third-party MCP servers as untrusted
  input — indirect prompt injection is the documented risk.

## Not established

- Whether Function Apps / App Service work as *private* MCP hosts for Foundry —
  Learn says they "might work but aren't internally validated". [unverified]

## Changelog

- 2026-09-20 First capture.
