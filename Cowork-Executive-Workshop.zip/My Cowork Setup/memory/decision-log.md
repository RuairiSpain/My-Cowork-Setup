# Decision Log

Decisions taken, with rationale and rejected alternatives. Append-only, newest at the end.

Entry shape:
## YYYY-MM-DD — Decision title
- **Decision:** what was chosen
- **Rationale:** why
- **Alternatives rejected:** what was considered and why not
