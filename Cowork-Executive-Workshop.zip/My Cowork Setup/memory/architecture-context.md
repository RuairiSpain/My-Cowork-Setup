# Architecture Context

Durable facts about how systems are built and run: architecture, tech stack, integration
patterns, environments, repos and services. Append-only, newest at the end.
