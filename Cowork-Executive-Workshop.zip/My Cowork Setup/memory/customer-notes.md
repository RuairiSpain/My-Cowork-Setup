# Customer Notes

Customer and account context: organisations, stakeholders, roles, preferences and engagement
history. Append-only, newest at the end. No credentials or sensitive personal data.
