# Requirements

Stated requirements, constraints and acceptance criteria. Append-only, newest at the end.
Mark each as [open] or [met]; compaction may never drop an [open] item.
