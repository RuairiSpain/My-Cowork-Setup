# Wasted Tokens — dead ends and failed approaches

Things that were tried and did NOT work, so a future session does not repeat them.
Append-only, newest at the end.

Entry shape:
## YYYY-MM-DD — What was attempted
- **Tried:** the approach
- **Failed because:** the reason
- **Do instead:** the approach that worked, if known
