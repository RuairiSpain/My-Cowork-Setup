#!/usr/bin/env python3
"""Character / token statistics for the session-memory files.

Reads the five memory files from the (read-only) user-config mount and reports
characters, token count and last-updated date per file, plus a TOTAL row.

Token counts use tiktoken when it is importable; otherwise they fall back to
characters / 4 (rounded) and `estimated` is true in the JSON output.

Usage:
    python memory_stats.py [--json] [--dir /mnt/user-config/memory]
                           [--before before.json --after after.json]

`--before/--after` compares two saved runs and emits compaction savings.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

MEMORY_FILES = [
    "architecture-context.md",
    "customer-notes.md",
    "decision-log.md",
    "requirements.md",
    "wasted-tokens.md",
]

DEFAULT_DIR = "/mnt/user-config/memory"
DATE_RE = re.compile(r"^##\s+(\d{4}-\d{2}-\d{2})", re.MULTILINE)


def _encoder():
    try:
        import tiktoken  # type: ignore

        return tiktoken.get_encoding("cl100k_base")
    except Exception:
        return None


def count_tokens(text: str, enc) -> tuple[int, bool]:
    if enc is not None:
        try:
            return len(enc.encode(text)), False
        except Exception:
            pass
    return round(len(text) / 4), True


def last_updated(text: str, path: str) -> str:
    dates = DATE_RE.findall(text)
    if dates:
        return max(dates)
    try:
        import datetime

        return datetime.date.fromtimestamp(os.path.getmtime(path)).isoformat()
    except Exception:
        return "-"


def collect(directory: str) -> dict:
    enc = _encoder()
    estimated_any = False
    rows = []
    for name in MEMORY_FILES:
        path = os.path.join(directory, name)
        if not os.path.isfile(path):
            rows.append(
                {
                    "file": name,
                    "path": path,
                    "exists": False,
                    "characters": 0,
                    "tokens": 0,
                    "entries": 0,
                    "last_updated": "-",
                }
            )
            continue
        with open(path, "r", encoding="utf-8") as fh:
            text = fh.read()
        tokens, est = count_tokens(text, enc)
        estimated_any = estimated_any or est
        rows.append(
            {
                "file": name,
                "path": path,
                "exists": True,
                "characters": len(text),
                "tokens": tokens,
                "entries": len(DATE_RE.findall(text)),
                "last_updated": last_updated(text, path),
            }
        )
    return {
        "directory": directory,
        "tokenizer": "chars/4 (estimate)" if enc is None else "tiktoken cl100k_base",
        "estimated": estimated_any or enc is None,
        "files": rows,
        "total": {
            "characters": sum(r["characters"] for r in rows),
            "tokens": sum(r["tokens"] for r in rows),
            "entries": sum(r["entries"] for r in rows),
            "missing": sum(0 if r["exists"] else 1 for r in rows),
        },
    }


def savings(before: dict, after: dict) -> dict:
    idx = {r["file"]: r for r in after["files"]}
    rows = []
    for b in before["files"]:
        a = idx.get(b["file"], b)
        pct = 0.0
        if b["characters"]:
            pct = round((b["characters"] - a["characters"]) * 100.0 / b["characters"], 1)
        rows.append(
            {
                "file": b["file"],
                "before_characters": b["characters"],
                "before_tokens": b["tokens"],
                "after_characters": a["characters"],
                "after_tokens": a["tokens"],
                "saved_percent": pct,
            }
        )
    bt, at = before["total"]["characters"], after["total"]["characters"]
    return {
        "files": rows,
        "total": {
            "before_characters": bt,
            "before_tokens": before["total"]["tokens"],
            "after_characters": at,
            "after_tokens": after["total"]["tokens"],
            "saved_percent": round((bt - at) * 100.0 / bt, 1) if bt else 0.0,
        },
    }


def render(data: dict) -> str:
    lines = ["| File | Characters | Est. tokens | Entries | Last updated |",
             "|---|---|---|---|---|"]
    for r in data["files"]:
        name = r["file"] if r["exists"] else f"{r['file']} (missing)"
        lines.append(
            f"| {name} | {r['characters']:,} | {r['tokens']:,} | {r['entries']} | {r['last_updated']} |"
        )
    t = data["total"]
    lines.append(f"| **TOTAL** | **{t['characters']:,}** | **{t['tokens']:,}** | **{t['entries']}** | — |")
    lines.append("")
    lines.append(f"Token counts: {data['tokenizer']}.")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dir", default=DEFAULT_DIR, help="memory folder to inspect")
    ap.add_argument("--json", action="store_true", help="emit JSON")
    ap.add_argument("--before", help="saved JSON from a prior run")
    ap.add_argument("--after", help="saved JSON from a later run")
    args = ap.parse_args()

    if args.before and args.after:
        with open(args.before, encoding="utf-8") as fh:
            before = json.load(fh)
        with open(args.after, encoding="utf-8") as fh:
            after = json.load(fh)
        result = savings(before, after)
        print(json.dumps(result, indent=2))
        return 0

    data = collect(args.dir)
    if args.json:
        print(json.dumps(data, indent=2))
    else:
        print(render(data))
    return 0


if __name__ == "__main__":
    sys.exit(main())
