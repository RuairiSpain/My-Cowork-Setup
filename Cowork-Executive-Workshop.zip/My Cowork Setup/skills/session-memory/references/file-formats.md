# Memory file formats

Every memory file lives on the user surface at `memory/<name>.md` (mount path
`/mnt/user-config/memory/<name>.md`, read-only for writes). Each has a stable header that
Reset restores and Compact preserves, followed by append-only dated entries.

## Entry shape (all files)

```
## YYYY-MM-DD — Short title
- One fact, decision or constraint per bullet
- Keep bullets self-contained: a future session has no other context
```

Newest entries go at the **end** of the file. If a heading for today already exists, add bullets
under it rather than opening a second heading for the same date.

## Headers

### memory/architecture-context.md
```
# Architecture Context

Durable facts about how systems are built and run: architecture, tech stack, integration
patterns, environments, repos and services. Append-only, newest at the end.
```

### memory/customer-notes.md
```
# Customer Notes

Customer and account context: organisations, stakeholders, roles, preferences and engagement
history. Append-only, newest at the end. No credentials or sensitive personal data.
```

### memory/decision-log.md
```
# Decision Log

Decisions taken, with rationale and rejected alternatives. Append-only, newest at the end.

Entry shape:
## YYYY-MM-DD — Decision title
- **Decision:** what was chosen
- **Rationale:** why
- **Alternatives rejected:** what was considered and why not
```

### memory/requirements.md
```
# Requirements

Stated requirements, constraints and acceptance criteria. Append-only, newest at the end.
Mark each as [open] or [met]; Compact may never drop an [open] item.
```

### memory/wasted-tokens.md
```
# Wasted Tokens — dead ends and failed approaches

Things that were tried and did NOT work, so a future session does not repeat them.
Append-only, newest at the end.

Entry shape:
## YYYY-MM-DD — What was attempted
- **Tried:** the approach
- **Failed because:** the reason
- **Do instead:** the approach that worked, if known
```

## Compaction rules

- Merge duplicate or near-duplicate bullets into one, keeping the earliest date.
- Collapse a superseded decision chain to the final decision; keep the final date and a one-line
  note that it superseded earlier choices.
- Drop entries explicitly resolved, obsolete or scoped out.
- Never drop an `[open]` requirement or an undecided question.
- Never invent, infer or embellish a fact that is not in the source text.
- Keep every header verbatim.
