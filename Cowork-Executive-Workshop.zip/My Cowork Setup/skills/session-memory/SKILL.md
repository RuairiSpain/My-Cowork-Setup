---
name: session-memory
description: |
  Cross-session memory: persists architecture context, customer notes, decisions,
  requirements and dead ends as append-only dated entries in memory/*.md in the user
  folder, and reloads them at the start of a new session with character and token counts.
  Use when the user says "remember this", "save that to memory", "note this decision",
  "that was a waste of tokens", "show memory", "memory status", "compact memory" or
  "reset memory", and at session start to load memory. Also append proactively whenever a
  decision, requirement, architecture fact, customer fact or dead end is established.
  Do NOT use for drafting a notes document or knowledge article (use knowledge-note or the
  docx skill), for Outlook/OneNote content, or for creating and editing skills (use skills).
metadata:
  category: productivity
  icon: BrainCircuit
---

## Overview

Five markdown files in the user's cross-session folder hold durable working context so a new
session starts informed instead of blank. Storage is the **user surface** (`surface="user"`),
so the files survive session teardown and sync to OneDrive.

| File | Holds |
|---|---|
| `memory/architecture-context.md` | System/solution architecture, tech stack, integration patterns, environment facts, repo and service names |
| `memory/customer-notes.md` | Customer/account context, stakeholders, org details, preferences, engagement history |
| `memory/decision-log.md` | Decisions made, with date, decision, rationale, alternatives rejected |
| `memory/requirements.md` | Stated requirements, constraints, acceptance criteria, scope boundaries |
| `memory/wasted-tokens.md` | Dead ends, failed approaches, things that did NOT work, so future sessions don't repeat them |

Every file starts with a stable header and grows by **append-only dated entries**:

```
## 2026-09-27 — Short title
- Fact or decision, one bullet each
```

## When NOT to Use

- Drafting a notes document, briefing or knowledge article the user will read as a deliverable — use `knowledge-note` or the `docx` skill
- Storing secrets, credentials or tokens — never write those to memory files
- Creating, editing or scoring skills — use the `skills` skill
- Project task tracking with owners and due dates — use a tracker (`xlsx`), not memory

## Tooling

| Need | Use |
|---|---|
| Read a memory file | Read `/mnt/user-config/memory/<file>.md` (the mount is read-only but readable) |
| Create a missing file | `host-CreateArtifact(surface="user", path="memory/<file>.md", ...)` |
| Append or rewrite | `host-EditArtifact(surface="user", path="memory/<file>.md", patches=[...])` |
| Counts | `python scripts/memory_stats.py --json` — never eyeball char or token counts |
| Fallback read | `sharepoint_onedrive-ReadFileContent(web_url=".../Cowork/memory/<file>.md", mode="download")` when the mount has no `memory/` folder |
| Destructive confirm | `core-AskUserQuestion` |

`/mnt/user-config` is **read-only**: never `Write`, `cp`, `mkdir` or `rm` there. All writes go
through the artifact host tools with `surface="user"`, which are approval-gated — never report a
memory write as done until the tool returns success.

**Mount lag:** a `memory/` folder created during the *current* session may not appear under
`/mnt/user-config/` until the next session — the mount enumerates top-level folders at session
start. If `/mnt/user-config/memory/` is missing but the files exist in OneDrive (`Cowork/memory/`),
do **not** recreate them: download each with `sharepoint_onedrive-ReadFileContent(mode="download")`
into `working/memory/` and run the stats script with `--dir working/memory`. Only treat a file as
genuinely missing when neither the mount nor OneDrive has it.

`scripts/memory_stats.py` computes characters, tokens and last-updated date per file. It uses
`tiktoken` when available and falls back to `characters / 4` otherwise; the fallback is an
**estimate** and must be labelled as such in output.

---

## Operation 1: Load (session start)

**Triggers:** start of a new session (the user's personal instructions request it), "load memory",
"what's in memory", "catch me up".

1. Run `python scripts/memory_stats.py --json`. It lists all five files, creating nothing.
2. If the whole folder is reported missing, apply the **Mount lag** fallback above before concluding anything is absent. For each file genuinely missing, create it with its header via `host-CreateArtifact(surface="user", path="memory/<file>.md")` using the header template in [references/file-formats.md](references/file-formats.md), and report it as 0 / 0.
3. Read each existing file and hold its content as working context. Summarise internally — do **not** dump file bodies into chat on Load.
4. Print the status table, nothing else:

```
| File | Characters | Est. tokens | Last updated |
|---|---|---|---|
| architecture-context.md | 1,240 | 310 | 2026-09-20 |
| ... | ... | ... | ... |
| **TOTAL** | **4,905** | **1,226** | — |
```
5. Add one line: `Token counts are estimates (chars/4)` when tiktoken was unavailable, or `Token counts from tiktoken` when it was used.
6. Offer nothing further unless memory is empty, in which case say so in one line.

## Operation 2: Append / routing

**Triggers:** "remember this", "save that to memory", "note this decision", "that was a waste of
tokens", "add to memory", "log that requirement".

Also append **proactively, without being asked**, the moment a session establishes any of: a
decision, a requirement or constraint, an architecture or environment fact, a customer/stakeholder
fact, or a dead end that cost effort.

**Routing rules — choose exactly one file:**

| Route here | When the item is | Examples |
|---|---|---|
| `architecture-context.md` | A durable fact about how a system is built or runs | "Auth goes through Entra ID app reg X"; "the gateway is Python FastAPI on Container Apps" |
| `customer-notes.md` | A fact about a person, account or organisation | "Contoso's CTO is Anna; prefers one-page briefs"; "Fabrikam renewal is in March" |
| `decision-log.md` | A choice made between alternatives | "Chose Cosmos over SQL for the event store; rejected SQL on write cost" |
| `requirements.md` | Something that must be true of the outcome | "Must support 10k rps"; "reports must be en-GB" |
| `wasted-tokens.md` | Something that was tried and did NOT work | "Regex parsing of the manifest failed on nested blocks — use the JSON schema instead" |

**Tie-break, in order:** (1) a failed attempt always goes to `wasted-tokens.md`, even if it was
architectural; (2) a choice between named alternatives goes to `decision-log.md`, even if it is
also a requirement; (3) a fact about a person or org goes to `customer-notes.md`; (4) otherwise
architecture vs requirements — "how it is built" is architecture, "what it must achieve" is a
requirement. Never write the same item to two files.

**Steps:**
1. Classify with the table above.
2. Read the target file's current tail so the append does not duplicate an existing entry; if today's dated heading already exists, add bullets under it rather than creating a second heading. If the file does not exist (apply the **Mount lag** fallback before believing that), create it first with its header via `host-CreateArtifact(surface="user", path="memory/<file>.md")` using [references/file-formats.md](references/file-formats.md), then append.
3. Append with `host-EditArtifact(surface="user", path="memory/<file>.md", patches=[{"op":"replace_text","find":"<exact last line of the file>","replace":"<that line>\n\n## <YYYY-MM-DD> — <title>\n- <bullet>","count":1}])`. **Never rewrite the whole file on an append** and never remove existing content.
4. Confirm in exactly one line: `Saved to decision-log.md — "Chose Cosmos over SQL".`

## Operation 3: Show

**Triggers:** "show memory", "show me the memory files", "show decision log", "what's in
requirements".

1. Run `memory_stats.py --json` for counts.
2. Print the full content of the requested file, or of all five when unqualified, each under a heading with its characters and token count, e.g. `### decision-log.md — 1,240 chars / 310 tokens`.
3. Do not summarise or reformat the content; show it verbatim.

## Operation 4: Status

**Triggers:** "memory status", "how big is my memory", "memory counts".

Run `memory_stats.py --json` and print the same table as Load, step 4. **Counts only — no file
content, no summary.**

## Operation 5: Reset (destructive)

**Triggers:** "reset memory", "clear memory", "wipe the decision log", "start memory fresh".

1. Resolve the target: one named file, or all five.
2. **Confirm first** with `core-AskUserQuestion`, naming exactly which files will be cleared and their current character counts. Never infer consent from the trigger phrase alone.
3. On confirmation, for each target run `host-EditArtifact(surface="user", path="memory/<file>.md", patches=[{"op":"replace_text","find":"<entire current content>","replace":"<header only>","count":1}])`, leaving just the file's header.
4. Report which files were reset and that they are now 0 entries. If the user declines, say plainly that nothing was changed.

## Operation 6: Compact

**Triggers:** "compact memory", "compact the decision log", "memory is getting big", "tidy memory".

1. Record before-counts with `memory_stats.py --json`.
2. Read the target file(s). Rewrite shorter **without losing meaning**: merge duplicate or near-duplicate entries; collapse superseded decisions to the final decision only, dropping the churn; drop items explicitly resolved or no longer relevant; keep every date; keep the header.
3. **Never invent a fact, and never drop an unresolved requirement or an open decision.** If in doubt, keep it.
4. Write the compacted file with `host-EditArtifact` (full-content replace is correct here — compaction is the one operation that rewrites).
5. Record after-counts and report the savings table:

```
| File | Before (chars/tokens) | After (chars/tokens) | Saved |
|---|---|---|---|
| decision-log.md | 4,120 / 1,030 | 2,480 / 620 | 39.8% |
```
Compute the percentage with the script, never by eye. **Never finish a compaction without showing
the user this before/after table.**

## Output

Load and Status: a table only. Append: one confirmation line. Show: verbatim content with
per-file counts. Reset: a confirmation question, then a one-line result. Compact: a before/after
savings table. Never pad any of these with preamble.

## Guardrails

- `/mnt/user-config` is read-only — every write goes through `host-CreateArtifact` / `host-EditArtifact` / `host-DeleteArtifact` with `surface="user"`; report success only after the tool returns it.
- Appends are additive. Only Compact and Reset may rewrite a file, and Reset only after explicit confirmation.
- Never write credentials, secrets, tokens or personal data beyond ordinary business contact context into memory.
- Never fabricate memory content: if a file is missing or empty, say so rather than reconstructing it.
- Token counts are estimates unless tiktoken produced them — always label which.
- One item, one file. If an item seems to belong to two, apply the tie-break order and note the choice in the confirmation line.
