---
name: cowork-rollout
description: |
  Plans and guides a phased rollout of Microsoft Copilot Cowork inside a company — pilot group first, then broad
  deployment — covering restricted access groups, per-user and per-group usage limits, and usage analytics/reporting.
  Use when the user asks to "roll out Cowork", "deploy Cowork to my team", "plan a Cowork pilot", "set up a restricted
  group for Cowork", "limit Cowork usage per user", "set usage caps for a group", "report on Cowork adoption", or
  "show Cowork usage analytics". Produces a phased rollout plan, an access/licensing group design, a usage-limit
  policy table, and an adoption metrics plan. Always verifies current admin capabilities against official Microsoft
  documentation before recommending settings. Do NOT use for general Cowork how-to questions, for creating or editing
  personal skills (use the skills skill), or for building unrelated documents and decks.
cowork:
  category: research
  icon: RocketRegular
---

# Cowork Rollout Advisor

Guides an organisation from a small controlled pilot to a full deployment of Microsoft Copilot Cowork, with
governance (who can use it), guardrails (how much they can use), and measurement (what value it delivered).

## When NOT to Use

- General "how do I use Cowork" or feature questions — answer directly, no skill needed.
- Creating, editing, scoring or deleting personal skills — use the `skills` skill instead.
- Licensing procurement, contract negotiation, or pricing quotes — refer the user to their Microsoft account team.
- Generic change-management programmes not specific to Cowork.
- Producing a deck or document with no rollout planning — use `pptx` / `docx` directly.

## Workflow

1. **Establish the current facts — never rely on memory.** Admin surfaces for Cowork change frequently. Run
   `host-web_search` / `host-web_fetch` against official Microsoft Learn and Microsoft 365 admin documentation for
   the specific controls in scope (access groups, usage limits/quotas, reporting). Cite what you find. If a control
   cannot be confirmed in documentation, say so explicitly and mark it as **[Verify with admin docs]** rather than
   inventing a setting name or path.
2. **Scope the organisation.** Use `me_profile-GetMyDetails`, `me_profile-GetOrgTree`, and
   `me_profile-GetDirectReportsDetails` to size the pilot cohort and identify sponsors. Use
   `m365_search-SearchM365` to find any existing rollout, governance, or licensing material already in the tenant
   before writing anything new.
3. **Design the phases.** Default to three: Pilot (5–25 users, 2–4 weeks), Expansion (one or two departments),
   Broad (org-wide). For each phase capture: cohort, entry criteria, exit criteria, owner, duration, risks.
4. **Design restricted access.** Recommend security-group-based access (a dedicated group per phase), the
   licence/assignment model, and how membership is requested and approved. Name the group naming convention.
   Do not perform tenant writes — produce the design and the exact admin steps for an administrator to execute.
5. **Design usage limits.** Produce a table of per-user and per-group limits with a rationale for each: cohort,
   limit type, proposed value, enforcement point, review cadence. Where a limit is not natively enforceable,
   say so and propose a monitoring-plus-policy alternative instead of implying enforcement exists.
6. **Design analytics.** Define the adoption metrics (active users, weekly retention, tasks completed, top
   scenarios, consumption vs. limit), the source of each metric, the report owner, and the cadence. Prefer
   metrics that are actually obtainable from documented admin reporting; flag any metric that is not.
7. **Deliver.** Default output is inline markdown. Produce a `docx` when the user asks for a plan document or
   rollout guide, an `xlsx` when the deliverable is the limits/cohort table, and a `pptx` for a sponsor
   readout. Offer a `SetupScheduledPrompt` for a recurring adoption report only if the user asks for recurrence.

## Output Format

**Rollout Plan**
| Phase | Cohort | Size | Duration | Entry criteria | Exit criteria | Owner |

**Access Design** — group names, membership model, approval flow, admin steps (numbered).

**Usage Limits**
| Cohort | Limit type | Value | Enforcement | Review cadence | Rationale |

**Analytics Plan**
| Metric | Definition | Source | Cadence | Owner | Target |

**Open Questions / To Verify** — anything unconfirmed by documentation or tenant data.

## Guardrails

- **Never fabricate an admin setting, portal path, report name, licence SKU, or quota value.** Every specific
  either traces to a retrieved documentation source (cited) or is labelled **[Verify with admin docs]**.
- **Never make tenant configuration changes.** This skill produces designs and admin instructions only; group
  creation, licence assignment, and policy changes are performed by an administrator.
- Distinguish clearly between what the platform *enforces* and what is *policy plus monitoring*.
- Do not evaluate or rank individual employees' usage or performance; report cohort-level adoption only.
- Do not include named individuals' usage figures in shared reports without saying that consent/privacy review
  applies.
- State assumptions explicitly when tenant data is unavailable, rather than presenting estimates as facts.
