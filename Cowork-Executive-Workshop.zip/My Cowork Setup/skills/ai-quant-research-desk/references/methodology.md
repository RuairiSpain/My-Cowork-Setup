# Methodology: Repo, Records, Gates, Factors, Statistics

## Repository layout (`quant-research-lab/`)
```
quant-research-lab/
  AGENTS.md            # rules for any agent working here (research-only, gates, injection guard)
  README.md
  pyproject.toml       # pandas, numpy, pyarrow, pydantic, pytest, matplotlib, exchange_calendars; duckdb optional
  progress.md          # handoff file
  config/              # base currency, dates, cost grid, tolerances, User-Agent env name
  schemas/             # pydantic models (exported JSON Schema)
  manifests/
    sources/           # DataManifest per source + coverage_ledger.csv
    universes/         # UniverseManifest versions
    hypotheses/        # ExperimentSpec per hypothesis (frozen, versioned)
  registry/ledger.csv  # every trial, including failures
  src/qrlab/
    data/{ingest,identifiers,calendar,fx,validate}.py
    universe/{build,evidence,coverage}.py
    factors/{momentum,quality,investment_cycle}.py
    portfolio/{weights,returns,costs}.py
    validation/{splits,metrics,review}.py
    runner.py  registry.py  reporting.py
  tests/               # pytest hard gates
  data/raw/            # byte-for-byte archives + sha256 (not in git)
  data/normalized/     # parquet (not in git)
  runs/<run_id>/       # immutable: RunManifest, outputs, charts
  reports/<run_id>/    # report.md, checks.md
```

## Identity tables
- **issuer_master**: `issuer_id, legal_name, domicile, lei, cik, external_ids{}, parent_issuer_id, valid_from, valid_to, source_ref`.
- **listing_master**: `listing_id, issuer_id, ticker, exchange_mic, share_class, instrument_type
  (common|depositary_receipt|other), currency, calendar, active_from, active_to, figi,
  composite_figi, share_class_figi, adr_ratio, underlying_listing_id`.
- **issuer_listing_map** (dated): `issuer_id, listing_id, valid_from, valid_to, method, evidence_ref`.
  Unresolved → excluded from core and counted.
- Core = common shares + depositary receipts. Excluded: ETFs, funds, derivatives, tokenised
  assets, private firms. ADR + underlying = one issuer. Primary-listing rule frozen before testing.

## Evidence record (AI exposure)
`evidence_id, issuer_id, bucket (direct|supplier_enabler|watchlist_only|unknown), claim,
source_passage, source_url, document_type, document_period, published_at, known_at,
captured_at, segment, label_rule, reviewer, parent_link, source_sha256`.
No evidence → `unknown`; report the count of unknowns per bucket.

## Records (pydantic)
| Record | Key fields |
|---|---|
| DataManifest | source, endpoint, retrieved_at, vintage, licence, sha256, coverage, gaps |
| UniverseManifest | as_of, venues, rules, id_map_snapshot_hash, filters, delisting_treatment, vintages, exclusions, counts_per_step |
| ExperimentSpec | hypothesis_id, version, signal definition, window, universe ref, rebalance, weights, cost grid, splits, metrics, tolerance, frozen_at |
| RunManifest | run_id, spec ref+version, code git hash, data hashes, env (package versions), started/ended, status, outputs |
| ReviewResult | requirement, verdict (pass/blocked/not_reproduced/not_calculated), evidence_path, reviewer, notes |

**Result statuses**: `verified_reconstruction`, `not_reproduced`, `not_calculated`, `blocked` (+ reason).
**Registry states**: proposed → design_only → data_audited → implemented → challenged →
independently_reviewed → research_qualified / rejected / paper_research.
(`paper_research` means a documented research note — never paper trading.)
Every trial is logged; a formula change after seeing output = new ExperimentSpec version + ledger row.

## Hard-gate tests (pytest; any failure = blocked)
- `available_at <= decision_at` for every input row used in a signal
- No duplicate issuer in any portfolio on any date (ADR + underlying count once)
- Units and currency present on every price/fundamental value
- Source sha256 present on every raw file and evidence record
- Every listing in a portfolio resolves through `issuer_listing_map` on that date
- Returns computed only on executable sessions from the exchange calendar
- Cost-grid results recompute exactly from saved holdings
- French Mom reconstruction within the tolerance written in the spec **before** calculation
- Every ExperimentSpec used by a run is frozen (hash matches)

## Returns & timing
- Base currency USD, unhedged: `r_usd = (1 + r_local) * (1 + r_fx) − 1`.
- FX: ECB reference (16:00 CET), source and timestamp recorded.
- Decision time = month-end close per listing calendar; trades assumed at the **next
  executable session**.
- Splits: purged / grouped by date (embargo ≥ signal lookback overlap).

## Hypotheses (each frozen separately)
1. **H1 Momentum** — plain 12-month (t−12..t−1) vs 12–2 (t−12..t−2). Only the signal window
   changes; everything else identical.
2. **H2 Quality composite** — profitability (e.g. gross profit/assets), balance-sheet resilience
   (e.g. leverage, current ratio), earnings stability (e.g. std of ROA over 12 quarters).
   Point-in-time inputs from XBRL `filed` dates; report per-component coverage. `design_only`
   until inputs pass audit.
3. **H3 AI investment cycle** — realised capex (cash-flow statement) kept strictly separate from
   guidance, commitments, construction-in-progress and targets. `design_only` until audited.

## Pilot
Long-only top 5, equal weight, monthly rebalance, fixed basket, cost grid 0/10/25/50 bps
one-way; turnover and costs computed from holdings.

## Statistics
- Cross-sectional rank IC (Spearman) by date; report mean, t-stat with HAC/Newey-West.
- Sharpe with uncertainty interval robust to serial dependence (e.g. stationary/block bootstrap).
- Always report the number of variants tried (from the ledger).
- With top-5 baskets, treat results as illustrative; say so.
