---
name: minto-pyramid
description: |
  Structures writing top-down with the Minto Pyramid Principle: answer first (SCQA),
  MECE supporting groups, assertion headings. Use when the user asks to "apply the Minto
  pyramid", "write an executive summary", "make this more executive", "bottom line up front"
  or "BLUF", "start with the answer", "restructure this memo", "turn this into a
  consulting-style brief", "draft a board update or recommendation", or to tighten rambling
  prose into a clear argument. Do NOT use to create the file itself — hand a finished
  structure to the docx, pptx or create skill; and do NOT use for research, data analysis,
  or line-level copy-editing with no structural change.
metadata:
  category: writing
  icon: TextBulletListTree
---

## Overview

Applies Barbara Minto's Pyramid Principle to shape an argument: the answer comes first, every
level below summarizes and supports the level above, and groupings are MECE. This skill shapes
**content and structure** — it does not produce files. When the deliverable is a document, deck
or page, hand the finished structure to the `docx`, `pptx` or `create` skill.

## When to Use

- Rewriting a memo, brief, update or summary so the conclusion leads
- Drafting an executive summary, recommendation or board/exec update from scratch
- Diagnosing why a draft feels rambling, buried or unconvincing
- Converting research notes or meeting output into a defensible argument
- Building a slide storyline where each headline is an assertion

## When NOT to Use

- **Creating the file** (.docx, .pptx, .xlsx, a page) — use `docx`, `pptx` or `create`; this skill hands off the structure
- **Gathering the facts** — use the research/search skills first; the pyramid organizes evidence, it does not find it
- **Grammar, tone or line edits with no structural change** — edit directly
- **Narrative, creative or chronological storytelling** where suspense is the point
- **Regulated or templated documents** with a mandated section order that overrides pyramid ordering

## Quick Start

```
User: "Make this more executive"
1. Find the question the reader is actually asking
2. Write the governing thought — one sentence that answers it
3. Frame it with SCQA (Situation, Complication, Question, Answer)
4. Group support into 3-5 MECE pillars; order them logically
5. Write assertion headings and topic sentences; attach evidence under each
6. Run the quality checklist; then hand off to docx/pptx/create if a file is wanted
```

## Core Instructions

### Step 1: Identify the reader's question
Name the decision-maker and the one question they need answered ("Should we renew the
contract?"). If the question is ambiguous, ask once — everything else depends on it.

### Step 2: Write the governing thought
One declarative sentence that answers the question, with the recommendation and its "so what".
Not "an analysis of margins" but "Renew for two years at the discounted rate — it saves $400K
and removes the migration risk." If it takes two sentences, the argument is not yet resolved.

### Step 3: Frame with SCQA
- **Situation** — the stable, agreed context the reader already accepts
- **Complication** — what changed or went wrong that forces a decision
- **Question** — the question the complication raises (usually implicit)
- **Answer** — the governing thought from Step 2

Keep S-C-Q to two or three sentences total; the intro exists to earn the answer, not to rehearse
the background.

### Step 4: Build MECE supporting groups
Produce **3-5** supporting points at each level (never more than 5; two usually means a missing
pillar). Each group must be:
- **Mutually exclusive** — no point overlaps another
- **Collectively exhaustive** — together they fully support the thought above, with no gap a
  skeptical reader could name

Test each group upward: does the parent statement genuinely summarize its children, or is it just
a category label? Common MECE cuts: by process step, by component, by stakeholder, by time period,
by option, by cost/benefit/risk.

### Step 5: Order within each group
Pick one ordering logic per group and keep it consistent:
- **Deductive** — premise → premise → therefore (use sparingly; it is heavy at the top level)
- **Inductive** — parallel reasons of the same kind, ordered by:
  - **Time** (chronological / process sequence)
  - **Structure** (geography, org unit, system component)
  - **Degree** (most important or largest impact first)

### Step 6: Write assertion headings and topic sentences
Every heading states a claim, not a topic: "Margins fell because freight costs doubled" — not
"Cost analysis". Each paragraph's first sentence carries the point of that paragraph; the rest is
evidence. A reader scanning only the headings and topic sentences should get the whole argument.

### Step 7: Attach evidence
Put data, quotes and detail *under* the assertion it supports. Any fact that supports no assertion
is cut or moved to an appendix. Mark anything unverified as `[verify]` — never invent numbers.

### Step 8: Hand off
State the structure in chat, then offer the file: "Want this as a Word memo (`docx`), a deck
(`pptx`), or a page (`create`)?" On yes, invoke that skill with the Skill tool and pass the
headings and topic sentences through verbatim so the pyramid survives into the artifact. This
skill never calls file-writing tools itself.

## Output Format

Return the structure as markdown, with one assertion heading per pillar and bulleted evidence
beneath it:

```
BOTTOM LINE: <one-sentence governing thought>

Context (SCQA): <2-3 sentences: situation, complication, question>

1. <Assertion heading 1>
   - <topic sentence>
   - evidence: ...
2. <Assertion heading 2>
   - <topic sentence>
   - evidence: ...
3. <Assertion heading 3>
   - <topic sentence>
   - evidence: ...

Next step / ask: <what the reader must decide or do>
```

Length: an executive summary is <= 250 words; a memo 1-2 pages; a slide storyline <= 3 bullets per
headline. Sections: bottom line, context, numbered pillars, next step. When restructuring an
existing draft, show the new structure first, then a short bulleted note of what moved, what was
cut, and what gap remains.

## Quality Checklist

Run before handing anything back:
- [ ] Does the top line **answer the question**, not describe the topic?
- [ ] Could a reader stop after paragraph one and still know the answer and the ask?
- [ ] Is each group **MECE** — no overlap, no gap?
- [ ] Does each parent statement genuinely **summarize** its children?
- [ ] Does **every heading assert** something, rather than label it?
- [ ] Are there **3-5** points per level, with one consistent ordering logic?
- [ ] Is every piece of evidence attached to an assertion it actually supports?

If any box fails, fix the structure before writing prose.

## Guardrails

- Never fabricate facts, figures or quotes to complete a pyramid; mark gaps `[verify]` and say what
  evidence is missing
- Never bury or soften a conclusion the evidence supports — but if the evidence does not support a
  single answer, say so and present the options MECE rather than forcing a false bottom line
- Preserve the author's substance and voice when restructuring; reorganize and sharpen, do not
  silently rewrite claims or change their meaning
- Do not create, save or send files — present the structure and hand off to `docx`, `pptx` or
  `create`, and let the user review before anything is sent
- If the reader's question cannot be determined, ask once rather than guessing the governing thought
