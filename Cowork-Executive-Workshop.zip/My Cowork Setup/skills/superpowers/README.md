# Superpowers (Cowork install)

Skills from **[obra/superpowers](https://github.com/obra/superpowers)** by Jesse Vincent — MIT licence (see `LICENSE`).
Upstream release: v6.4.2 (main @ 8ca22db; most skill folders last changed in v6.4.1 @ 5bf4e78). Installed 2026-10-04.

## Skills

brainstorming · dispatching-parallel-agents · executing-plans · finishing-a-development-branch · receiving-code-review ·
requesting-code-review · subagent-driven-development · systematic-debugging · test-driven-development · using-git-worktrees ·
using-superpowers · verification-before-completion · writing-plans · writing-skills

Not installed: `diagnosing-superpowers` (added upstream in v6.4.1; troubleshoots the upstream plugin install itself).

## How this copy was made

The install sandbox had no direct access to GitHub, so files were reconstructed from GitHub's web pages. The **wording is
verbatim**, but whitespace, line wrapping and some Markdown markup were rebuilt and may differ cosmetically from upstream.
In `finishing-a-development-branch/SKILL.md`, four `<placeholder>` tokens were restored from a third-party mirror. For a
byte-exact copy, compare against the upstream repo.

## Cowork adaptations (everything else is upstream content)

1. **Frontmatter:** each SKILL.md gains `license: MIT` and a `metadata:` block (author, source URL, upstream version,
   Cowork category/icon). Names and the other skills' descriptions are unchanged.
2. **using-superpowers:** the description is scoped to software-development work, with a "Do NOT use for Microsoft 365"
   exclusion. The upstream version fires at the start of *every* conversation. A short Cowork scope note sits above
   `<SUBAGENT-STOP>`, and a `Cowork` entry was added to the Platform Adaptation list.
3. **New file:** `using-superpowers/references/cowork-tools.md` maps Claude Code tool names (Skill, Agent/Task, TodoWrite,
   Read/Write/Edit, Bash, EnterPlanMode) to Cowork equivalents.
4. **Helper scripts:** `executing-plans/scripts/task-start` and `task-done` call the sibling scripts as
   `"${BASH:-bash}" "$sdd/..."` instead of by bare path. Executable bits do not survive the OneDrive sync, and the
   upstream `review-package` and `task-brief` scripts already use the same pattern.

## Not included (executable companions)

- `brainstorming/scripts/*` (server.cjs, helper.js, frame-template.html, start/stop-server.sh): the optional browser
  "visual companion". It needs a local web server the user can open in a browser, which a Cowork sandbox can't offer.
  The brainstorming skill works without it, in text only.
- `writing-skills/render-graphs.js`: an optional renderer that turns dot flowcharts into SVG.
- `systematic-debugging/find-polluter.sh` and `condition-based-waiting-example.ts`: illustrative helpers. The Markdown
  that references them is included.
