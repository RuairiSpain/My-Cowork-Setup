# Cowork Tool Notes

> Cowork adaptation added by the installer — not part of upstream obra/superpowers.

Superpowers skills speak Claude Code's vocabulary. In Microsoft Cowork, map them as follows:

| Superpowers / Claude Code term | Cowork equivalent |
|---|---|
| `Skill` tool / "invoke the X skill" / `superpowers:X` | The `skill` tool with the bare skill name (e.g. `skill: "systematic-debugging"`). The `superpowers:` prefix is just the plugin namespace. |
| `Agent` / `Task` tool, "dispatch a subagent", `Subagent (general-purpose): ...` | The `task` tool with `agent_type: "general-purpose"` (use `explore` for read-only research, `code-review` for review passes). Subagents are stateless — put the full context in the prompt. |
| Parallel subagents | Several `task` calls in one response (background mode where available). |
| `TodoWrite` / "create a todo per item" | The `TaskCreate` / `TaskUpdate` / `TaskList` tools if available; otherwise keep a visible numbered checklist in your replies. |
| `Read` / `Write` / `Edit` | `view` / `create` / `edit`. |
| `Bash` | `bash`. Bundled helper scripts must be run through their interpreter (`bash scripts/<name> ...`) — executable bits are not preserved when skills sync through OneDrive. |
| Plan mode / `EnterPlanMode` | Not available; follow brainstorming → writing-plans instead. |
| Native worktree tools (`EnterWorktree` etc.) | Not available; use the `git worktree` fallback in using-git-worktrees. |
| `CLAUDE.md` / `AGENTS.md` | The user's Cowork personal instructions (`copilot-instructions.md`) and any `AGENTS.md` in the repository. |

## Scope in Cowork

Cowork is also used for Microsoft 365 work (email, calendar, Teams, Word, Excel, PowerPoint). Superpowers skills apply only to **software-development work** — code, tests, debugging, plans, reviews, git branches, and authoring agent skills. Do not invoke them for M365 or general office requests.

## Where the code lives

The Cowork workspace is a sandbox. Superpowers workflows assume a git repository you can edit and test. If no repository is available in the workspace, say so and ask your human partner where the code is rather than inventing one.
