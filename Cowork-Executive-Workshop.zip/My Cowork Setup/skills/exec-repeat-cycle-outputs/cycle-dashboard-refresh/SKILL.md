---
name: cycle-dashboard-refresh
description: |
  Generates or refreshes a single-file interactive HTML dashboard and its underlying data views
  from recurring Excel and SharePoint/OneDrive sources, with all figures computed in code, plus a
  hand-off note for BTS & Digital. Builds the data views only — hosting, governance and corporate
  design standards stay with BTS & Digital. Use when the user asks to "refresh the dashboard data",
  "build an interactive HTML dashboard for [Cycle period]", "update the data views", or "prototype
  a dashboard for BTS". Do NOT use for PowerPoint decks (use flashcalls-deck or qbr-deck) or to
  deploy, host or publish a dashboard.
metadata:
  category: analysis
  icon: DataArea
---

# Cycle Dashboard Refresh (data views — partial fit)

## Overview
Produces a self-contained interactive HTML file (filters, sortable tables, simple charts) and
the tidy data tables behind it, refreshed each cycle from the same sources. It is a **data-view
generator and prototype**, not a production BI platform.

## Scope boundary — state this in every run
> This skill generates and refreshes the underlying data views only. **Hosting, deployment,
> access control, data governance and corporate design standards are owned by BTS & Digital**
> and are out of scope. The HTML file is a draft/prototype for hand-off, not a governed
> production dashboard.

## When to Use
- Refreshing a recurring dashboard's data for a new `[Cycle period]`.
- Creating a first interactive prototype of a data view to hand to BTS & Digital.
- Regenerating the tidy data extracts (CSV/XLSX) a dashboard depends on.

## When NOT to Use
- Hosting, publishing to a web server/SharePoint page, Power BI deployment, access rights or
  data-governance decisions — route to BTS & Digital.
- Applying or certifying corporate design standards — BTS & Digital owns these.
- PowerPoint outputs — use `flashcalls-deck` or `qbr-deck`.
- Project status dashboards from project files — use `project-dashboard-builder`.

## Inputs (ask once for anything missing; defaults in brackets)
| Input | Placeholder | Default if not given |
|---|---|---|
| Dashboard purpose & audience | `[Dashboard purpose]` | Ask |
| Scope | `[Brand/market]` | Ask — never assume |
| Period | `[Cycle period]` | Latest closed month |
| Data sources | `[SharePoint source folder]` / `[Source workbook]` | Search for the prior dashboard's sources; confirm |
| Prior dashboard file | `[Prior dashboard HTML]` | Latest `.html` with "dashboard" in the source folder |
| Metrics & dimensions | `[Metric list]` / `[Dimensions]` | Those in the prior dashboard |
| BTS & Digital contact | `[BTS & Digital contact]` | Leave as placeholder |
| Output folder | `[Output folder]` | Source folder, subfolder `dashboard-drafts` |

Never invent customer or business data; unknown items remain visible placeholders.

## Workflow
1. **State the scope boundary** (quote above) and confirm inputs.
2. **Locate sources** with `sharepoint_onedrive` SearchDrive / GetDriveChildren and `SearchM365`;
   read the prior dashboard (if any) to reuse its views, filters and metric definitions.
3. **Extract** data with ReadFileContent (xlsx skill for workbooks). Record source, sheet,
   row count and last-modified date for each table.
4. **Transform and compute in code** (Python via bash or RunScript): clean types, join, aggregate,
   compute KPIs, period-over-period changes, and data-quality checks (null counts, duplicates,
   out-of-period rows). Never compute numbers by hand.
5. **Write data views** as tidy CSV/XLSX files (one per view) — these are the primary deliverable.
6. **Generate the HTML** with the built-in html / create skill: one self-contained file, data
   embedded as JSON, neutral styling (no corporate branding claimed), accessible colours,
   filters for `[Dimensions]`, sortable tables, charts, a "Data as of" stamp and a visible
   "DRAFT — not a governed BTS & Digital asset" banner. No external CDNs or trackers unless the
   user approves; no credentials or live connections embedded.
7. **Write the BTS & Digital hand-off note** (Markdown or Word): purpose, audience, metric
   definitions, sources + refresh steps, data-quality findings, known limitations, and open
   items explicitly for BTS & Digital — hosting, access/permissions, governance/data
   classification, design-standard alignment, refresh automation.
8. **Save** all files to `[Output folder]` (UploadFileContent) with names
   `dashboard_[Brand-market]_[YYYY-MM]_DRAFT.html`, `data_[view]_[YYYY-MM].csv`,
   `handoff_BTS-Digital_[YYYY-MM].md`; never overwrite — add `_v2`.

## Output
- Interactive HTML draft, the refreshed data-view files, and the hand-off note (paths + links).
- Chat summary: views refreshed, row counts, KPI headline values (from code), data-quality
  issues, and the reminder that hosting/governance/design are with BTS & Digital.
- Optional draft email to `[BTS & Digital contact]` attaching the hand-off note — draft only,
  never sent without explicit approval.

## Quality checks (run before reporting)
- HTML opens offline as a single file; filters and sorting work on the embedded data.
- KPI values in the HTML equal the code output (re-check 3 values).
- Row counts per view match source after documented filters.
- "Data as of", DRAFT banner and BTS & Digital scope note are present.
- Hand-off note lists every open governance/hosting/design item.

## Edge cases and failure handling
- **Source schema changed (renamed/missing columns):** stop that view, report the differences, and ask how to map them.
- **Source unreadable or empty:** keep the view with a "No data this cycle" state and list it in the hand-off note.
- **Data too large to embed (> ~5 MB JSON):** pre-aggregate in code and note the aggregation level in the hand-off.
- **User asks to publish/host/share the dashboard:** decline that part, explain it is BTS & Digital's remit, and offer a draft email to `[BTS & Digital contact]`.
- **Tool error on save:** retry once, then report the error and the local draft path.

## Guardrails
- Never host, publish, share or grant access to the dashboard — that is BTS & Digital's remit.
- Never claim compliance with corporate design or governance standards.
- No fabricated data; missing data is shown as missing.
- Do not embed secrets, connection strings or personal data beyond what the source already shows.
- Draft-only communications unless the user explicitly asks to send.
