---
name: flashcalls-deck
description: |
  Rebuilds the recurring Flashcalls PowerPoint deck each cycle: pulls the latest volume, share and
  execution numbers from SharePoint/OneDrive, Excel and mail, reuses the prior cycle's deck as the
  template, and flags any missing or stale numbers so the team edits rather than assembles.
  Use when the user asks to "build this month's flashcalls deck", "refresh the flashcalls",
  "update the flash deck with the latest numbers", or "prepare the flashcall for [Cycle period]".
  Do NOT use for one-off decks (use pptx), quarterly business reviews against plan (use qbr-deck) or interactive HTML
  dashboards (use cycle-dashboard-refresh) or meeting briefings and inbox follow-ups (use
  exec-chief-of-staff).
metadata:
  category: productivity
  icon: SlideTextSparkle
---

# Flashcalls Deck (repeat-cycle)

## Overview
Every cycle the same Flashcalls deck is rebuilt from fresh volume, share and execution numbers.
This skill finds last cycle's deck, keeps its exact slide structure, swaps in the new numbers
from the source files, recomputes every derived figure with code, and marks anything it could
not source. The output is a DRAFT deck the team reviews and edits — not a finished, approved deck.

## When to Use
- Monthly / weekly / per-cycle refresh of the Flashcalls (flash call) deck.
- "Roll last month's flashcalls forward with the new numbers."
- Checking which Flashcalls numbers are still missing before the call.

## When NOT to Use
- Quarterly actual-vs-plan reviews with narrative and variance thresholds — use `qbr-deck`.
- Interactive / browser-based data views — use `cycle-dashboard-refresh`.
- Meeting briefing packs or inbox follow-ups — use `exec-chief-of-staff`.
- One-off decks with no recurring structure — use the built-in PowerPoint (pptx) skill directly.

## Inputs (ask once for anything missing; defaults in brackets)
| Input | Placeholder | Default if not given |
|---|---|---|
| Brand / market scope | `[Brand/market]` | Ask — never assume a brand or market |
| Cycle period | `[Cycle period]` | The most recently closed calendar month |
| Comparison period | `[Comparison period]` | Prior cycle and same cycle last year, if data exists |
| Source folder for numbers | `[SharePoint source folder]` | Search SharePoint/OneDrive for "flashcall" / "flash" files modified in the last 45 days, then confirm with the user |
| Prior deck (template) | `[Prior Flashcalls deck]` | Most recent `.pptx` whose name contains "flash" in the source folder or OneDrive |
| Output folder | `[Output folder]` | Same folder as the prior deck |
| Metric definitions | `[Metric list]` | The metrics already shown in the prior deck |

Never invent customer, brand, market or numeric data. If an input is unknown, keep the
bracketed placeholder visible in the deck and list it in the gap report.

## Workflow
1. **Confirm scope.** Echo back `[Brand/market]`, `[Cycle period]` and `[Comparison period]`.
   Get today's date and timezone (`outlook_calendar` GetUserDateAndTimeZoneSettings) so "latest
   cycle" is computed, not guessed.
2. **Find the prior deck (template).** `sharepoint_onedrive` SearchDrive / GetDriveChildren on
   `[SharePoint source folder]` for the latest Flashcalls `.pptx`; fall back to `SearchM365`
   ("flashcalls deck", "flash call"). Read it with ReadFileContent and record the slide order,
   titles, tables, charts and every number slot. If none is found, tell the user and use the
   default structure below.
3. **Collect the numbers.** For each number slot, locate the source:
   - Excel / CSV workbooks in `[SharePoint source folder]` (ReadFileContent; use the xlsx skill for
     multi-sheet files) — volume, share, distribution, execution KPIs.
   - Latest data-drop emails (`outlook` ListMessages / GetMessage, last 30 days, subject keywords
     from the prior deck such as "flash", "share", "volume", "sell-out") and their attachments.
   - Teams channel posts announcing data drops (`m365_teams` ListChannelMessages), only if the
     user names the channel.
   Record for every value: source file/email, sheet/cell or table, last-modified date.
4. **Compute with code, never mentally.** Put the extracted raw values into a small Python
   script (bash/python or RunScript) that calculates every derived figure — growth %, share
   change in percentage points, vs prior cycle, vs last year, totals, rankings. Keep the script
   output as the single source of truth for numbers placed in the deck.
5. **Freshness and gap check.** Flag a value as:
   - **MISSING** — no source found → slot shows `[MISSING: metric, period]` in red.
   - **STALE** — source last modified before the cycle closed or period label does not match.
   - **CONFLICT** — two sources disagree by more than 0.5% (computed in code) → show both.
6. **Rebuild the deck** with the built-in PowerPoint (pptx) skill: copy the prior deck's
   structure slide-for-slide, replace numbers and period labels, refresh charts from the computed
   table, keep commentary boxes but replace their text with `[Commentary — to be written by
   team]` unless the user asks for a draft. Add a final "Data sources & gaps" slide.
   Default structure if no template exists: 1 Title + cycle · 2 Headlines (3 bullets) ·
   3 Volume · 4 Share · 5 Execution KPIs · 6 Watch-outs / asks · 7 Data sources & gaps.
7. **Save** as `Flashcalls_[Brand-market]_[YYYY-MM]_DRAFT.pptx` in `[Output folder]`
   (`sharepoint_onedrive` UploadFileContent). Never overwrite an existing file — add `_v2`.
8. **Report back** (see Output).

## Output
- The DRAFT `.pptx` (path + link).
- A chat summary: cycle covered, slides updated, count of numbers refreshed / missing / stale /
  conflicting, and a table `Metric | Value | Source | Status` for every non-OK item.
- Optional: a draft email (Outlook CreateDraftMessage) to the deck owners listing the missing
  numbers — **only created as a draft, never sent** unless the user explicitly says to send.

## Quality checks (run before reporting)
- Slide count and order match the prior deck (or the default structure if none).
- Every number in the deck traces to a source row in the computed table; no hand-typed figures.
- All derived figures come from the script output; spot-check 3 values against the source.
- Period labels on every slide equal `[Cycle period]`.
- No placeholder text remains except intentional `[MISSING …]` / `[Commentary …]` markers.

## Edge cases and failure handling
- **No prior deck found:** say so, use the default structure, and ask whether to save it as the new template.
- **Source file unreadable or locked:** mark its metrics MISSING, name the file, and continue with the rest.
- **Period mismatch (data for a different month):** treat as STALE; never relabel it to the current cycle.
- **Metric definition changed vs prior deck:** keep the old slot, add a note, and ask the owner to confirm.
- **Tool error on save:** retry once; if it still fails, give the user the local draft path and the error.

## Guardrails
- Draft only: never send, post or share the deck or emails without explicit user approval.
- If data is missing, say so — never fabricate or estimate a number to fill a slot.
- Do not overwrite the prior cycle's deck or source workbooks.
- Read only the folders/mailboxes the user points to; respect existing sharing permissions.
- Commercially sensitive figures stay inside the user's tenant; do not paste them into web tools.
