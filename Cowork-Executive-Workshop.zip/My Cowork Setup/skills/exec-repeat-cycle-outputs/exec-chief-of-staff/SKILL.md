---
name: exec-chief-of-staff
description: |
  Acts as an executive's Chief of Staff across Outlook mail, calendar, Teams and SharePoint: builds
  standing briefing packs for upcoming meetings, keeps a follow-up / action tracker, and triages
  the inbox into a prioritised action list with draft replies. Drafts only — never sends without
  approval. Use when the user asks to "prepare my briefing pack for this week", "chief of staff
  run", "what follow-ups are open", or "turn my inbox into actions". Do NOT use for a single
  morning brief (use custom-daily-brief) board packs (use
  board-meeting-prep), decks (use flashcalls-deck or qbr-deck) or dashboards (use cycle-dashboard-refresh).
metadata:
  category: productivity
  icon: PersonStar
---

# Executive Chief of Staff

## Overview
A standing, repeatable Chief of Staff run combining three outputs in one pass:
**(A) briefing pack** for upcoming meetings, **(B) follow-up / action tracker**, and
**(C) inbox-to-action triage**. It reads mail, calendar, Teams and SharePoint/OneDrive,
writes only drafts and files, and never sends, accepts, declines or posts anything without
explicit approval.

## When to Use
- Weekly or daily "chief of staff" run for an executive (self, or a principal the user supports).
- Preparing briefing packs before a block of meetings.
- Reviewing which commitments and follow-ups are open or overdue.
- Converting a busy inbox into a prioritised action list with draft replies.

## When NOT to Use
- A simple one-page morning brief — use `custom-daily-brief`.
- Pure inbox clean-up rules / folder triage only — use `inbox-triage`.
- Board meeting packs — use `board-meeting-prep`.
- Building QBR or Flashcalls decks — use `qbr-deck` / `flashcalls-deck`.

## Inputs (ask once for anything missing; defaults in brackets)
| Input | Placeholder | Default if not given |
|---|---|---|
| Principal | `[Executive name]` | The signed-in user |
| Look-ahead window (briefings) | `[Briefing window]` | Next 5 business days |
| Look-back window (triage, follow-ups) | `[Triage window]` | Last 7 days |
| Priority people / VIPs | `[VIP list]` | Manager, direct reports (me_profile GetManagerDetails / GetDirectReportsDetails) |
| Key topics / accounts | `[Priority topics]` | Ask; otherwise none |
| Tracker location | `[Tracker file]` | `[OneDrive]/ChiefOfStaff/followup-tracker.xlsx` (create if missing, with approval) |
| Output folder | `[Output folder]` | `[OneDrive]/ChiefOfStaff/` |

Never invent people, customer facts or commitments. Unknowns stay as visible `[placeholders]`.

## Workflow
1. **Context.** Get date/timezone (`outlook_calendar` GetUserDateAndTimeZoneSettings), the
   principal's profile and VIPs (`me_profile` GetMyDetails, GetManagerDetails,
   GetDirectReportsDetails). Load the existing `[Tracker file]` if present (ReadFileContent).
2. **(A) Briefing pack.** `outlook_calendar` ListCalendarView for `[Briefing window]`. Skip
   declined, free/focus and all-day placeholder events. For each meeting worth briefing
   (external, VIP, ≥ 4 attendees, or matches `[Priority topics]`):
   - Attendees and roles (`me_profile` GetMultipleUsersDetails; external = name/company from invite only).
   - Recent related mail (`outlook` ListMessages / GetMessage by subject + attendees, 30 days).
   - Related Teams chat/channel context (`m365_teams` ListChatMessages; `SearchM365`).
   - Linked or recent documents (`sharepoint_onedrive` SearchDrive; invite attachments).
   - Prior meeting notes/transcripts (`graph` ListMeetingTranscripts / GetMeetingTranscript, if available).
   Produce per meeting: purpose, desired outcome, who's who, context in 5 bullets, open items
   with these people, suggested questions/asks, prep gaps (e.g. "no agenda", "pre-read missing").
3. **(B) Follow-up tracker.** Scan `[Triage window]` sent mail, inbox, Teams chats and meeting
   transcripts for commitments in both directions ("I'll send…", "can you…by Friday").
   Each item: `ID | Commitment | Owner | Counterpart | Source (link) | Date raised | Due | Status | Next step`.
   Merge with the existing tracker (dedupe by source link + commitment). Compute due/overdue
   status and ageing in code (Python), not mentally. Never close an item without evidence.
4. **(C) Inbox-to-action triage.** `outlook` ListMessages for `[Triage window]` (unread +
   flagged + VIP). Classify each: **Act now** (VIP/deadline ≤ 2 business days), **Decide**,
   **Delegate** (suggest owner), **Read/FYI**, **Ignore/archive candidate**. For Act now /
   Decide items, prepare reply drafts with `outlook` CreateReplyDraft / CreateDraftMessage —
   left in Drafts, never sent.
5. **Count and prioritise in code**: totals per category, overdue count, meetings briefed,
   using a short Python script.
6. **Assemble outputs**: briefing pack (Word via the docx skill, one page per meeting,
   cover summary), tracker (Excel via the xlsx skill, updated `[Tracker file]` — save as new
   version, never overwrite without approval), and triage list (in chat + tracker sheet "Inbox").
   Save to `[Output folder]` with names `briefing-pack_[YYYY-MM-DD].docx`, `followup-tracker.xlsx`.

## Output
1. **Top of chat:** 5-line executive summary — busiest day, top 3 actions, overdue
   follow-ups count, meetings missing prep.
2. **Briefing pack** document (path + link).
3. **Follow-up tracker** (path + link) with new / overdue / closed-with-evidence counts.
4. **Triage table:** `Priority | From | Subject | Ask | Proposed action | Draft created?`.
5. List of drafts created (all unsent) and anything awaiting the user's decision.

## Quality checks (run before reporting)
- Every briefing fact, commitment and triage item links to its source message/event/file.
- No meeting in the window that meets the criteria is left without a brief or a reason.
- Tracker has no duplicate IDs; overdue status computed in code against today's date.
- All drafts are in Drafts; zero messages sent, zero calendar responses made.
- Sensitive content (HR, legal, personal) is summarised minimally and flagged, not quoted.

## Edge cases and failure handling
- **Calendar, Teams or transcripts unavailable:** produce the other sections and mark the missing one "Could not be retrieved this run".
- **Very large inbox (> 300 messages in window):** triage unread + flagged + VIP first and state how many were scanned.
- **Tracker file missing or locked:** create a new dated tracker in `[Output folder]` and tell the user; never overwrite.
- **Ambiguous commitment (owner or due date unclear):** record it with `[Owner?]` / `[Due?]` rather than guessing.
- **User asks to send a draft:** confirm the specific recipients and message first, then send only that item.

## Guardrails
- **Drafts only.** Never send email, post in Teams, accept/decline/forward meetings, or share
  files unless the user explicitly asks to send that specific item.
- Never delete, move or mark messages read without explicit approval.
- If a source is unavailable, say which section is incomplete — never fabricate content.
- Acting for another principal requires that the user already has delegate access; do not
  attempt to access mailboxes or files the user cannot already open.
