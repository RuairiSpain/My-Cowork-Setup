# Exec Repeat-Cycle Outputs

Four repeat-cycle outputs that already consume senior time every month.

| Skill | Fit | Produces |
|---|---|---|
| [flashcalls-deck](flashcalls-deck/SKILL.md) | Strong | Flashcalls PowerPoint rebuilt on the prior cycle's structure with fresh volume, share and execution numbers; missing numbers flagged |
| [qbr-deck](qbr-deck/SKILL.md) | Strong | QBR PowerPoint: actual vs plan across finance, commercial, operations; variance flags with thresholds; narrative draft |
| [cycle-dashboard-refresh](cycle-dashboard-refresh/SKILL.md) | Partial | Single-file interactive HTML dashboard + refreshed data views + BTS & Digital hand-off note (hosting, governance, design standards stay with BTS & Digital) |
| [exec-chief-of-staff](exec-chief-of-staff/SKILL.md) | Highest value | Briefing pack, follow-up tracker, inbox-to-action triage across mail, calendar, Teams, SharePoint |

Shared rules: never invent customer data (unknowns stay as `[placeholders]`); all calculated figures are computed with code; communications are draft-only unless the user explicitly asks to send.
