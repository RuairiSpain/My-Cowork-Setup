---
name: qbr-deck
description: |
  Drafts a Quarterly Business Review PowerPoint deck: reconciles quarter results against plan across
  finance, commercial and operations sources in SharePoint/OneDrive, Excel and mail, computes
  actual-vs-plan variances with code, flags the variances worth discussing against set thresholds,
  and drafts the narrative. Use when the user asks to "build the QBR deck", "prepare the quarterly
  business review", "actual vs plan for [Cycle period]", or "which variances should we discuss
  this quarter". Do NOT use for one-off decks (use pptx), the monthly flashcalls refresh (use flashcalls-deck), HTML
  dashboards (use cycle-dashboard-refresh) or meeting briefings (use exec-chief-of-staff).
metadata:
  category: analysis
  icon: DataBarVertical
---

# QBR Deck (actual vs plan + narrative)

## Overview
Builds a DRAFT QBR deck that reconciles actuals against plan from finance, commercial and
operations sources, highlights only the variances that cross agreed thresholds, and proposes
a narrative for leadership to edit. All arithmetic is done in code; every number is traceable.

## When to Use
- Quarterly (or half-year) business reviews for a brand, market or business unit.
- "Reconcile actuals vs plan and tell me what to talk about."
- Re-running last quarter's QBR with new data.

## When NOT to Use
- Monthly flash numbers with no plan comparison — use `flashcalls-deck`.
- Browser-based interactive data views — use `cycle-dashboard-refresh`.
- Pre-meeting briefing for the QBR meeting itself — use `exec-chief-of-staff`.
- Board packs — use the `board-meeting-prep` skill.

## Inputs (ask once for anything missing; defaults in brackets)
| Input | Placeholder | Default if not given |
|---|---|---|
| Scope | `[Brand/market]` / `[Business unit]` | Ask — never assume |
| Quarter | `[Cycle period]` | Most recently closed fiscal quarter (confirm fiscal calendar with user) |
| Finance source (P&L, actuals, plan/budget) | `[Finance source file]` | Search `[SharePoint source folder]` for "actuals", "plan", "budget", "P&L" |
| Commercial source (sales, share, pipeline) | `[Commercial source file]` | Search for "sales", "share", "pipeline", "volume" |
| Operations source (supply, service, OTIF, headcount) | `[Operations source file]` | Search for "operations", "OTIF", "service level", "supply" |
| Variance thresholds | `[Thresholds]` | Flag if \|variance\| ≥ 5% **and** ≥ `[Materiality amount]`; Red ≥ 10% |
| Prior QBR deck | `[Prior QBR deck]` | Latest `.pptx` containing "QBR" in the source folder |
| Audience | `[Audience]` | Leadership team |

Never invent customer or financial data. Unknown inputs stay as visible `[placeholders]`.

## Workflow
1. **Confirm scope, quarter, fiscal calendar and thresholds** with the user in one message.
2. **Locate sources.** `sharepoint_onedrive` SearchDrive / GetDriveChildren in
   `[SharePoint source folder]`; fall back to `SearchM365`. Check recent mail
   (`outlook` ListMessages, last 30 days, "actuals", "plan", "close", "QBR") for newer
   attachments. Find `[Prior QBR deck]` to reuse its structure.
3. **Extract** actual and plan values per metric with ReadFileContent (xlsx skill for workbooks).
   Build one tidy table: `Domain | Metric | Unit | Actual | Plan | Prior year | Source | As-of date`.
4. **Reconcile.** Check the same metric across sources (e.g. revenue in finance vs commercial).
   Differences > 0.5% are listed as reconciliation issues — do not silently pick one.
5. **Compute variances with code.** In Python (bash or RunScript): absolute variance, % variance,
   vs prior year, YTD, and the threshold flag (Green / Amber / Red) per `[Thresholds]`. Sort by
   absolute impact. The script output is the only source for numbers in the deck.
6. **Select variances worth discussing:** all Red items plus Amber items in the top 5 by impact;
   max 8 discussion items. For each, gather context — related emails, Teams threads, meeting
   notes (`SearchM365`, `m365_teams` ListChatMessages when relevant) — and record the evidence.
   If no explanation is found, write `[Driver to be confirmed by owner]`.
7. **Draft narrative** using the Minto pattern: one-sentence headline answer, 3 supporting
   points, then asks/decisions. Mark every causal claim with its source or as a hypothesis.
8. **Build the deck** with the built-in PowerPoint (pptx) skill, reusing the prior QBR
   structure when found. Default structure: 1 Title · 2 Executive summary (narrative) ·
   3 Scorecard actual vs plan (RAG) · 4 Finance · 5 Commercial · 6 Operations ·
   7 Variances to discuss (driver, owner, proposed action) · 8 Outlook / risks & opportunities ·
   9 Decisions & asks · 10 Appendix: data sources, reconciliation issues, thresholds used.
9. **Save** as `QBR_[Brand-market]_[FYxx-Qx]_DRAFT.pptx` in `[Output folder]`
   (default: source folder) via UploadFileContent; never overwrite — add `_v2`.

## Output
- The DRAFT QBR `.pptx` (path + link).
- Chat summary: headline narrative (3 lines), variance table
  `Metric | Actual | Plan | Var | Var % | Flag | Driver`, reconciliation issues, missing data.
- Optional draft email to metric owners asking for driver explanations — Outlook
  CreateDraftMessage only; **never sent without explicit approval**.

## Quality checks (run before reporting)
- Every actual and plan figure has a source and as-of date in the appendix.
- Variance math re-run in code and totals tie (sum of parts = total within rounding).
- Thresholds stated on the scorecard slide match those used in code.
- Narrative contains no claim that is not backed by data or labelled as a hypothesis.
- Units and currency consistent (€, k/m) across all slides; period labels match `[Cycle period]`.

## Edge cases and failure handling
- **Plan file missing:** build actuals-only slides, mark all variances `[Plan missing]`, and ask for the plan source.
- **Fiscal calendar unclear:** ask once; if unanswered, use calendar quarters and state the assumption on slide 1.
- **Sources disagree:** show both figures on the appendix slide; do not average or pick silently.
- **More than 8 variances cross thresholds:** keep the top 8 by absolute impact; list the rest in the appendix.
- **Tool error reading or saving:** name the failed source/file, continue with what is available, and report it.

## Guardrails
- Draft only — never send, post or share without explicit user approval.
- Never fabricate actuals, plan values or drivers; missing data stays visibly missing.
- Do not modify source finance/commercial/operations files.
- Financial data is confidential: keep it inside the tenant; no external web tools.
