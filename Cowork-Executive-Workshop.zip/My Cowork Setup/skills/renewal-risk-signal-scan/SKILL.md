---
name: renewal-risk-signal-scan
description: |
  Scans Outlook email, Teams chats and meeting transcripts for renewal risk signals (budget cuts, reorgs,
  competitor mentions, escalations, champion departures, fading engagement) across every account renewing
  in the next N days from a renewal workbook, then builds a risk-ranked Word report with evidence-backed
  deep dives. Use when user asks to "scan for renewal risk", "which renewals are at risk", "build a
  renewal risk report", "churn signals across my accounts", or "run my monthly renewal scan".
  Do NOT use for one deal's stall diagnosis (use d365-sales-deal-rescue), ranking open opportunities
  (use d365-sales-pipeline-prioritizer), or sending anything to customers.
metadata:
  category: analysis
  icon: ShieldError
---

# Renewal Risk Signal Scan

## Overview
Reads the renewal account list from an Excel workbook, scans the last 90 days of customer communications
(Outlook mail, Teams meeting recaps/transcripts, Teams chats) for each account renewing inside the chosen
window, scores renewal risk with code, and produces a Word report: a risk-ranked table plus a one-page
deep dive for every High-risk account, ready to share with CS and leadership. The point is early
detection — prioritise saves before the renewal clock runs out.

## When to Use
- "Scan my comms for renewal risk across accounts renewing in the next 90 days"
- "Which of my renewals are at risk this quarter?"
- "Build the renewal risk report from Renewals FY27.xlsx"
- "Churn signals across my book" / monthly renewal-risk run
- "Renewal risk scan, and also flag expansion signals" (dual risk/opportunity mode)

## When NOT to Use
- Diagnosing a stall on one specific opportunity — use `d365-sales-deal-rescue`
- Ranking open pipeline to work next — use `d365-sales-pipeline-prioritizer`
- Full context brief on one account — use an account-research / meeting-prep skill (recommended follow-up for High accounts)
- Drafting or sending customer emails — this skill never contacts customers

## Inputs (with defaults)
| Parameter | Meaning | Default if not given |
|---|---|---|
| `[TIME_PERIOD]` | Renewal window: accounts whose renewal date falls between today and today + period | **90 days** |
| `[RENEWAL_WORKBOOK]` | The renewal workbook (.xlsx) | Most recently modified `.xlsx` in OneDrive `/Sales/Renewals/` — tell the user which file was picked |
| `[TODAYS_DATE]` | Report date, used in the file name and window maths | The run date (user's local date, ISO `YYYY-MM-DD`) |
| Comms lookback | How far back to read communications per account | **90 days** |
| Extra signals | User-supplied industry terms (e.g. "compliance change", "audit finding") | none |
| Expansion mode | Also flag expansion signals | off — on if user says "also flag expansion signals" |

Ask at most one question, and only if the workbook cannot be found at all. Otherwise apply defaults and state them in the report's "Scope & method" section.

## Core Instructions

### Step 1 — Resolve inputs
1. Get the user's date/time zone (`outlook_calendar-GetUserDateAndTimeZoneSettings`); set `TODAYS_DATE` = run date unless given.
2. Locate the workbook: if named, find it with `sharepoint_onedrive-SearchDrive`; otherwise list `/Sales/Renewals/` with `sharepoint_onedrive-GetDriveChildren` and take the newest `.xlsx` by `lastModifiedDateTime`.
3. Read it (`sharepoint_onedrive-ReadFileContent`, or download and parse with Python/openpyxl).

### Step 2 — Validate the workbook (hard gate)
Required columns, matched case-insensitively with obvious synonyms:
- **Account** (name) — `Account`, `Customer`, `Account Name`
- **ACV** — `ACV`, `Annual Contract Value`, `ARR`
- **Renewal date** — `Renewal Date`, `Contract End`, `End Date`
- **Customer domain** — `Domain`, `Email Domain`, `Customer Domain`

Optional, used when present: `Champion` / `Primary Contact` (name + email), `Owner`, `Segment`, `Industry`.

**If ACV, renewal date, or customer domain is missing, STOP.** Report which columns were found, which are missing, and what the user must add. Do not guess domains from account names and do not continue with a partial scan.
Also list (don't silently drop) rows with unparseable dates, blank domains, or non-numeric ACV.

### Step 3 — Filter accounts (in code)
With Python: keep rows where `TODAYS_DATE <= renewal_date <= TODAYS_DATE + TIME_PERIOD`. Record total rows, in-window rows, excluded rows with reasons. If zero accounts are in window, say so and stop (offer a wider window).

### Step 4 — Gather evidence per account (last 90 days)
For each in-window account, collect, keeping source, date, sender/speaker and an ID/link for every item:
- **Email**: `outlook-ListMessages` / `m365_search-SearchM365` filtered on `@{domain}` (from, to, cc), last 90 days. Capture send timestamps and reply latency per thread.
- **Meetings**: `outlook_calendar-ListCalendarView` for events with attendees at `@{domain}` (frequency, attendance, declines); `graph-ListMeetingTranscripts` / `graph-GetMeetingTranscript` and meeting recaps for those meetings.
- **Teams chats**: `m365_search-SearchM365` / `m365_teams-ListChatMessages` for messages mentioning the account name, domain, or champion.
For a large book (>10 accounts) loop with a tool script rather than one call at a time. Do not print raw mail bodies to the user beyond the quoted evidence.

### Step 5 — Detect signals
Default signal list (tunable — append the user's industry-specific terms):
| # | Signal | What counts as evidence | Weight |
|---|---|---|---|
| S1 | Budget / cost-cutting | "tightening", "budget review", "justify spend", "cost reduction", "freeze", "procurement review" | 3 |
| S2 | Organisational change | new CFO/CIO, acquisition, merger, layoffs, reorg, restructuring | 3 |
| S3 | Competitor mention | a named competitor in customer-authored content, or evaluation/RFP language | 3 |
| S4 | Unresolved escalation / complaint | open support escalation, Sev A/1, outage complaint, "not working", unanswered complaint | 3 |
| S5 | Champion departure / role change | champion leaving, permanent out-of-office replies, bounces, new title, "handing over to" | 4 |
| S6 | Declining meeting cadence / attendance | meetings in last 45 days vs prior 45 days down ≥50%, repeated declines/no-shows | 2 |
| S7 | Email tone shift | median customer reply length down ≥40% or median response time up ≥2× (last 30 vs prior 60 days) | 1 |

Rules:
- S1–S5 need a **verbatim quote** (≤40 words) with date, sender/speaker and source. S6–S7 are **computed in Python** from timestamps/counts — show the numbers, not an impression.
- One quote supports one signal. Our own (Microsoft-side) speculation is not a customer signal unless it relays a fact (e.g. "Ana confirmed she's leaving in May").
- Recency: signals in the last 30 days count ×1.5.

### Step 6 — Score and rank (in code, never by eye)
- `raw = Σ(weight × recency multiplier)` over distinct signals per account.
- **High** if raw ≥ 7, or S5 present, or S4 + any other signal; **Med** if raw 3–6.9; **Low** if < 3 with adequate evidence.
- **Insufficient evidence**: fewer than 3 customer communications in 90 days → do NOT score from guesswork. Rate it **"Insufficient evidence"**, which is itself a risk (silent accounts churn); rank it with Med and recommend re-engagement.
- Sort: High → Med/Insufficient → Low; within tier by renewal date ascending, then ACV descending. Totals (ACV at risk by tier, counts) also computed in code.
- Recommended action per account comes from the top signal (e.g. S5 → "Identify and multi-thread to new sponsor within 2 weeks"; S1 → "Build value/ROI recap before budget review"; S3 → "Competitive positioning session with account team"; S4 → "Escalate to CSAM/support manager, close loop in writing").

### Step 7 — Optional expansion mode
If requested, also flag: new hires / headcount growth, growth or funding announcements, new projects/workloads, increased usage or capacity requests — same evidence rules. Add an "Expansion signal" column and an "Opportunities" section; never let expansion signals offset risk scores.

### Step 8 — Build the Word report (docx workflow)
Create the .docx using the docx skill/agent workflow. Title: **"Renewal Risk Scan — [TODAYS_DATE]"**.
1. **Summary** — window, workbook used, accounts scanned, counts and ACV by tier, top 3 accounts to act on.
2. **Risk-ranked table** — Account | ACV | Renewal Date | Risk Score (High/Med/Low/Insufficient evidence) | Top Signal | Recommended Action.
3. **High-risk deep dives** — one page each (page break between): account snapshot (ACV, renewal date, days left, champion), signals found with **evidence quotes** (quote — sender, date, source), engagement metrics, a **recovery play** (objective, 3–5 concrete steps with owners and dates before renewal, who to involve from CS/leadership), and "Next: run an Account Research Brief for full context".
4. **Expansion opportunities** (only in expansion mode).
5. **Scope & method** — defaults applied, signal list and weights, excluded rows, data gaps, "Generated by Cowork; verify before sharing externally".

### Step 9 — Save
- Target: OneDrive `/Sales/Renewals/Renewal Risk Scan — [TODAYS_DATE].docx` via `sharepoint_onedrive-UploadFileContent`.
- **Cowork limitation:** if a direct save to `/Sales/Renewals/` is not possible (permissions, folder missing, tool failure), save to the OneDrive root (or the session output) and tell the user exactly where it went and that they need to move it. Never claim it is in `/Sales/Renewals/` unless the upload returned success.

## Output
Chat reply (≤10 lines): file name + saved location, accounts scanned, counts by tier with ACV at risk, the top 3 High accounts with their top signal, any workbook/data gaps, and the suggestion to run monthly and pair High accounts with an Account Research Brief.

## Guardrails
- **Never fabricate.** Every signal cites a real quote/metric with date and source from retrieved mail, Teams chats or transcripts. No evidence → no signal.
- Accounts with no or thin comms data are flagged **"Insufficient evidence"** (itself a risk), never guessed.
- All filtering, scoring, counts, ACV totals and engagement metrics are computed in code.
- **Read-only toward customers:** never send, reply, forward, draft-to-customer, or post in customer-facing chats. The report is internal.
- Do not modify the renewal workbook or CRM records.
- Missing required columns (ACV, renewal date, customer domain) → stop and report; do not proceed partially.
- Quote minimally (≤40 words) and keep the report internal — it contains customer correspondence.
- If a data source is unavailable (e.g. transcripts not accessible), say so in Scope & method and score only on what was retrieved.

## Tips
- Run monthly — risk signals compound and early detection is the point.
- Tune the signal list to your business: say "add 'compliance change' and 'data residency' as budget-level signals".
- Say "also flag expansion signals" for a dual risk/opportunity scan.
- Pair every High account with an Account Research Brief to build the save plan.
