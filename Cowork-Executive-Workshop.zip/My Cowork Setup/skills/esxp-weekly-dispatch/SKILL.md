---
name: esxp-weekly-dispatch
description: Ruairi's weekly ESXP self-dispatch run. Reads his Outlook calendar for a Mon–Fri week, builds the per-company Priority hours list, checks ESXP My Deliveries (Incoming/Upcoming/Current) once into a cache, then for each company either links an existing delivery or creates ONE self-dispatch for the week (billable, or non-billable only if the company has no billable hours). Use when Ruairi asks for his weekly or daily dispatches, e.g. "do my ESXP dispatches", "self-dispatch this week", "match my calendar to ESXP", or "create my deliveries for the week". Not for logging labour hours.
---

# ESXP weekly self-dispatch (Ruairi O'Donnell)

Runs end to end without asking questions. The ONLY human stop: the ESXP form's Submit button stays disabled.

## Inputs
- Week: Monday 00:00 → Saturday 00:00 of the requested week (default: current week), W. Europe Standard Time.
- ESXP: https://esxp.microsoft.com/#/supportdelivery/mydeliveries (Ruairi is signed in in the local browser).
- Reference tables at the end of this skill.

## When NOT to use
- The request is not about weekly or daily ESXP dispatches (e.g. general ESXP questions, labour/time entry, report submission, reading a single delivery, pipeline or manager reports).
- Do not use for other people's calendars or deliveries — Ruairi's only.

## Safety rules
- Never submit a delivery twice: click Submit once; if the outcome is unclear, search ESXP/the cache for the title before any retry.
- Never dispatch Unassigned slots.
- Never dispatch slots that do not have the Outlook category "Priority".
- Never accept, decline or edit existing deliveries — read-only except creating the planned self-dispatch.

## Part 1 — Company list from Outlook
1. Read the whole week in ONE calendar call (script it): subject, start, end, bodyPreview, categories, organizer, responseStatus, isCancelled, isAllDay.
2. Keep events that have category **Priority**, are not cancelled, not declined, not all-day.
3. Map each slot to a company with the Company table, in this order:
   a. A specific customer keyword in the subject wins (SEAT, ECCBC, EUDA, Nespresso, KPMG, PwC, FCC, NI…).
   b. Organiser Avinash Kumar or an AXA/CGI keyword → **CGI** if subject contains CGI, Intraevo, AI Search, API Manager or APIM; **AXA UK** if it contains AXA, ADU, Doc Understanding, Brendon or "Workshop on 15th".
   c. Intraevo is always CGI.
   d. Anything unmatched → "Unassigned"; report, never dispatch.
4. Mark each slot **Billable** or **Free**. Free if ANY of:
   - subject or body contains the whole word "free" (any case);
   - subject contains "scoping" (any case);
   - duration is 30 minutes or less;
   - company is ECCBC (Coca-Cola) — always Free.
   **Exceptions (always Billable even if ≤30 min):** "Nespresso - Unified acceleration stand-up".
5. Hours: slot hours = end − start; overlapping slots each count in full. Per company per day per funding type, sum and round UP to whole hours. Weekly figure = sum of the rounded daily figures.
6. Plan exactly ONE dispatch per company per week:
   - If the company has any Billable hours → one **Billable** dispatch for the Billable hours only. Its Free hours are NOT dispatched separately — they will be entered later as labour on this same dispatch (note them in the output).
   - If the company has only Free hours → one **Non-Billable** dispatch for the Free hours.
   - Title = subject of the company's longest slot in the dispatched group. Description = every slot of the company that week as "dd-Mon – subject (Xh, Billable/Free)" separated by "; " (max 1,100 characters).
7. Save the plan to working/esxp_dispatch_plan.json.

## Part 2 — ESXP delivery cache (read ONCE per run)
1. Open My Deliveries. If an "Application Updated" banner shows, click Refresh. Wait until the table shows rows or "No records".
2. Read ONLY tabs **Incoming**, **Upcoming**, **Current** (never Reports Pending, Labor Assist, Complete). Per tab: click it, wait for load, set Results Per Page = **All**, confirm footer "Showing 1 to N of N", then read the whole table as page text in ONE extraction (do not open rows). Capture: tab, customer, tracking number, skill/product, CSAM, created date, scheduled start date, estimated duration, type.
3. Link = https://esxp.microsoft.com/#/supportdelivery/requestdetails/<TrackingNumber>
4. Save to working/esxp_deliveries_cache.json with a read timestamp. Never re-read during the run; append each new self-dispatch to the cache. Re-read only on a new run if the cache is older than 12 hours.

## Part 3 — Loop over the planned dispatches (largest hours first)
### 3a. Existing delivery (cache only)
Candidates = cached deliveries whose customer fuzzy-matches the company's ESXP names AND whose Scheduled Start + 2 days is on or after the work dates (no lower bound — work may precede creation). If any → list each (tracking link, skill, CSAM, created, scheduled, duration), status **Existing delivery**, no self-dispatch; next company.
### 3b. Guards
- No CSAM known → status **Opportunity hours (no package)**; next.
- Cache already holds a delivery for this customer with the same title created today → reuse it; next.
### 3c. Create the self-dispatch
Speed rules (the page is very slow):
- After every dropdown choice, poll every 3 s (max 60 s) until the next control is enabled before acting.
- Never scroll lists: type a keyword in the dropdown filter (company, "EDE", product), wait 3 s, click the closest match.
- For Agreements and Package Name, read all options as text in ONE extraction, choose by text, record the options.
- Fill independent text fields (title, description, address) in one batch, then verify once; the Description counter must be > 0.
- Browser timeout → wait 10 s and retry the same step, max 3; then mark **Failed (browser timeout)** and continue with the next company.

| # | Field | Value |
|---|---|---|
| 1 | Open | My Deliveries → **New Delivery** ("Create and Dispatch a Delivery") |
| 2 | Type of Request | **DSE Self Dispatch** |
| 3 | CSAM Alias | CSAM from the Company table |
| 4 | Agreements | Fuzzy match company name → parent company → country. None → **Opportunity hours (no package)**, abandon form, next |
| 5 | Package Name | Wait until enabled. Prefer "Enhanced Designated Engineering"/"EDE"; else closest to company/country/subdivision |
| 6 | Delivery Country | Auto. IGNORE "different from Agreement Country" warning (remote dispatches) |
| 7 | Service Name | First value |
| 8 | Authorized Contact | A customer person seen in Ruairi's Outlook mail for that company; else first in list |
| 9 | Delivery Title | Planned title |
| 10 | Delivery Method | Leave default |
| 11 | Product Component | From Company table; if not offered type "Azure Foundry" |
| 12 | Technical POC | Same as Authorized Contact (usually auto) |
| 13 | Start Date | **Today** (past dates are blocked). Arrival default 09:00 |
| 14 | Days/Hours | **Hours** radio; planned hours |
| 15 | Recurrence | **No** |
| 16 | Address / Post Code / State / City | From Address table; if missing, ONE web search for the company's office in the delivery country, then add it to the table. Pick State, wait for City to enable, pick City; if exact city missing choose nearest large city |
| 17 | Description | Planned description (verify counter > 0) |
| 18 | Time zone | **(GMT+01:00) Central European Time** |
| 19 | Language | **English** |
| 20 | Funding Type | Billable → **Bill to Line Item** (leave Charge Case Labor default). Non-Billable → **Non-Billable**, Approver **Richard Bumann**; if not listed/not permitted → **Jose Luis Molina Romero**; Non-Billable Reason **CSU Strategic Investment** |
| 21 | Calendar invite | Default (off) |

Submit:
- Enabled → click ONCE, wait up to 90 s for "Successfully submitted Delivery Request ROSS…". If the browser times out after clicking, do NOT click again — search ESXP for the title to confirm. Record ROSS, link, hours, funding, warnings; append to cache.
- Disabled → the only human stop: list every field with an error/required marker, leave the form open, ask Ruairi to fix it, then submit and continue.

## Part 4 — Output
Table per company:
| Company | Dispatch funding | Dispatched hours | Free hours to log as labour | Outlook slots | Delivery (ROSS link) | Status |
Status ∈ Existing delivery · Self-dispatched · Opportunity hours (no package) · Needs help (form blocked) · Failed (browser timeout) · Unassigned slot.
Totals per status; billable vs non-billable dispatched hours.

## Reference tables
### Company table
| Company | Calendar keywords | ESXP customer names (fuzzy) | CSAM | Product Component |
|---|---|---|---|---|
| Nestlé / Nespresso | Nespresso, Nestlé, RBAC | Nestlé Nespresso SA; Nestlé Operational Services Worldwide | sboumelala (Sabrine Boumelala) | Azure Networking |
| AXA UK | AXA, ADU, Doc Understanding, Brendon, Workshop on 15th | AXA Group Operations SAS | avinaskumar (Avinash Kumar) | Document Intelligence |
| CGI | CGI, Intraevo, AI Search, API Manager, APIM | CGI Inc. | avinaskumar | Azure AI Search |
| Network International | NI, MySQL, Network International | Network International (L.L.C.) | Reina Nader (search "Nader") | Azure Database for MySQL |
| ECCBC (always Free) | ECCBC, Coca-Cola, Agent 365 | Equatorial Coca Cola Bottling Company | albertopr (Alberto Prieto Montiel) | Copilot |
| SEAT | SEAT | SEAT, S.A. | albertopr | Copilot |
| EUDA | EUDA, Git/Hub, GitHub | European Union Drugs Agency (EUDA) | jorosa (Jonathan Rosa) | GitHub (else Azure Foundry) |
| FCC | FCC, Grupo de Trabajo, Agentes IA | Fomento de Construcciones y Contratas | amolinap | Azure Foundry |
| KPMG Spain | KPMG | KPMG, S.A. | robertoguran (Roberto Guran) | Azure Foundry |
| PwC NL | PWC, PwC | Pricewaterhousecoopers Accountants N.V. | Danila Belnuovo (search "Belnuovo") | Azure Foundry |

### Free-rule exceptions (always Billable)
- Nespresso - Unified acceleration stand-up

### Address table (append as discovered)
| Company | Address | Post code | State | City |
|---|---|---|---|---|
| Nestlé / Nespresso (Spain) | Carrer de Clara Campoamor, 2 (Edificio Nestlé) | 08950 | Catalonia | Barcelona |

### Known dispatches
- ROSS2026100905542803 — Nespresso - review RBAC in Terraform, 3 h, Billable, 10-Oct-2026 (week of 5-Oct).
