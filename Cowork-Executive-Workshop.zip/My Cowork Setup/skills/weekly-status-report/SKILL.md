---
name: weekly-status-report
description: |
  Aggregates the user's week across Outlook mail, calendar, Teams chats, channel posts and meeting
  transcripts, drafts a one-page Word status report saved to OneDrive, and creates an UNSENT Outlook
  draft to their manager with the report attached. Use when the user asks to "generate my weekly
  status report", "weekly status for week of [date]", "draft my status update for my manager", or
  "summarise my week into a status report". Do NOT use for a daily briefing, a single meeting recap,
  or a team-wide pipeline review — use the daily-briefings or meeting-analyzer skills instead.
metadata:
  category: productivity
  icon: DocumentBulletList
---

# Weekly Status Report Generator

## Overview
Chains Outlook, Teams, Word and OneDrive: gathers a week of evidence (email, chats, channel posts,
meeting transcripts, calendar), synthesises a concise one-page executive status report, saves it to
OneDrive as `Status Report - [WEEK_STARTING_DATE].docx`, and leaves a **draft** email to the manager
with the report attached. Nothing is ever sent automatically.

## When to Use
- "Generate my weekly status report" / "summarise my week into a status report"
- "Weekly status for week of 28 September" (explicit week)
- "Draft my status update for my manager"
- "Weekly status — scan channels Project-X, Launch, Ops" (explicit channel list)

## When NOT to Use
- Daily or morning briefing of today's inbox/calendar — use `daily-briefings` / `email-inbox`
- Summary or action items for ONE meeting — use `meeting-analyzer`
- Team or sales pipeline reviews — use the D365 Sales skills
- Sending an email right now with no report — use Outlook directly

## Inputs
| Parameter | Default | Notes |
|---|---|---|
| `WEEK_STARTING_DATE` | Monday of the current week (user's time zone) | Accept "week of …", "last week" (= previous Monday). Format `YYYY-MM-DD` in filenames/subjects |
| `TEAMS_CHANNEL_NAME` | none → scan active channels the user posted/was mentioned in this week | One or more, e.g. "scan CHANNEL_1, CHANNEL_2, CHANNEL_3" |
| `MANAGER_EMAIL` | resolve via `me_profile-GetManagerDetails` | If no manager is returned, ask the user once |

Week window = `WEEK_STARTING_DATE 00:00` → following `Sunday 23:59` in the user's time zone
(get it from `outlook_calendar-GetUserDateAndTimeZoneSettings`). Next week = the following Mon–Fri.

## Workflow

### Step 0: Context
1. `me_profile-GetMyDetails` → user's name, email, id.
2. `outlook_calendar-GetUserDateAndTimeZoneSettings` → time zone; compute the week window.
3. `me_profile-GetManagerDetails` → `MANAGER_EMAIL` (unless supplied).

### Step 1: Outlook mail
1. `outlook-ListMessages` on Inbox and Sent Items filtered to the week window (page through results;
   skip newsletters, automated notifications and calendar responses).
2. Read substantive threads with `outlook-GetMessage` when the preview is insufficient.
3. Extract: key topics, decisions made, commitments the user made or received, open issues/blockers.
   Record the source (subject + date) for every fact.

### Step 2: Teams activity
1. **Chats:** `m365_teams-ListChats` → chats with activity in the window → `m365_teams-ListChatMessages`.
   Extract decisions, action items, important exchanges.
2. **Channels:** if `TEAMS_CHANNEL_NAME` is given, resolve each with `m365_teams-ListTeams` →
   `m365_teams-ListChannels`; otherwise pick channels where the user posted, replied or was mentioned this
   week. Read with `m365_teams-ListChannelMessages`. Extract announcements, discussions and deliverables
   the user was involved in.
3. **Meeting transcripts:** `outlook_calendar-ListCalendarView` for the week → for each Teams meeting take
   the online-meeting join URL → `graph-ListMeetingTranscripts` → `graph-GetMeetingTranscript`. For a
   recurring series, pick the transcript whose start is closest to this occurrence's start. Note meeting
   name, key outcomes, decisions, and action items assigned to the user.
   - If transcripts return 403/404 or none exist (transcription off, not organizer, not yet processed),
     fall back to calendar + chat evidence and record the gap for the report footer.

### Step 3: Calendar
1. From the same `ListCalendarView`, note meetings with no transcript/chat coverage (in-person, non-Teams)
   and any outcomes found in mail/chat about them. Ignore declined/cancelled events.
2. `outlook_calendar-ListCalendarView` for NEXT week → key meetings, deadlines and reviews for
   "Upcoming Next Week".

### Step 4: Synthesise the report
Deduplicate across sources (the same decision often appears in mail, chat and transcript). Classify each
fact into exactly one section. Keep it to **one page**: max ~5 bullets per section, one line each.

### Step 5: Create the Word document
Build `Status Report - [WEEK_STARTING_DATE].docx` with the docx/Word workflow (delegate to the docx
skill/agent), then save to OneDrive with `sharepoint_onedrive-UploadFileContent` (default drive root,
or a `Status Reports` folder if one exists). Confirm the returned item id/webUrl.

### Step 6: Draft the email (never send)
1. `outlook-CreateDraftMessage` to `MANAGER_EMAIL`, subject `Weekly Status - [WEEK_STARTING_DATE]`, body
   = one short paragraph summarising the week (top accomplishment, main blocker, next-week focus).
2. `outlook-AddDraftAttachments` (or `UploadAttachment`) to attach the .docx.
3. Do NOT call `SendDraftMessage`. Tell the user the draft is in Drafts for review.

### Variation: post to Teams instead of email
Only when the user explicitly asks: post the one-paragraph summary (plus OneDrive link) to
`TEAMS_CHANNEL_NAME` with `m365_teams-PostChannelMessage` — show the text and get confirmation first.

## Output

**Report (one page):**
```
Weekly Status Report — [User Name] — Week of [YYYY-MM-DD]
Accomplishments            • [fact] (source)
In Progress                • [item — status / next step]
Blockers & Risks           • [blocker — impact — help needed]
Key Decisions & Outcomes   • [decision — meeting/thread, date]
Upcoming Next Week         • [meeting/deadline — day]
Footer: Sources: N emails, N chats, N channel threads, N transcripts. Gaps: [e.g. 2 meetings without transcripts]
```
Empty section → `No items identified this week from available data.`

**Chat reply to the user:** OneDrive file name + link, draft email subject + recipient, 3-bullet
highlight of the week, and any data gaps.

## Tips
- Best run on **Fridays after the last meeting** so transcripts are available.
- Prerequisite: Teams meeting transcription must be enabled for recap data.
- List multiple channels explicitly for a more focused scan: "scan CHANNEL_1, CHANNEL_2, CHANNEL_3".

## Guardrails
- **Never send** the email or post to Teams without explicit user instruction; drafts only by default.
- Only include facts traceable to retrieved data — never invent accomplishments, numbers or dates. Use the
  placeholder line when a section has no evidence.
- Executive tone: concise bullets, no jargon, no internal acronyms without expansion.
- Exclude sensitive personal content (HR, health, compensation) and confidential threads not relevant to work status.
- If a tool fails (403/404/throttling), continue with remaining sources and list the gap in the footer.
- Confirm before overwriting an existing OneDrive file of the same name.
