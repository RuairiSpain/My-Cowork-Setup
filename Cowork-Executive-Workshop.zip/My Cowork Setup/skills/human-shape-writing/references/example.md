# Before / after example (original, illustrative)

Topic: Azure Front Door and a caching problem. The "after" uses `[placeholder: …]` where a real fact is needed —
the skill must never invent those details.

## Before — the tidy, self-announcing shape

> **Unlocking Performance: A Comprehensive Guide to Azure Front Door Caching**
>
> In today's fast-paced digital landscape, delivering content quickly is more crucial than ever. Traditional
> on-premises CDNs struggle to keep up with modern, global user bases. Enter Azure Front Door — a next-generation,
> cloud-native solution that seamlessly accelerates your applications.
>
> In this post, we'll explore how Azure Front Door caching works, walk through best practices, and look at
> common pitfalls. Let's dive in!
>
> *(…four evenly sized sections with bolded bullet lead-ins…)*
>
> **In short,** Azure Front Door caching is a game-changer for organisations looking to modernise delivery.

Tells: freshness framing, legacy-vs-modern contrast, thesis + roadmap before the first section, institutional voice,
no outside voices, uniform sections, summary close, stock phrases (fast-paced, landscape, seamlessly, dive in,
game-changer).

## After — rolled recipe: opening = complaint/mistake · flow = problem → false starts → fix · evidence = concrete
## input/output · voices = "I" + docs excerpt · temporal = specific date · ending = caveat · length = short

> **Why our product images ignored the new cache rule**
>
> On [placeholder: date] I changed a cache duration on a Front Door route, purged, and watched the old images keep
> coming back for another [placeholder: observed time].
>
> My first guess was the purge. I purged again, this time with the exact path. No change.
>
> The second guess was the browser. A `curl -I` from a clean shell showed:
>
> ```
> x-cache: TCP_HIT
> cache-control: [placeholder: header value seen]
> ```
>
> That header was the clue. The origin was sending its own `Cache-Control`, and the route was set to honour
> origin. The docs say it plainly: [placeholder: quote the relevant line from the Front Door caching docs, with link].
> I'd read that page twice and still assumed my rule would win.
>
> Switching the route's caching behaviour to override fixed it within one purge cycle.
>
> One caveat I haven't resolved: [placeholder: the open question, e.g. whether query-string handling changes this
> for your setup]. If you've seen different behaviour, I'd like to hear it.

Note what changed: the *order, evidence and voices* changed, not just the words. No roadmap, no "modern vs legacy",
a real artefact (the header), an outside voice (the docs), a false start, and it stops on a caveat rather than a
summary.
