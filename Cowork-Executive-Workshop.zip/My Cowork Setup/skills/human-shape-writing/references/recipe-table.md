# Weighted recipe table (fallback when scripts can't run)

Mirrors `scripts/structure_dice.py`. Pick one option per dimension, roughly in proportion to the weights (e.g. roll
a number 1–100 against the cumulative weights). ⚠ = AI-modal: keep at or below ~5% and use only if the user asks.
Across pieces in one session, don't reuse the previous opening, flow or ending.

| Dimension | Options (weight) |
|---|---|
| Opening | mid-story anecdote (16) · concrete number or date (14) · a question someone actually asked (14) · a complaint or mistake (14) · quote from a named person (10) · straight into the first technical step (14) · short dated context, "In March 2023 we…" (14) · ⚠ thesis + roadmap (2) |
| Flow | chronological (12) · problem → false starts → fix (14) · Q&A (10) · single worked example, expanded (14) · roundup (8) · interview/dialogue excerpt (8) · notes/log entries (9) · compare two options (12) · what I'd do differently (12) |
| Explanation | show via example (30) · analogy (15) · code-first then prose (25) · trade-off table (20) · ⚠ mechanism explanation (3) |
| Evidence | specific dated event (18) · named/anonymised customer story (18) · concrete input/output (20) · measured number with source (16) · personal failure (14) · comparison of two sources (14) |
| Voices | "I" (26) · "we", a real team (20) · second person, sparingly (10) · outside voice: quote, colleague, community comment, docs excerpt (40) · ⚠ institutional only (2) |
| Temporal | specific historical date/period (35) · version-specific, "as of AKS 1.30" (35) · none (27) · ⚠ modern vs legacy (2) |
| Ending | stop after the last useful point (20) · open question (15) · next thing I'm trying (16) · caveat/limitation (16) · short anecdote (13) · link to go further (16) · ⚠ summary / "In short" (2) |
| Length | short < 800 words (45) · medium 800–1,300 (40) · long, only if content demands (15) |
| Format | plain prose, few headings (32) · headings with uneven section lengths (28) · mostly code (20) · bullets only for genuine lists (20) |
| Sentence variance | high (45) · medium (55) |
| Paragraph variance | high, include a one-liner and a long one (50) · medium, no two consecutive the same (50) |
| Rhetorical devices | 0 (60) · 1 at most (40) |
