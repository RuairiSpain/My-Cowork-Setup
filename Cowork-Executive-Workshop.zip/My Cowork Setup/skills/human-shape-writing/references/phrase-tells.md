# Phrase-level tells (secondary layer)

Use after the structural audit. These are signs, not sins: one instance is fine; clusters and mechanical repetition
are the problem. Replace with the specific thing meant, or delete — don't swap one stock word for another.

## Overused words
delve · tapestry · landscape · realm · navigate (figurative) · journey · unlock · unleash · elevate · empower ·
harness · leverage · seamless · robust · holistic · pivotal · crucial · vital · paramount · game-changer ·
cutting-edge · next-generation · transformative · streamline · synergy · ecosystem (non-technical) · testament ·
underscore · showcase · foster · bolster · myriad · plethora · nuanced · intricate · ever-evolving

## Stock constructions
- "In today's fast-paced / digital / ever-changing world…"
- "It's not just X, it's Y" / "This isn't about X. It's about Y."
- "Let's dive in" / "Let's dive deeper" / "Let's unpack"
- "Here's the thing:" / "Here's why that matters:" / "The result?"
- "Whether you're a seasoned pro or just starting out…"
- "In this post / article, we'll explore…"
- "In short," / "In conclusion," / "Ultimately," / "At the end of the day,"
- "By doing X, you can Y" repeated as a paragraph template
- "Imagine a world where…"
- Rhetorical question immediately answered by the next sentence, repeatedly

## Pattern tells
- **Rule-of-three triads** everywhere ("faster, safer and cheaper").
- **Em-dash overuse** — more than one or two per few hundred words.
- **Colon-heavy headings** ("Scaling AKS: What You Need to Know").
- **Uniform paragraph lengths**; every section the same shape (intro line → 3 bullets → wrap-up line).
- **Bolded lead-ins on every bullet** ("**Scalability:** …").
- **Emoji bullets** (🚀 ✅ 💡) in technical writing.
- Title Case Headings On Everything (British style: sentence case).
- Closing line that turns into a motivational call to action.

## Quick density check
Count per ~500 words: em-dashes, triads, bolded bullet lead-ins, words from the list above. If any count is above
2–3, fix the worst instances first and stop when the density is ordinary.
