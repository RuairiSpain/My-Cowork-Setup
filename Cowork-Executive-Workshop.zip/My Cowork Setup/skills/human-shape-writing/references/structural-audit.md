# Structural audit checklist

Run on the whole draft before any phrase-level work. For each finding, record **location → problem → planned fix**,
then fix only those. If a fix would need a fact you don't have, insert `[placeholder: …]` instead.

## A. Tidy self-announcing tells (SlopShape)

| # | Tell | Look for | Typical fix |
|---|---|---|---|
| A1 | Thesis/roadmap before the first unit | "In this post we'll cover…", a first paragraph that previews every section | Cut the preview; start where the recipe's opening says |
| A2 | Legacy-vs-modern framing | "Traditionally… but today…", "gone are the days" | Replace with the actual dated situation or version, or drop |
| A3 | Confident institutional voice throughout | Every claim stated as settled fact by an unnamed "organisations" | Attribute: who saw it, when, under what conditions; admit uncertainty where real |
| A4 | Summary close | "In short", "To sum up", "Ultimately", last paragraph restates the intro | End at the recipe's ending; delete the restatement |
| A5 | No outside voices | Only the author speaks | Add a real quote, colleague remark, community comment, docs excerpt — or a placeholder |
| A6 | Mechanism-only explanation | Paragraphs of "how X works" with no case | Swap for an example, input/output, or trade-off |
| A7 | Freshness language | "modern", "next-generation", "cutting-edge", "in today's…" | Use the version/date instead |
| A8 | Over-length | Longer than the content needs | Cut to the recipe's length band |

## B. Connection checks (Science or Slop?, adapted to general writing)

| # | Check | Question to ask | Fix (without gaming it) |
|---|---|---|---|
| B1 | Macro redundancy | Does a later section restate an earlier one instead of moving on? | Delete the restatement, keep any new fact or citation it carried |
| B2 | Cross-references | Is every section, code block, table or diagram *used* by something else? | Refer back only where it does work ("the 429s from the first run…"); cut orphans. No hollow "as noted above" |
| B3 | Argument build-up | Does any claim arrive with no lead-in or reason? | Add the step that justifies it, or soften/qualify the claim |
| B4 | Isolated sources | Is each link/source cited alone, never compared? | Relate sources: agree, disagree, which one you trusted and why |
| B5 | Cluttered visuals/code | Does a diagram or snippet carry detail that doesn't show the point? | Trim to the lines that matter; say what to look at |
| B6 | Evidence gap | Any aggregate claim or number with no concrete case, input or output? | Attach a real example, or `[placeholder: example of …]` — never invent one |

## C. Overcorrection guard
- One finding → one edit. Don't rewrite unflagged passages.
- Don't delete citations, numbers or caveats while removing repetition.
- Don't add cross-references, quirks, slang, hedges or typos for their own sake.
- After editing, re-read each change against the source material: is it still true and supported?
