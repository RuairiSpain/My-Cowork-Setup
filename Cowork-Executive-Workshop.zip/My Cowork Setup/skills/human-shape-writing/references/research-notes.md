# Research notes

Condensed from the two papers the skill is built on. Numbers are as reported by the authors.

## 1. SlopShape: Identifying AI-Generated Commercial Web Content
Madler, arXiv:2609.15369.

**Data.** 2,250 pre-ChatGPT human company blog posts vs 11,250 AI "mirrors" (same brief) from five frontier models.
AI mirrors were longer than the human posts (model means 1,064–1,541 words).

**Structure beats style, and survives rewording.**
- 176 structural features with style stripped detect AI posts at **97.0 macro-F1**; a style model reaches 88.1.
- Rewording every AI post with its own model drops structural detection only to **96.1**, even though rewording
  changed 73% of 13-word sequences. → Word-level "humanising" does not work; the structure has to change.
- The structure and style classifiers fail on nearly disjoint posts — they are separate signals, so handle both
  (this skill: structural audit first, phrase audit second).

**The AI shape: the tidy, self-announcing blog post.** States its thesis and announces its structure before the
first section ("In this post, we'll cover X, Y and Z"); frames the subject as the modern answer to a legacy way of
working; explains in a confident institutional voice; closes with a summary or restated thesis ("In short, …").

**Core features (human–AI gap; direction = who it points to).**

| Feature | Points to | Gap |
|---|---|---|
| Conclusion restates thesis / reframe | AI | 0.650 |
| Stage inventory includes summary / synthesis | AI | 0.609 |
| External participation pathway absent (no outside voices, quotes, people, community) | AI | 0.592 |
| No legacy-vs-modern contrast | Human | 0.497 |
| No thesis before the first unit | Human | 0.419 |
| "Modern / next-generation" freshness framing | AI | 0.360 |
| Dominant credibility = confident institutional explanation | AI | 0.347 |
| Stage inventory includes mechanism explanation | AI | 0.285 |
| References to specific historical dates or periods | Human | 0.283 |
| Short posts (< 800 words) | Human | 0.274 |

Other top signals: argument-structure stages, how the reader is addressed, temporal framing, how sources are
disclosed.

**Rarity.** Human posts' mean rarity percentile 0.835 vs AI 0.436 (Cohen's d 1.80). In the rarest 1% of
configurations: 146 human vs 2 AI. The human post was the rarest of its 6-post group in 85.6% of cases. All five
models crowd into the same common configurations. Humans also produce formats AI almost never does: interviews,
transcripts, roundups. → `structure_dice.py` down-weights modal options and up-weights rare ones.

**Schema (11 dimensions):** purpose, audience, structure and flow, explanation, evidence, voices, actionability,
commercial integration, timeliness, page format, writing style.

## 2. Science or Slop? Benchmarking and Mitigating Scientific Slop in AI-Generated Papers
Oh, Lee, Ahn, Kim, Kang, arXiv:2610.00531.

Six whole-document measures across Structure, Argument and Artifacts:

1. **Macro redundancy** — later sections restate earlier material instead of developing it.
2. **Cross-section references** — sections/objects never referred to from elsewhere. Strongest single signal
   (0.905 pair accuracy). Humans connect the parts of a document.
3. **Argument graph** — claims arrive with no build-up; the argument is flat.
4. **Citation isolation** — sources cited alone, never compared, grouped or related.
5. **Figure exposition** — diagrams cluttered with detail that doesn't show the method.
6. **Evidence gap** — aggregate claims/numbers with no concrete example, input, output or case.

**Mitigation lessons.**
- Generic "improve this" revision leaves the slop in place.
- Optimising directly against the checklist causes reward hacking / overcorrection — e.g. deleting a repeated
  sentence *and* its citations; scattering "see Section X" references that connect nothing.
- What worked: locate specific problems, fix them, then verify each edit is supported by real source material.
- Never invent an example. If none exists, say so or use a placeholder.

## How the skill uses this
- Paper 1 → the recipe dimensions and weights, the "tidy self-announcing" audit, length bias toward short.
- Paper 2 → the six connection checks and the anti-overcorrection rule (locate → fix → verify against source).
