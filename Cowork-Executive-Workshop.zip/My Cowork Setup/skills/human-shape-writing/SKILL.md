---
name: human-shape-writing
description: |
  Drafts or rewrites blog posts, articles, emails, docs and LinkedIn posts so their STRUCTURE reads as human:
  rolls a randomised structure recipe (opening, flow, evidence, voices, ending, length), then audits whole-document
  connection and phrase tells. Based on SlopShape and "Science or Slop?". Use when the user asks to "make it sound
  human", "less AI-like", "give it a human structure", "vary my writing", "avoid AI slop structure", or to draft a
  Hashnode or LinkedIn post in a human voice. Do NOT use for wording-only edits or AI-slop detection,
  use no-ai-slop instead; for Wikipedia signs-of-AI checks, use wikipedia-human-style-writing instead; for a brand or
  house voice, use brand-voice-pass instead; for a standard post skeleton, use blog-post-structure-pass instead.
metadata:
  category: writing
  icon: TextEditStyle
---

# Human Shape Writing

LLM writing clusters into a few common structural configurations; human writing spreads across rare ones. Swapping
words does not fix that — in SlopShape, rewording changed 73% of 13-word sequences yet structure still detected AI
posts at 96.1 macro-F1. So this skill changes the **structure first** (what points, in what order, with what
evidence, in whose voice), then checks phrases as a secondary layer. Research summary:
[references/research-notes.md](references/research-notes.md). British English by default.

## When to Use
- Drafting a new post, article, email, doc or LinkedIn post that should not have the "tidy, self-announcing" AI shape.
- Rewriting an existing draft whose structure (not just wording) reads as generated.
- Writing several pieces in one session that must not all share the same shape.

## When NOT to Use
- Wording-only polish or "is this AI?" detection → `no-ai-slop`.
- Checking against Wikipedia's signs-of-AI catalogue → `wikipedia-human-style-writing`.
- Matching a brand or house voice → `brand-voice-pass`.
- Restructuring into a standard hook/problem/reframe skeleton → `blog-post-structure-pass`.
- Disguising AI authorship where disclosure is required (see Ethics).

## Workflow

1. **Gather real material first.** Collect from the user, their files (`view`) or notes (`SearchM365`) the actual dates, versions, names,
   quotes, numbers, customer stories, mistakes and links. Never fabricate any of these to look human. If something
   the recipe needs is missing, write `[placeholder: what is needed]`.
2. **Roll the recipe.** Use the `bash` tool to run `python scripts/structure_dice.py` (add `--history working/hsw-history.json` when
   writing more than one piece; `--seed N` to reproduce; `--fix dim=value` for user constraints). If scripts cannot
   run, pick from the weighted table in [references/recipe-table.md](references/recipe-table.md). **User
   constraints override the dice** — a requested format, length or ending wins. If the recipe asks for evidence
   or a voice you do not have, re-roll that dimension rather than inventing it.
3. **Draft to the recipe.** Follow the opening, flow, explanation mode, evidence, voices, temporal framing, ending,
   length, format and rhythm knobs exactly. Let section lengths come out uneven.
4. **Structural audit** (primary) — use [references/structural-audit.md](references/structural-audit.md):
   - Tidy self-announcing tells: thesis/roadmap before the first section; legacy-vs-modern framing;
     confident institutional voice throughout; summary/"In short" close; no outside voices; mechanism-only
     explanation; "modern/next-generation" freshness language.
   - Six connection checks: macro redundancy, cross-references, argument build-up, isolated sources,
     cluttered visuals/code, evidence gap.
   Record each problem with its location before changing anything.
5. **Phrase audit** (secondary) — scan against [references/phrase-tells.md](references/phrase-tells.md) for
   overused words, stock constructions, triads, em-dash and colon density, and uniform paragraph shape.
6. **Fix only what you located (anti-overcorrection).** One targeted edit per finding. Do not strip useful content
   or citations along with a repeated sentence; do not scatter "as mentioned above" references that connect
   nothing; no forced quirks, slang or deliberate typos. Re-check each edit is supported by real source material.
7. **Variation memory.** For each further piece in the session, re-roll with the same history file; never reuse
   the previous opening, flow or ending.
8. **Return the piece plus a short end note** (format below).

## Output Format

The finished text, then:

```
---
Recipe: opening=…; flow=…; explanation=…; evidence=…; voices=…; temporal=…; ending=…; length=…; format=…
Audit fixes: <n> structural, <n> phrase (one line each, location → change)
Placeholders needing real facts: [list, or "none"]
```

Before/after illustration: [references/example.md](references/example.md).

## Guardrails
- Never invent dates, names, quotes, numbers, customers or anecdotes; use `[placeholder: …]` and list it.
- Preserve the author's facts, stance, technical accuracy and citations; flag (do not silently change) anything
  that looks wrong.
- Output is a draft only: hand the text back for the user to review; this skill does not distribute anything.
- Ethics: this is for improving the user's own content and natural voice. Do not use it to misrepresent
  authorship where disclosure is required (e.g. academic submissions or publications with AI-use policies);
  if the request is plainly that, decline and say why.
- If the user rejects the rolled recipe, re-roll or let them pick; do not argue for the dice.
