#!/usr/bin/env python3
"""structure_dice.py - roll a less "modal" structure recipe for one piece of writing.

Grounded in SlopShape (arXiv:2609.15369): LLM posts crowd into a few common
structural configurations; human posts spread across rare ones. Each dimension
below is a weighted choice that down-weights the AI-modal option(s) (marked
ai_modal=True) and up-weights rarer human ones.

Stdlib only. Deterministic with --seed; random otherwise.

Usage:
  python structure_dice.py                       # one recipe, markdown
  python structure_dice.py --seed 42             # reproducible
  python structure_dice.py --history hist.json   # avoid repeating recent recipes, append this one
  python structure_dice.py --fix length="short (< 800 words)"   # user constraints win
  python structure_dice.py --json
  python structure_dice.py --selftest            # 1,000-draw check: AI-modal options <= 5%
"""
import argparse
import json
import os
import random
import sys

# (option, weight, ai_modal)
DIMENSIONS = {
    "opening": [
        ("mid-story anecdote (start inside the event)", 16, False),
        ("concrete number or date", 14, False),
        ("a question someone actually asked", 14, False),
        ("a complaint or a mistake", 14, False),
        ("quote from a named person", 10, False),
        ("straight into the first technical step", 14, False),
        ("short dated context ('In March 2023 we...')", 14, False),
        ("thesis up front + roadmap ('In this post we'll cover...')", 2, True),
    ],
    "flow": [
        ("chronological", 12, False),
        ("problem -> false starts -> fix", 14, False),
        ("Q&A", 10, False),
        ("single worked example, expanded", 14, False),
        ("roundup (several short items, uneven lengths)", 8, False),
        ("interview / dialogue excerpt", 8, False),
        ("notes / log entries", 9, False),
        ("compare two options", 12, False),
        ("what I'd do differently", 12, False),
    ],
    "explanation": [
        ("show via example", 30, False),
        ("analogy (one, specific)", 15, False),
        ("code-first, then prose", 25, False),
        ("trade-off table", 20, False),
        ("mechanism explanation (how it works, institutional)", 3, True),
    ],
    "evidence": [
        ("specific dated event", 18, False),
        ("named or anonymised customer story", 18, False),
        ("concrete input / output", 20, False),
        ("measured number with its source", 16, False),
        ("personal failure", 14, False),
        ("comparison of two sources", 14, False),
    ],
    "voices": [
        ("first-person singular ('I')", 26, False),
        ("'we' (a real team)", 20, False),
        ("second person, sparingly", 10, False),
        ("outside voice: quote, colleague, community comment or docs excerpt", 40, False),
        ("confident institutional voice only, no outside voices", 2, True),
    ],
    "temporal": [
        ("specific historical date or period", 35, False),
        ("version-specific ('as of AKS 1.30')", 35, False),
        ("no temporal framing", 27, False),
        ("modern vs legacy / 'next-generation' framing", 2, True),
    ],
    "ending": [
        ("stop after the last useful point", 20, False),
        ("open question", 15, False),
        ("next thing I'm trying", 16, False),
        ("caveat or limitation", 16, False),
        ("short anecdote", 13, False),
        ("link to go further", 16, False),
        ("summary / 'In short' / restated thesis", 2, True),
    ],
    "length": [
        ("short (< 800 words)", 45, False),
        ("medium (800-1,300 words)", 40, False),
        ("long (> 1,300 words) - only if the content demands it", 15, False),
    ],
    "format": [
        ("plain prose, few headings", 32, False),
        ("headings with deliberately uneven section lengths", 28, False),
        ("mostly code with short prose between", 20, False),
        ("bullets only for genuine lists, prose otherwise", 20, False),
    ],
    "sentence_variance": [
        ("high: mix 4-word and 35-word sentences", 45, False),
        ("medium: noticeable mix, no run of 3 same-length sentences", 55, False),
    ],
    "paragraph_variance": [
        ("high: include a one-line paragraph and a long one", 50, False),
        ("medium: no two consecutive paragraphs the same length", 50, False),
    ],
    "rhetorical_devices": [
        ("0 (none)", 60, False),
        ("1 (at most one, where it earns its place)", 40, False),
    ],
}

# Dimensions whose repetition between consecutive pieces reads as a template.
NO_REPEAT = ("opening", "flow", "ending")


def draw(rng, fixed=None, avoid=None):
    """Draw one recipe. `fixed` = user constraints (win over dice); `avoid` = recent values."""
    fixed = fixed or {}
    avoid = avoid or {}
    recipe = {}
    for dim, options in DIMENSIONS.items():
        if dim in fixed:
            recipe[dim] = fixed[dim]
            continue
        pool = [o for o in options if not (dim in NO_REPEAT and o[0] in avoid.get(dim, set()))]
        if not pool:
            pool = options
        names = [o[0] for o in pool]
        weights = [o[1] for o in pool]
        recipe[dim] = rng.choices(names, weights=weights, k=1)[0]  # nosec B311 - not security use
    return recipe


def ai_modal_names():
    return {dim: {o[0] for o in opts if o[2]} for dim, opts in DIMENSIONS.items()}


def load_history(path):
    if not path or not os.path.exists(path):
        return []
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def avoid_from_history(history, lookback=3):
    avoid = {d: set() for d in NO_REPEAT}
    for rec in history[-lookback:]:
        for d in NO_REPEAT:
            if d in rec:
                avoid[d].add(rec[d])
    return avoid


def to_markdown(recipe, seed):
    modal = ai_modal_names()
    title = "### Structure recipe" + (f" (seed {seed})" if seed is not None else "")
    lines = [title]
    for dim, val in recipe.items():
        flag = "  <- AI-modal; keep only if the user asked for it" if val in modal.get(dim, set()) else ""
        lines.append(f"- **{dim.replace('_', ' ')}**: {val}{flag}")
    return "\n".join(lines)


def selftest(n=1000, seed=12345):
    rng = random.Random(seed)  # nosec B311 - not security use
    modal = ai_modal_names()
    counts = {d: 0 for d, s in modal.items() if s}
    history = []
    for _ in range(n):
        rec = draw(rng, avoid=avoid_from_history(history))
        history.append(rec)
        for d in counts:
            if rec[d] in modal[d]:
                counts[d] += 1
    rates = {d: round(c / n, 3) for d, c in counts.items()}
    repeats = sum(1 for a, b in zip(history, history[1:]) for d in NO_REPEAT if a[d] == b[d])
    ok = all(r <= 0.05 for r in rates.values()) and repeats == 0
    return {"draws": n, "ai_modal_rates": rates, "max_allowed": 0.05,
            "consecutive_repeats_opening_flow_ending": repeats, "passed": ok}


def main(argv=None):
    p = argparse.ArgumentParser(description="Roll a less modal structure recipe for one piece of writing.")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--history", help="JSON list of earlier recipes; this recipe is appended")
    p.add_argument("--fix", action="append", default=[], metavar="DIM=VALUE",
                   help="user constraint that overrides the dice (repeatable)")
    p.add_argument("--json", action="store_true")
    p.add_argument("--selftest", action="store_true")
    a = p.parse_args(argv)

    if a.selftest:
        res = selftest()
        print(json.dumps(res, indent=2))
        return 0 if res["passed"] else 1

    fixed = {}
    for item in a.fix:
        if "=" not in item:
            p.error(f"--fix expects DIM=VALUE, got {item!r}")
        k, v = item.split("=", 1)
        k = k.strip().replace(" ", "_")
        if k not in DIMENSIONS:
            p.error(f"unknown dimension {k!r}; choose from {', '.join(DIMENSIONS)}")
        fixed[k] = v.strip()

    rng = random.Random(a.seed)  # nosec B311 - not security use
    history = load_history(a.history)
    recipe = draw(rng, fixed=fixed, avoid=avoid_from_history(history))

    if a.history:
        history.append(recipe)
        with open(a.history, "w", encoding="utf-8") as fh:
            json.dump(history, fh, indent=2)

    print(json.dumps(recipe, indent=2) if a.json else to_markdown(recipe, a.seed))
    return 0


if __name__ == "__main__":
    sys.exit(main())
