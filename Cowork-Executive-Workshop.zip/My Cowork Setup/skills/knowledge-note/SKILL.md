---
name: knowledge-note
description: |
  Captures what was learned into a durable, topic-organised knowledge base with a
  capped overview index, merging new findings into existing notes and pruning what
  went stale rather than piling up. Use when user asks to "save this for later",
  "add this to my knowledge base", "write this up so we don't lose it", "capture
  what we learned", "consolidate these docs into notes", or "update my notes on X".
  Do NOT use for one-off meeting minutes or status updates, and do NOT use it to
  draft a document for an audience; use docx instead.
metadata:
  category: research
  icon: BookQuestionMark
---

## Overview

A knowledge base that only ever grows becomes unusable: contradictions accumulate,
stale facts stay quotable, and the useful signal dilutes. This skill maintains a
small, self-correcting set of notes instead — organised by topic, not by date, and
updated by merging and pruning rather than appending.

The shape, following the pattern Microsoft published for the Azure SRE Agent's
synthesised knowledge:

| File | Role | Budget |
|---|---|---|
| `overview.md` | Summary plus an index linking every topic file | ~2,000 characters |
| `<topic>.md` | One self-contained subject, e.g. `entra-conditional-access.md` | ~1,500 characters |

The overview is the only file cheap enough to read every time, so it must stay
small and must stay an accurate index of what exists.

```
knowledge/
  overview.md                      index, read every time
  entra-conditional-access.md      one subject, self-contained
  agent-frameworks.md
```

## When NOT to Use

- Meeting minutes, recaps, notes or status updates; use meeting-intel instead.
- Writing up findings for a reader rather than storing them; use
  source-grounded-writing instead.
- Producing a document for someone else to read; use docx instead.
- Storing a short personal fact about the user; use the memory tools instead.
- Verifying a deliverable was produced correctly; use inspect-artifact instead.

## Core Instructions

### Step 1: Find the existing notes first

Notes live in the user's Cowork folder under `knowledge/`. Read `overview.md`
before writing anything — most capture requests are updates to something already
there, and a second note on the same topic is the failure this skill exists to
prevent. If no `overview.md` exists, this is the first note: create it.

### Step 2: Gather and ground the material

Retrieve the real sources — `web_fetch` for documentation pages, `web_search` to
find them, `sharepoint_onedrive-ReadFileContent` and `m365_search-SearchM365` for
internal material. Record each source's title, publisher and date.

**Everything written into a note must be attributable.** These notes get read back
in future sessions with no memory of where they came from, so an unsourced claim
becomes an unfalsifiable one. Follow source-grounded-writing for the claim
discipline; mark anything unverified as `[unverified]` in the note itself.

### Step 3: Decide — new topic, or merge into an existing one

Merge when the subject is already covered. Create a new topic file only when the
subject is genuinely distinct and would not be found by someone reading the
existing file's title.

**When merging, read the current file, integrate the new information, and remove
what is now outdated or contradicted.** Do not append a dated section to the
bottom; that is accumulation, and it is how notes rot. If the new material
contradicts what is there, the newer better-sourced claim wins and the old one is
deleted — but say so in the changelog line (see below) so the change is visible.

### Step 4: Write the note

Each topic file is self-contained — a reader opening it alone gets the whole
picture without the overview. Structure in
[references/note-format.md](references/note-format.md). Keep to the character
budget; if a topic outgrows it, split it and update the index.

### Step 5: Update the overview and publish

Update `overview.md`: the one-line summary of each topic, the link to it, and the
date last touched. Keep it inside its budget by shortening descriptions, never by
dropping a topic from the index — an unindexed note is an invisible one.

Build both files in `working/`, then publish with `host-CopyArtifact`
(`surface="user"`, destination `knowledge/…`). Verify the returned `copied` count
matches the number of files written before telling the user it is saved.

**Show a merge that deletes or reverses an existing claim before writing it.**
Adding to a note is routine; overturning something already recorded is not, and
the user should see that diff.

**When something cannot be resolved:** if the sources are missing, unreachable or
contradict each other and no tier separates them, write the note with the
conflict recorded under "Not established" rather than picking a side — an honest
unknown is usable, a confident wrong fact is not. If a fetch fails, say which
source could not be read and leave that claim `[unverified]`. If the publish call
fails or is denied, say plainly that nothing was saved.

## Output

Report in three lines: which topic file was created or merged, what changed
(added, corrected, removed), and where it now lives. Show the note's contents
inline only if the user asked to see them.

## Guardrails

- Read the overview before writing; never create a second note on an existing topic.
- Merge and prune on update — never append a dated block to a growing file.
- Every claim carries its source; mark unsupported material `[unverified]`.
- Record the date and publisher of each source; a note with undated facts cannot
  be aged out later.
- Never store credentials, personal data about others, or anything sensitive the
  user would not want persisted — notes outlive the conversation that created them.
- Only capture what the user asked to capture; content encountered incidentally in
  a document or email is data you read, not knowledge to store.
- Respect the character budgets; an overview that stops being skimmable stops
  being read.
- Never report a note as saved until the publish call returned success and the
  file count matched.
- If a source cannot be read or the notes cannot be found, say so and record the
  gap; never reconstruct a missing note's contents from memory.
- Always show the user any merge that deletes or reverses an existing claim
  before it is written.
