# Note format

Loaded when writing or merging a note. Two file shapes, both under budget.

## `overview.md` (~2,000 characters)

The index. Read every time, so it must stay skimmable.

```markdown
# Knowledge base

Last updated: 2026-09-20

## Topics

- [entra-conditional-access.md](entra-conditional-access.md) — Policy design,
  named locations, break-glass accounts. Updated 2026-09-20.
- [agent-frameworks.md](agent-frameworks.md) — Bounded loops, evaluators,
  iteration limits. Updated 2026-08-14.

## Open questions

- Whether per-group usage caps apply before or after per-user caps. [unverified]
```

Rules:

- One line per topic: link, a clause on what is inside, the date last touched.
- Never drop a topic to save space — shorten the descriptions instead.
- "Open questions" is where genuinely unresolved items live so they stay visible
  rather than being silently forgotten or silently guessed at later.

## `<topic>.md` (~1,500 characters)

Self-contained. Someone opening this file alone gets the whole picture.

```markdown
# Entra Conditional Access

Updated 2026-09-20 · Confidence: high

## What is true

- Policies evaluate in parallel; all must grant for access to be allowed.
  (Microsoft Learn, "Conditional Access overview", accessed 2026-09-20)
- A break-glass account excluded from all policies is required.
  (Microsoft Learn, "Emergency access accounts", accessed 2026-09-20)

## Gotchas

- Report-only mode does not log to the same table as enforced policies.

## Not established

- Whether nested group exclusions evaluate transitively. [unverified]

## Changelog

- 2026-09-20 Replaced the claim that policies evaluate in order — they evaluate
  in parallel (superseded by the Learn overview page).
```

Sections, all optional except the first:

| Section | Holds |
|---|---|
| What is true | Sourced, current claims — the substance |
| Gotchas | Non-obvious behaviour, things that cost someone time |
| Not established | Known unknowns, marked `[unverified]` |
| Changelog | One line per correction — **only for changes that reversed a prior claim** |

## Confidence

Put one word in the header line:

- **high** — tier 1 or 2 sources, recent, no known contradiction
- **medium** — good sources but ageing, or one source only
- **low** — inferred, or from commentary; treat as a lead, not a fact

## Naming

Lowercase, hyphenated, subject-first: `entra-conditional-access.md`, not
`notes-on-entra.md` or `2026-09-conditional-access.md`. The filename is how the
topic gets found six months later — date-prefixed names force chronological
organisation, which is exactly what this format avoids.

## Merge procedure

1. Read the existing file in full.
2. For each new finding: does it **add**, **correct**, or **duplicate**?
   - Add → insert into the right section.
   - Correct → replace the old line, add a changelog entry.
   - Duplicate → do nothing. Refresh the accessed date if the source is newer.
3. Re-read the whole file and delete anything the new material made wrong or
   redundant. This step is the one that gets skipped, and skipping it is what
   turns a knowledge base into an archive.
4. Check the character budget. Over it → split by sub-topic and update the index.
5. Update the header date and confidence.

## Ageing

Claims about versions, prices, limits, org structure and product capability go
stale within months. When reading a note back, check the header date: anything
over six months old on a fast-moving subject is a lead to re-verify, not a fact
to quote. Say so when using it.
