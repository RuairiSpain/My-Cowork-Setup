# Hashnode GraphQL recipes

Endpoint: `https://gql.hashnode.com/` (official agent skill documents
`https://gql-beta.hashnode.com/`). Always `POST` a JSON body
`{"query": "...", "variables": {...}}` with headers:

```
Authorization: $HASHNODE_PAT      # raw token
Content-Type: application/json
```

Canonical field-level reference: <https://github.com/Hashnode/gql-skill> →
`skills/gql-api/references/` (`schema.graphql`, `queries.md`, `mutations.md`,
`auth-and-roles.md`, `errors-and-limits.md`, `recipes.md`).

## Helper

```bash
gql() {  # $1 = query, $2 = variables JSON (optional)
  jq -n --arg q "$1" --argjson v "${2:-null}" '{query:$q, variables:$v}' \
  | curl -sS -X POST https://gql.hashnode.com/ \
      -H "Authorization: $HASHNODE_PAT" \
      -H "Content-Type: application/json" \
      -d @-
}
```

## 1. Who am I, and which publications do I own?

```bash
gql 'query { me { id username publications(first: 10) { edges { node { id title url } } } } }' \
| jq '{me: .data.me.username,
       publications: [.data.me.publications.edges[].node | {id, title, url}],
       errors: .errors}'
```

The `node.id` is the `publicationId` every write needs.

## 2. Publish a post (public, immediate)

```bash
VARS=$(jq -n --arg p "$PUB_ID" --arg t "$TITLE" --arg b "$(cat article.md)" '{
  input: {
    publicationId: $p,
    title: $t,
    contentMarkdown: $b,
    tags: [ {name:"AI", slug:"ai"}, {name:"Web Development", slug:"web-development"} ]
  }
}')

gql 'mutation PublishPost($input: PublishPostInput!) {
       publishPost(input: $input) { post { id slug url title } } }' "$VARS" \
| jq '{post: .data.publishPost.post, errors: .errors}'
```

Useful optional input fields:

| Field | Purpose |
|---|---|
| `subtitle` | Post subtitle |
| `slug` | Custom URL slug (otherwise derived from the title) |
| `canonicalUrl` / `originalArticleURL` | Point SEO back to the original when cross-posting |
| `coverImageOptions: { coverImageURL: "https://…" }` | Cover image |
| `publishedAt` | ISO-8601 timestamp, to backdate |
| `settings` | `disableComments` and similar toggles |
| `seriesId` | Add the post to a series |
| `publishAs` | Publish on behalf of another author (also the way to change author on `updatePost` / `updateDraft`) |

Tags must be objects with `name` + `slug`; a plain string array is silently
ignored. Slug lowercase, hyphenated. Max 15 per post.

## 3. Save a draft (safe default)

```bash
VARS=$(jq -n --arg p "$PUB_ID" --arg t "$TITLE" --arg b "$(cat article.md)" \
  '{input: {publicationId: $p, title: $t, contentMarkdown: $b}}')

gql 'mutation CreateDraft($input: CreateDraftInput!) {
       createDraft(input: $input) { draft { id slug title } } }' "$VARS" \
| jq '{draft: .data.createDraft.draft, errors: .errors}'
```

Publish it later:

```bash
gql 'mutation PublishDraft($input: PublishDraftInput!) {
       publishDraft(input: $input) { post { id url } } }' \
    "$(jq -n --arg d "$DRAFT_ID" '{input:{draftId:$d}}')"
```

## 4. Update a published post

```bash
VARS=$(jq -n --arg id "$POST_ID" --arg b "$(cat article.md)" \
  '{input: {id: $id, contentMarkdown: $b}}')

gql 'mutation UpdatePost($input: UpdatePostInput!) {
       updatePost(input: $input) { post { id url title } } }' "$VARS"
```

## 5. List my posts

```bash
gql 'query { me { posts(pageSize: 20, page: 1) {
       nodes { id title slug url views reactionCount responseCount publishedAt } } } }'
```

## 6. Cover / OG images

Images use a two-step presigned S3 upload flow — request the presigned URL from
the API, `PUT` the bytes to it, then pass the resulting public URL as
`coverImageOptions.coverImageURL`. See `references/recipes.md` in the official
skill for the exact mutation names and payload limits before attempting it.

## Errors and limits

- GraphQL returns HTTP 200 even on failure — always read `errors[]`.
- `UNAUTHENTICATED` → PAT missing or invalid.
- `FORBIDDEN` + "Publication does not have an active Pro plan" → the publication
  must upgrade. **Do not retry.**
- All write mutations and publication-scoped reads (`publication`, `draft`,
  `scheduledPost`, `searchPostsOfPublication`, `topCommenters`) are Pro-gated.
  Public reads (`post`, `feed`, `user`, `tag`) are free and need no token.
- Page sizes cap at 100 (drafts 50); over-asking is silently clamped.
- Query depth ≤ 10.
- Cursor pagination: read `pageInfo.endCursor` / `pageInfo.hasNextPage`, pass
  `endCursor` as the next `after`.
- Queries may be cached ~25s; mutations never are.
