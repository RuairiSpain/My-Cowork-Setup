---
name: hashnode-publish
description: |
  Publishes and updates blog posts on a Hashnode blog through the Hashnode GraphQL
  API (publishPost, createDraft, publishDraft, updatePost), including title,
  subtitle, Markdown body, tags, slug, cover image and canonical URL for
  cross-posting. Use when the user asks to "publish this to Hashnode", "post this
  article on my Hashnode blog", "save a Hashnode draft", "update my Hashnode post",
  "cross-post this to Hashnode", "list my Hashnode publications", or mentions a
  Hashnode publication ID or personal access token. Do NOT use for writing or
  researching the article itself (use azure-blog-post or source-grounded-writing),
  for other platforms (Dev.to, Medium, WordPress, LinkedIn), or for publishing to
  SharePoint, Loop or Viva Engage.
license: MIT
metadata:
  category: automation
  icon: Globe
---

# Publish to Hashnode

Takes a finished Markdown article and puts it on the user's Hashnode blog through
the Hashnode GraphQL API. Drafts are the safe default; public publishing happens
only when the user has clearly asked for it.

Grounded in the official Hashnode agent skill
([Hashnode/gql-skill](https://github.com/Hashnode/gql-skill)). That skill's
`references/` folder (`schema.graphql`, `queries.md`, `mutations.md`,
`auth-and-roles.md`, `errors-and-limits.md`, `recipes.md`) is the canonical
field-level reference — consult it for exact field names before inventing any.

## When NOT to Use

- **Writing the article.** This skill ships finished Markdown. If the post does not
  exist yet, write it first (`azure-blog-post`, `source-grounded-writing`, `docx`),
  then come back here.
- **Any other platform** — Dev.to, Medium, WordPress, Substack, LinkedIn, Ghost.
- **Internal Microsoft 365 publishing** — SharePoint pages, Loop, Viva Engage,
  Teams posts. Use the SharePoint/Teams tools instead.
- **Reading someone else's public Hashnode content for research** — a plain web
  fetch is simpler and needs no token.

## Prerequisites (check before anything else)

| Need | Where it comes from | If missing |
|---|---|---|
| Personal Access Token (PAT) | Hashnode dashboard → Account Settings → Developer / API tokens, exported as `HASHNODE_PAT` | Ask the user to export it in the session; never ask them to paste it into chat |
| `publicationId` | The `me` query below — it is NOT the username or blog URL | Run the query; if several publications come back, ask which blog |
| Pro plan on the target publication | Hashnode account | Stop and tell the user to upgrade; do not retry |

The Hashnode account for this user is **lapido@gmail.com** — if the `me` query
returns a different username, stop and confirm before writing anything.

Never print, echo, log or store the PAT. Reference it only as `$HASHNODE_PAT`
inside shell interpolation, and never write it into a file in `output/`.

## Endpoint and auth

- POST GraphQL to `https://gql.hashnode.com/` (the official skill documents
  `https://gql-beta.hashnode.com/`; if one returns a routing/404 error, try the
  other). Body is `{"query": "...", "variables": {...}}`.
- Header: `Authorization: $HASHNODE_PAT`. Hashnode expects the **raw token**;
  sources differ on whether a `Bearer ` prefix is accepted, so if the first call
  returns `UNAUTHENTICATED`, retry **once** with the other form before reporting
  an auth failure.
- GraphQL always returns HTTP 200 — real failures live in the JSON `errors`
  array. Always inspect it and report it verbatim.

## Workflow

1. **Confirm the content.** Identify the exact Markdown body, title, and (if
   given) subtitle, tags, slug, cover image URL and canonical URL. Never
   invent or embellish the article's text.
2. **Resolve the publication.** Run the `me` query
   (see [references/graphql-recipes.md](references/graphql-recipes.md)) to get
   `publicationId`. One publication → use it. Several → ask which one with
   `core-AskUserQuestion`, listing their titles and URLs.
3. **Decide draft vs. publish.**
   - The user said "publish", "post it live", "ship it" → `publishPost`.
   - Anything less explicit ("get it ready", "put it on Hashnode", no verb) →
     `createDraft`, then tell them the draft is waiting and offer `publishDraft`.
4. **Build the input.** `publicationId`, `title`, `contentMarkdown` are required.
   Tags are objects, not strings: `{name: "Web Development", slug: "web-development"}` —
   slug lowercase and hyphenated, max 15 tags, 1–5 is a sensible range. When the
   article also lives elsewhere, always set `canonicalUrl` to the original.
5. **Send the mutation** with `RunScript` or `Bash` (jq + curl pattern in the
   recipes file). Pass the body through a variables JSON built by `jq -n --arg`
   so quotes and newlines in the Markdown are escaped correctly — never
   string-concatenate Markdown into a GraphQL query.
6. **Verify and report.** Read back `post.url`, `post.slug`, `post.id` from the
   response. Confirm the `errors` array is absent before calling it published.
7. **Save the post id** in your reply so a later `updatePost` has it.

## Output format

Report back in a few lines, no card needed:

```
Published to <publication title>
Title:  <title>
URL:    <post.url>
Tags:   <tags>
Post id: <post.id>   (keep this to update the post later)
```

For a draft, say "Saved as a draft on <publication title>" plus the draft id, and
end with the offer to publish it.

If the call failed, quote the GraphQL `errors[].message` and `extensions.code`
verbatim and say what the user needs to do — never paraphrase an API error into a
guess.

## Error handling

| Response | Meaning | Action |
|---|---|---|
| `UNAUTHENTICATED` | Missing/invalid PAT | Retry once with the other Authorization header form, then ask the user to re-export a valid PAT |
| `FORBIDDEN` + "does not have an active Pro plan" | Publication is not Pro | **Stop. Do not retry.** Tell the user to upgrade in the Hashnode dashboard |
| Tags silently missing on the live post | Tags were passed as strings | Re-send with `{name, slug}` objects |
| "Publication not found" | Wrong `publicationId` | Re-run the `me` query; never guess the id from a URL or username |
| Name resolution / network failure | The session has no outbound network | Do not fake success. Save the exact ready-to-run request to `output/` and tell the user to run it where the API is reachable |

Other limits worth respecting: page sizes cap at 100 (drafts 50), query depth
must stay ≤ 10, pagination is cursor-based via `pageInfo.endCursor` /
`hasNextPage`, and mutations are never cached while queries may be cached ~25s.

## Guardrails

- **Publishing is public and hard to undo.** When intent is anything short of an
  explicit publish instruction, create a draft instead and say so.
- **Never publish content the user has not seen.** Show the title, tag list and
  first lines, or point at the source file, before the mutation.
- **Never fabricate** article text, tags, a publication id, a post URL, or a
  success. A response is published only when the API returned a `post.url`.
- **Token hygiene:** the PAT grants full write access to every publication on the
  account. Never echo it, never commit it, never put it in a deliverable, and
  never send it to any host other than the Hashnode endpoint.
- **One post per call.** For a batch, confirm the list first, then publish
  sequentially and report each result — stop the batch on the first hard error.
- **Respect copyright.** Do not publish text reproduced from third-party sources
  beyond short attributed quotes.
