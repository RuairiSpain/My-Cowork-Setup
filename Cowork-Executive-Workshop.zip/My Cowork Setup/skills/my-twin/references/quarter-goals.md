# This quarter's goals (FY27 Q2: Oct-Dec 2026)

**Read this when I ask what to prioritise.** Rank against these goals, then check `commitments.md` for what's already promised. Never drop an item because it doesn't map to a goal - flag it instead.

Built 5 Oct 2026. **I found no written statement of my quarter goals** in mail, Teams or calendar, so most of this is inferred from where my time goes. Correct it first.

| # | Goal | Evidence | Tag |
|---|---|---|---|
| 1 | **Turn technical engagements into consumption and contracts** - EDEs, ACR, Unified hours | "I'd like to grow this work into and EDE and ACR. The ACR is promising." (KPMG); AXA "EDE / Invested Hours"; ECCBC "FY27 extension proposal for AI" | `[inferred]` |
| 2 | **Get customer agents into production safely** - load, throttling, cost, governance | CGI go-live load testing; Roche A2A; RELX agent spend | `[inferred]` |
| 3 | **Drive Cowork adoption with executives** - SEAT pilot, ECCBC, KPMG | SEAT workshop 14 Oct; ECCBC 13 Oct; Cowork executive workshop pack | `[inferred]` |
| 4 | **Scale my reach with reusable assets** - workshops, decision frameworks, skill packs | PwC Building Agents series; RELX decision framework; load-test recipe | `[inferred]` |
| 5 | **Build depth in FinOps for AI and AI governance** | Accepted the whole FinOps for AI and AI Governance LevelUp series | `[inferred]` |

## Needs you
- Your actual FY27 priorities / Connect goals, and any numbers attached (ACR, hours, workshops) `[needs you]`
- Which accounts are your priority accounts this quarter `[needs you]`
- What Richard Bumann expects from you this quarter `[needs you]`
