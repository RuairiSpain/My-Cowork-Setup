# Current work

**Read this when I ask about current work** - a project's status, what's next, or "where are we with X". Recognise projects with it; never use it to filter what to look at.

Built 5 Oct 2026. Tags: `[observed]`, `[inferred]`, `[needs you]`. **Goes stale - refresh every couple of weeks.**

## Projects in flight

| Project | State (5 Oct) | Next | Tag |
|---|---|---|---|
| **CGI - AI intranet agent** (Foundry hosted agent, AI Search, BFF, Canada East) | 10-user test clean (1,291 questions). 30-user run hit 100,840 HTTP 429s on session creation at ~2 sessions/s; search 0% throttled | Rerun with diagnostics; AI Gateway PoC; send YAML config; working session | `[observed]` |
| **SEAT - Cowork pilot** | Outline + executive use-case PDF sent to Jordi 29 Sep | Workshop 14 Oct | `[observed]` |
| **SEAT - APIM for AI APIs** | Session booked | 8 Oct; prep the questions | `[observed]` |
| **SEAT - AI-assisted coding hackathon** | Ran 23 Sep - "everyone left really happy" (Jordi) | Done | `[observed]` |
| **ECCBC - Cowork + FY27 AI extension** | Outline ready; Patrice pushing on Digital Accelerator | Session 13 Oct, adapted to Patrice | `[observed]` |
| **KPMG Spain - Foundry + AI Search + Fabric data agents** | Customer has architecture; blockers: Fabric IQ ↔ Fabric agents, index access via private network | Follow-on call; grow to EDE/ACR; ACA review scoping | `[observed]` |
| **Roche - A2A Copilot Studio ↔ external agent** | Connection created; JSON-RPC call fails with generic SystemError | Their gateway/CloudWatch logs | `[observed]` |
| **RELX - agent platforms and spend** | Decision framework sent 29 Sep | Consumption analytics findings with Duygu | `[observed]` |
| **PwC - Building Agents (Copilot Studio + Foundry)** | Sessions 1-3 done | Session 4 on 7 Oct; PwC NL 2-day labs 8-9 Oct | `[observed]` |
| **Nespresso / Nestlé** | VMSS deletion incident closed; post-mortem 28 Sep; traffic analytics | Health assessment deep dives 16 Oct; doc change request | `[observed]` |
| **AXA UK - Document Understanding** | Weekly technical connect | EDE / invested hours, 5 Oct | `[observed]` |
| **FCC, IE University, Avaloq** | Foundry sessions / scoping | FCC working group 8 Oct | `[observed]` |

## My own write-ups (calibration for voice and depth)
Quoted from my sent mail. Private - never paste into anything addressed to someone else.

### 1. CGI - load test recipe (18 Sep)
> Morning! Here are steps to simulate users hitting the Web page and doing sustained searches. It would be good to run, to check how your code and search work under load.
> 1. In the Azure Portal, open Azure Load Testing and select Create test.
> 2. Choose URL-based test (or JMeter if more advanced scenarios are needed).
> ...
> 4. Configure the load pattern: • Users: 30 (this is simultaneously on your server) • Ramp-up time: 1 minute • Test duration: 30 minutes
> ...
> 7. Add success criteria, such as: • Error rate < 1% • Average response time < 3 seconds

### 2. SEAT - Cowork workshop outline (29 Sep)
> Hi Jordi,
> I've attached the draft workshop outline. The hands-on labs are targeted at executives and people managers, and the outline explains my proposed workshop approach. I estimate the session would take approximately half a day (4 hours).
> ...
> The key message is that Cowork is not limited to generating Word documents or PowerPoint presentations. It can orchestrate multiple skills, data sources, and business processes to automate more complex end-to-end tasks.
> Best regards,
> Ruairi

### 3. RELX - agent decision framework (29 Sep)
> Hi Team,
> Apologies for the delay.
> Here is a decision framework covering the main Microsoft agent platforms, workflows and knowledge approaches. I've distilled the options into 5-6 pages, it could be 50 pages if we include more variables and integrations. I've including Agent search choices, because I believe that will be a big factor in your agent plans.

### 4. Roche - A2A assessment (1 Oct)
> My current assessment is:
> 1. The agent card is reachable, but Copilot Studio may not be interpreting it fully.
> ...
> The most useful evidence will likely be in the API Gateway and CloudWatch logs.

### Assets
- RELX_Agentic_Decision_Factors.pdf (sent 29 Sep)
- Advanced-Cowork-Use-Cases-SEAT-Executives PDF (sent 29 Sep)
- Cowork-Executive-Workshop-Pack (in my OneDrive)
- Azure AI Search vs Foundry IQ comparison PDF (sent to KPMG 3 Sep)
