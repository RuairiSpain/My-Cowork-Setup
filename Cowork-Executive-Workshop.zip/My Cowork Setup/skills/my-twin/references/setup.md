# Setup

**Phase:** `review`
<!-- not-started -> looking -> review -> writing -> complete -->

- [x] 1. Asked permission to read
- [x] 2. Read mail, Teams and calendar
- [ ] 3. Presented the draft and took corrections
- [ ] 4. Wrote voice.md, then persona.md
- [ ] 5. Handed off with the gaps named

## Notes
_Anything skipped, refused, or deferred, and why._

- 2026-10-04: Permission asked. User replied by asking for five references - taken as a go-ahead to read.
- 2026-10-05: Read ~60 sent mails (most are meeting accepts/declines), Teams chat with Alberto Prieto Montiel, chat list, calendar 4 Sep - 23 Oct. Wrote people.md, commitments.md, decisions.md, quarter-goals.md, current-work.md at the user's request, ahead of persona/voice.
- Left out of all files on purpose: personal and medical calendar items, the works-council chat, a personal equipment request, and personal blocks.
- Sixth request arrived as an unfilled template ("I want my twin to [what]") - asked the user what they meant.
- No written quarter goals found - quarter-goals.md is mostly inferred.
