# Decisions

**Read this before proposing a change of approach.** If a proposal reverses or contradicts a decision below, name the decision and why it was made before recommending the change.

Built 5 Oct 2026. Tags: `[observed]`, `[inferred]`, `[needs you]`. Add new decisions as they're made.

## CGI - AI intranet agent (Foundry hosted agent, ~90K users)
- **Diagnose before fixing.** "before we jump to fix, let's redo the test so we can identify the root cause" - add BFF + hosted-agent diagnostics, rerun the 30-user load test. (mail 28 Sep) `[observed]`
- **Stay at 0.5 vCPU per agent** until better logging gives clearer metrics. (meeting 30 Sep) `[observed]`
- **Reuse idle hosted-agent sessions** rather than spin up a micro-VM per request - no conversation state is stored. (30 Sep) `[observed]`
- **Staged, country-by-country rollout**, with country as the metadata switch; AI icon stays visible with a holding message, which doubles as a kill switch. (team decision, 30 Sep) `[observed]`
- **AI Gateway proposed** to filter by country/BU before the BFF; SPFx flag list + BFF whitelist as backstop. (30 Sep) `[observed]`
- **Idle session time is billable** until the idle timeout deprovisions compute - I corrected the earlier understanding. (mail 24 Sep) `[observed]`

## SEAT - Cowork pilot
- **Half-day (4 h) hands-on workshop for executives and people managers**, centred on *Executive* skills that orchestrate everyday skills. (mail 29 Sep) `[observed]`
- **Core message: Cowork is not just Word/PowerPoint** - it orchestrates skills, data and processes end to end. `[observed]`

## KPMG Spain
- **Call it a follow-on, not a scoping call.** Aim: grow the work into an EDE and ACR - "The ACR is promising." (29 Sep) `[observed]`
- KPMG's direction: Cowork as the front end; MCP plugin as PoC path because Fabric IQ can't query Fabric agents today. (their decision, 16 Sep) `[observed]`
- **Before ACA work, reassess whether they need it** - asked for a 10-minute scoping call. (29 Sep) `[observed]`

## Roche - A2A
- Supported pattern: **Teams → Copilot Studio agent → A2A connection → external agent.** An external A2A agent can't be published directly as a Teams app. (1 Oct) `[observed]`
- Validate the agent card before debugging Copilot Studio config. (29 Sep) `[observed]`

## RELX
- **Use one distilled decision framework (5-6 pages)** rather than an exhaustive one; prove it on a real scenario (Insight IR agent, good for ROI). (29 Sep) `[observed]`

## Calendar
- **Mon-Wed 14:00-15:00 customer calls are fixed.** `[observed]`
- I decline Asia-timezone repeats of community calls and LevelUps and take the EMEA/Americas option. `[observed]`
