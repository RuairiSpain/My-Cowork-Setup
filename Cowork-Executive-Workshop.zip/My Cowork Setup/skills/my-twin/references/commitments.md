# Commitments

**Read this before suggesting I take anything else on.** If a new ask collides with anything below, say which commitment it collides with before recommending yes. Never treat something as unimportant because it is not listed here.

Built 5 Oct 2026 from mail, Teams and calendar. Tags: `[observed]`, `[inferred]`, `[needs you]`. **Goes stale fast - refresh weekly.**

## Standing constraints
- **Mon-Wed 14:00-15:00: customer calls I can't move.** "my lunchtimes 2-3pm, have customer calls Monday to Wednesday each week. I can't move them." (Teams to Alberto, 2 Oct) `[observed]`
- **12 Oct: Spanish national holiday (OOF).** `[observed]`
- **19-20 Oct: provisionally booked all day** (Teams to Alberto, 2 Oct) `[observed]` - what for `[needs you]`

## Dated commitments
| When | What | With | Source |
|---|---|---|---|
| 5 Oct 09:30 | Quick internal sync - KPMG Spain | Roberto Guran | calendar `[observed]` |
| 5 Oct 12:30 | Doc Understanding - Use Case Support - EDE / invested hours | AXA UK (Benjamin Dunn) | calendar `[observed]` |
| 7 Oct 09:00-13:00 | PwC Session 4: Building Agents with Copilot Studio and Foundry Agents (I organise) | PwC | calendar `[observed]` |
| 8-9 Oct (all day) | PwC NL workshop - Develop AI Apps and Agents on Azure with Labs, 2 days (I organise) | PwC NL | calendar `[observed]` |
| 8 Oct 11:00 | Grupo de Trabajo - Agentes IA | FCC (Angel Perez Palacios) | calendar `[observed]` |
| 8 Oct 16:00 | SEAT - AI APIs through Azure API Management (2 h ROSS) - **prep the questions in advance** | SEAT, Alberto | calendar + Alberto's Teams 5 Oct `[observed]` |
| 13 Oct 14:00-17:00 | ECCBC Cowork session (blocked) - **adapt to Patrice's ask** | ECCBC, Alberto | calendar + Teams 5 Oct `[observed]` |
| 14 Oct 11:00-14:00 | Hands-on Copilot Cowork Workshop - SEAT pilot (half day, execs and people managers) | Jordi Navarro | calendar + mail 29 Sep `[observed]` |
| 16 Oct 10:00 | Nespresso Azure Health Assessment deep dives (not yet responded) | Avanade / Nespresso | calendar `[observed]` |

## Open promises (no date agreed)
- **CGI:** build an **AI Gateway proof of concept** for country/BU filtering; **send the Azure YAML config** for micro-VM spin-up vs session reuse (meeting summary 30 Sep, both "Not Started") `[observed]`
- **CGI:** working session with Rosemarie, Ilyes and Yanis on AI Gateway config / load testing - Rosemarie to set up `[observed]`
- **RELX:** share consumption analytics/reporting findings with Duygu - "We will share our findings separately." (29 Sep) `[observed]`
- **KPMG:** follow-on call (Roberto to set up); 10-min scoping call on ACA architecture review / CI-CD guardrails `[observed]`
- **Nespresso:** I raised a change request on a doc page and the related Learn pages - "I'll update you when I get an update." (28 Sep) `[observed]`
- **Roche:** A2A troubleshooting - waiting on their API Gateway / CloudWatch logs `[observed]`

## Learning I've accepted (movable)
Many FY27 LevelUp sessions are accepted most weeks (FinOps for AI, AI Governance, Azure Monitor). Treat these as **movable** unless I say otherwise `[inferred]`.
