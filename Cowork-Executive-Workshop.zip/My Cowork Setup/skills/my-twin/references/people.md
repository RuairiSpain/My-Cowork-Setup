# People

**Read this whenever a named person is involved** - in a triage item, a draft, or a question about who to involve. Use it to recognise people, never to decide what matters: someone not listed here is not less important.

Built 5 Oct 2026 from sent mail, Teams and calendar (4 Sep - 31 Oct 2026). Tags: `[observed]` straight from mail/chat/calendar, `[inferred]` a reasonable read, `[needs you]` a guess for Ruairi to correct. **Goes stale - refresh monthly.**

## Microsoft - account teams and managers

| Person | Role / account | What they need from me | How I talk to them |
|---|---|---|---|
| **Alberto Prieto Montiel** | CSAM-type lead for SEAT and ECCBC `[inferred]` | Availability fast, session prep done in advance, outlines ready to forward to customers (Jordi at SEAT, Patrice at ECCBC). Raises ROSS/scoping requests. 5 Oct: asked me to prep the SEAT APIM session (2 h ROSS) and adapt the ECCBC Cowork session to Patrice's ask `[observed]` | Teams, short and blunt: "14th", "Now is good", "Free between 13:00 and 14:30". States constraints flatly: "my lunchtimes 2-3pm, have customer calls Monday to Wednesday each week. I can't move them." `[observed]` |
| **Roberto Guran** | Account lead for KPMG Spain `[inferred]` | Sets up customer calls I ask for; checks I've followed up with KPMG `[observed]` | Informal, directive: "Hey, Welcome back to reality! Could you setup call with KPMG? Label it a follow-on call, rather than a scoping call." `[observed]` |
| **Claire Rowe** | Customer Success Principal, RELX `[observed]` | Write-ups when promised; she brokers sessions with RELX and promotes my demos/workshops `[observed]` | Honest about slippage: "I haven't had time to write it up. Will try to send tomorrow morning -R" `[observed]` |
| **Duygu Silivri** | Microsoft, RELX team `[observed]` | Joint review of consumption analytics/reporting options for RELX - findings to be shared `[observed]` | `[needs you]` |
| **Sabrine Boumelala** | Nespresso / Nestlé account `[inferred]` | Incident/post-mortem support (VMSS deletion), Unified acceleration. **OoO 6-21 Oct**: stand-in Daniel Nikli on 6 Oct, Anahita Talebi Amiri 7-21 Oct `[observed]` | `[needs you]` |
| **Avinash Kumar** | Microsoft, CGI and AXA UK `[observed]` | Pulls me into CGI SharePoint and AXA UK Document Understanding work `[observed]` | `[needs you]` |
| **Christoph Mahr** | Microsoft, Roche `[observed]` | Fallback when I can't take Roche work: "If that's too late, Christoph can find someone." `[observed]` | `[needs you]` |
| **Graham Tyler** | 1:1 with me (24 Sep) `[observed]` - relationship `[needs you]` | `[needs you]` | `[needs you]` |
| **Richard Bumann** | My manager (Sr CSA Manager) | I cancelled our 1:1 on 29 Sep `[observed]`; what he needs from me `[needs you]` | `[needs you]` |
| **Samuel Padilla** | Microsoft, Fabric (at FabCon) `[inferred]` | I asked him to meet KPMG Madrid on Fabric data agents `[observed]` | "@Samuel Padilla, you are at FabCon this week? Do you have time to meet up with these guys from KPMG Madrid?" `[observed]` |

## Customers

| Person | Organisation | What they need from me | How I talk to them |
|---|---|---|---|
| **Jordi Navarro Seró** | SEAT - Digital Workplace & Productivity Platforms | Cowork use cases, "wow" cases, which profiles benefit; then the half-day hands-on workshop (14 Oct) `[observed]` | Formal-ish, structured: "Hi Jordi, I've attached the draft workshop outline..." signed "Best regards, Ruairi" `[observed]` |
| **Xavier Farre Lopez, Oscar Iglesias Bou** | SEAT | AI-assisted coding hackathon (ran 23 Sep) `[observed]` | `[needs you]` |
| **Patrice** | ECCBC | Cowork session adapted to his ask; pushing on Digital Accelerator `[observed via Alberto]` | `[needs you]` - I haven't written to him directly in the window |
| **Rosemarie Dumont** (+ Ilyes Mzoughi, Djamel/Yanis Yoni, Valerie Guillot, Chris Green) | CGI - AI intranet agent, ~90K users | Load-test diagnosis (429s on hosted-agent session creation), AI Gateway guidance, billing clarity before go-live `[observed]` | Long, numbered, technical, hedged where unsure: "my hunch... that's not 100% certain", "before we jump to fix, let's redo the test" `[observed]` |
| **Yuliya Bohdan, Adam Kursa** (+ Alessandra Tipa, Carlos Zubiaur) | Roche - Enterprise Search / integration | A2A from Copilot Studio to their external agent; Sinequa connector licensing answers `[observed]` | Diagnostic, step-by-step, sets limits on timing: "I'm busy today and tomorrow. I will investigate a solution for you on Friday." `[observed]` |
| **Marco Junior, Greg Benson, Antony Lynch, Clive Bastin** | RELX | Agent platform decision framework; GCH/agent spend per agent with timestamp ("If we cannot measure, then we cannot pay" - Clive) `[observed]` | "Hi Team, Apologies for the delay..." then offers to walk a real scenario `[observed]` |
| **Claudio Garcia Oreiro, Andrés Mesa Moya** | KPMG Spain - Oficina del Dato | Follow-on on Foundry + AI Search + Fabric data agents; Cowork as front end; network/permission blocker on index access `[observed]` | Warm, offers help; Andrés thanked me for speaking Spanish `[observed]` |
| **Benjamin Dunn** | AXA UK - Document Understanding | EDE / invested hours use-case support `[observed]` | `[needs you]` |
| **Angel Perez Palacios** | FCC - Grupo de Trabajo IA + Infra / Agentes IA | Foundry sessions in Spanish `[observed]` | Spanish `[inferred]` |
| **Guilbert Payusan** | PwC NL | Building Agents series (Sessions 1-4) and 2-day labs workshop `[observed]` | `[needs you]` |
| **Claudia Fernández Estebaranz** | IE University | Foundry `[observed]` | `[needs you]` |
| **Fabio Vivaldelli** | Nespresso (traffic analytics) `[inferred]` | Traffic Analytics working sessions `[observed]` | `[needs you]` |
