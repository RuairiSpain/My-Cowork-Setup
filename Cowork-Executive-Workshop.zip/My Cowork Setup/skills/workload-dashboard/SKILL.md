---
name: workload-dashboard
description: |
  Generates an interactive, self-contained HTML dashboard of the user's workload across
  Outlook email, calendar meetings, Teams chats and other direct involvement - with
  customer/project, collaborator and source filters, a top-5 priority list and a
  time-allocation pie chart. Use when user asks for a "workload dashboard", a
  "dashboard of my workload", "what's on my plate next week as a dashboard", or to
  "summarize my work across email, meetings and Teams".
  Do NOT use for a plain text daily briefing, inbox triage only, or Copilot adoption
  dashboards - use those dedicated skills instead.
metadata:
  category: productivity
  icon: DataPie
  apps: "Outlook, Teams, Calendar"
  complexity: advanced
  toolkit-category: personal-productivity
---

# Workload Dashboard

## Overview
Researches everything the user is directly involved in for a time window (meetings, emails,
Teams chats, other M365 items), normalizes it into task records, and produces ONE interactive
HTML dashboard with filters, a top-5 task list and a time-allocation pie chart. Read-only:
it never sends, replies to, accepts or edits anything.

**Apps:** Outlook, Teams, Calendar (plus M365 search) | **Complexity:** Advanced | **Category:** personal productivity

## When to Use
- "Build me a workload dashboard for next week"
- "What's on my plate next week as a dashboard?"
- "Summarize my work across email, meetings and Teams" (visual, filterable output wanted)
- "Dashboard of my workload with Alice, Bob and Carol as collaborators, dark mode"

## When NOT to Use
- A quick text summary of today's meetings/mail -> use a daily briefing skill (`custom-daily-brief`, `daily-briefings`)
- Triage or clean-up of the inbox only -> use `inbox-triage` / `email-inbox`
- Copilot adoption / usage metrics dashboards -> use `create-copilot-adoption-dashboard`
- Generic dashboards over arbitrary data or persistent apps -> use `dashboards-microapps` or `create`
- Any request to reply, decline, reschedule or send - this skill is read-only

## Parameters (ask-free defaults - never block on questions)
| Parameter | Default if omitted |
|---|---|
| `TIME_PERIOD` | "next week" = Monday-Friday of the coming week. Recommend 1-2 weeks max; for longer ranges, proceed but note results are noisier |
| `NAME1, NAME2, NAME3` (top 3 collaborators) | Infer the 3 people the user interacts with most in the period (email senders/recipients + Teams chat members + meeting co-attendees, excluding the user). Resolve every supplied name with `me_profile-SearchPeople`; never guess an email address |
| `THEME` | "corporate blue" (other examples: dark mode, retro terminal) |
| `EXCLUDE_ALLDAY_OOO` | ON - drop calendar events that are all-day or showAs = oof |

## Core Prompt (implement faithfully)
> Research my [TIME_PERIOD], including all of the work I have to do across meetings, emails,
> Teams chats and other stuff I'm involved in directly.
> Your goal is to create an interactive HTML dashboard with filters, listed in order of
> prominence on the dashboard:
> - Customer/project
> - My top 3 collaborators [NAME1, NAME2, NAME3]
> - Task location or response mechanism (e.g. Teams, Outlook, calendar, etc.)
> - If available, each task should have a deep link to the source item
> My top 5 tasks should be prominently displayed at the top, and should respond to the filters/slicers.
> There should be a pie chart showing projected time required in Teams, Outlook, meetings, misc.
> All visualizations should update when one of the filters or slicers is selected.
> The theme of the dashboard should be [THEME].
> As a final task, review the dashboard for legibility, font size, interestingness and overall
> visual quality, making adjustments if necessary.

## Workflow

### Step 1: Resolve context and dates
1. Call `outlook_calendar-GetUserDateAndTimeZoneSettings` (fallback: `me_profile-GetMyDetails`) for the user's timezone and identity.
2. Convert TIME_PERIOD to explicit start/end datetimes in the user's local timezone (e.g. "next week" -> Mon 00:00 to Fri 23:59). State the resolved range in the final summary.

### Step 2: Gather data (paginate every call fully)
- **Calendar:** `outlook_calendar-ListCalendarView` for the range. Skip all-day / OOO events when EXCLUDE_ALLDAY_OOO is ON. Skip events the user declined or that are cancelled. Private events: keep the time block but title them "Private appointment" and show no other details.
- **Outlook:** `outlook-ListMessages` (Inbox, recent ~14 days plus the period) to find items needing action: flagged, unread from people (not newsletters/notifications), direct asks or questions to the user, threads where the user is awaiting a reply. Use `outlook-GetMessage` only when the preview is insufficient to judge the ask.
- **Teams:** `m365_teams-ListChats` (most recent first), then `m365_teams-ListChatMessages` for chats active in the last ~14 days; keep chats with open asks, unanswered questions or @mentions of the user.
- **Other involvement:** `m365_search-SearchM365` for documents shared with / assigned to the user, comments and mentions in the period; classify as Misc.
- **Collaborators:** if names were supplied, resolve with `me_profile-SearchPeople`; if ambiguous, pick the best match by interaction frequency and note it. If not supplied, count interactions per person across all gathered items with code and take the top 3.

### Step 3: Normalize into task records
Each item becomes one record:
`{id, title, source: Teams|Outlook|Calendar|Misc, project, collaborators[], date, est_minutes, priority, link, notes}`
- `project`: infer from subject keywords, customer domains in participants, or chat/meeting name; else "Internal/Other".
- `est_minutes`: meetings = scheduled duration; emails 5-15 by complexity (short ask 5, decision/review 10, long/doc review 15); chats 5-10; misc estimated and labelled as an estimate.
- `priority`: score with explicit, documented factors (deadline proximity, sender seniority/manager, direct ask vs FYI, customer-facing, flagged/@mention, collaborator in top 3).
- `link`: only real URLs returned by tools (`webLink`, `onlineMeeting.joinUrl`, Teams message `webUrl`). If none, leave empty and show "No link". Never construct or fabricate URLs.

### Step 4: Compute with code
Use Python (bash) to dedupe, compute time totals per source bucket (Teams / Outlook / Meetings / Misc), per project and per collaborator, and rank priorities. Never do the arithmetic mentally. Embed the final records as a JSON array in the HTML.

### Step 5: Build the HTML dashboard
Single self-contained file - inline CSS and JS, **no CDN or external network dependencies**. Required layout, top to bottom:
1. Header: title, resolved date range, generated timestamp, data-gap notes.
2. Filter bar in this order: **Customer/project -> Top 3 collaborators -> Source (Teams/Outlook/Calendar/Misc)**, plus a "Clear filters" button. Multi-select chips or dropdowns.
3. **Top 5 tasks** as prominent cards (title, source badge, project, due/date, est. time, deep link) - recomputed from the filtered set.
4. **Pie chart** of projected time by Teams / Outlook / Meetings / Misc drawn with inline SVG or canvas, with legend showing hours and %.
5. Full task table (sortable) with deep links opening in a new tab.
All components re-render from one `applyFilters()` function on every filter change. Apply THEME through CSS variables. Each filter is a slicer: selecting a customer/project, collaborator or source instantly updates the top-5 cards, the pie chart, the totals and the table together.

### Step 6: Final QA pass (mandatory)
Review and fix before delivering: body text >= 14px, headings clearly larger; WCAG AA contrast for the theme; no overflowing/truncated text; empty-state messages when filters return nothing; pie and top-5 genuinely update; visual interest (badges, colour coding per source, hover states). Open the file / check the JS for errors (e.g. `node --check` on the extracted script) and adjust.

### Step 7: Deliver
Save to the output folder as `workload-dashboard-<YYYY-MM-DD>-to-<YYYY-MM-DD>.html` (write in `working/` and publish if `output/` is not directly writable). In chat, give a brief summary.

## Output Format
Chat summary (short):
```
Workload dashboard: <start> to <end> (<timezone>) -> output/workload-dashboard-<start>-to-<end>.html
Top 5: 1. <task> (<source>, <est>) ... 5. ...
Time split: Meetings Xh (Y%) | Outlook Xh | Teams Xh | Misc Xh  - total Xh
Collaborators: NAME1, NAME2, NAME3 (supplied | inferred)
Gaps: <anything not retrieved or estimated>
```

## Guardrails
- Read-only: never send, reply, accept/decline, flag, move or delete anything.
- Never fabricate tasks, people, emails or links; mark missing data clearly as a gap.
- Respect privacy: private events show only "Private appointment"; do not copy sensitive email body content into the dashboard beyond a short task title.
- Never guess email addresses - resolve people via `me_profile-SearchPeople`.
- Do not ask the user questions; apply the defaults above and state which defaults were used.
- If a data source fails or returns nothing, still build the dashboard from the rest and say which source is missing.

## Tips & Variations
- Replace the placeholders: TIME_PERIOD, NAME1-3, THEME.
- Keep the window to 1-2 weeks; longer ranges get noisy.
- Consider excluding All Day / OOO events (default ON).
- Variations: "this week so far", "dark mode", "retro terminal", "only customer X".

---
*Based on the Cowork Toolkit (community maintained).*
