---
name: azure-blog-post
description: |
  Produces a three-part Azure technical blog package: a runnable code-sample repo
  zipped ready to push to GitHub, a long-form blog post in markdown grounded in
  Microsoft Learn links, and social posts (X/Twitter thread + LinkedIn) in markdown.
  Use when user asks to "write a blog post about [Azure topic]", "blog about
  [Azure service]", "create a blog post and code samples", "write up [Azure
  feature] with examples", "turn this into a blog post", or "blog + repo + social".
  Do NOT use for internal status updates or stakeholder comms (use
  stakeholder-comms), for non-Azure/non-Microsoft topics, or for slide decks (use
  pptx).
metadata:
  category: writing
  icon: DocumentBulletListMultiple
---

## Overview

Turns an Azure topic into a complete publishable package: **a code repo (zip), a blog post
(markdown), and social posts (markdown)**. Every technical claim is verified against current
Microsoft Learn documentation before it is written — never against model memory, because Azure
API surfaces, role names, SDK versions and preview flags change monthly.

The blog post teaches by showing progressively harder scenarios, each mapped to the exact code
change it costs and the business problem it solves.

## When to Use

- "Write a blog post about Azure Container Apps scaling"
- "Blog about Foundry hosted agents with code samples"
- "Create a blog post, repo and social posts for [Azure feature]"
- "Turn what we just worked out into a blog post"

## When NOT to Use

- Internal updates, escalations, or audience-targeted business comms — use `stakeholder-comms`
- A presentation or deck — use `pptx`
- A Word document deliverable — use `docx`
- Non-Azure / non-Microsoft topics — there is no Learn grounding to anchor them
- A pure code sample with no write-up — just build the repo directly

## Quick Start

```
User: "Write a blog post about managed identity in Azure Container Apps"
1. Scope: confirm the angle only if genuinely ambiguous; otherwise pick a strong default
2. Ground: web_search + web_fetch Microsoft Learn; collect exact quotes and URLs
3. Build the repo in working/, verify it compiles, zip it
4. Write the blog post in markdown, every claim tied to a Learn link
5. Write the social posts in markdown (single post + thread + LinkedIn)
6. Publish all three to output/ and confirm with exact filenames
```

## Core Instructions

### Step 1: Scope the post

Settle three things. Infer them from the conversation when you can; ask **at most one**
`core-AskUserQuestion` only if the topic itself is unclear.

| Decision | Default if unstated |
|---|---|
| Angle | The architectural decision a reader must make, not a feature tour |
| Scenario count | 3, ordered simplest → hardest |
| Audience | Cloud architects and senior engineers evaluating the service |

If this session already worked the problem through, **that conversation is the outline** —
do not re-derive it, and reuse the code already written and verified here.

### Step 2: Ground everything in Microsoft Learn (mandatory)

1. `web_search` the topic, targeting `learn.microsoft.com`.
2. `web_fetch` **every** page you intend to cite — search snippets are truncated and stale.
   Run independent fetches in parallel.
3. Collect for each source: canonical URL, page title, and the **verbatim sentences** that
   support each claim you will make.
4. Chase the linked "how-to", "concepts", "reference" and permissions pages; the trap that
   makes a post valuable (a permission not in any built-in role, a header that is silently
   ignored, a deprecation date) is usually one hop away from the landing page.
5. Note every version number, package name, role name, preview status and retirement date
   exactly as written.

**Verify, never recall.** If Learn does not state it, either leave it out or mark it
`[verify]`. A fabricated role name or SDK version destroys the post's credibility and the
reader's afternoon.

### Step 3: Build the code repo

Build under `working/<repo-name>/`, one folder per scenario, ordered by difficulty.

Required repo contents:

- `README.md` — what each scenario is, a difficulty table, prerequisites, run commands, layout
- `LICENSE` — MIT unless the user says otherwise
- `.gitignore`, `.env.example` (never real secrets), dependency manifest
- One folder per scenario, each with its **own README** stating the delta from the previous one
- Infra / permissions: role JSON, `az` commands, or Bicep where the feature needs them
- `docs/` — a choosing-a-pattern guide and a troubleshooting table

Code rules: comment the *why*, not the *what*; comment every line that encodes a documented
gotcha; fail closed on missing security context; never hardcode secrets or tenant IDs.

Then verify and package:

```bash
python -m py_compile <every .py>          # or the language's equivalent check
python -c "import shutil; shutil.make_archive('<repo-name>','zip','.','<repo-name>')"
python -c "import zipfile; print(len(zipfile.ZipFile('<repo-name>.zip').namelist()),'entries')"
```

`zip` is usually absent from the container — use `shutil.make_archive`. Exclude build caches
from the archive. Never ship a zip whose code you have not at least syntax-checked, and never
delete anything outside `working/`.

### Step 4: Write the blog post

Target **2,500–4,000 words**. Structure:

1. **Title + one-line subtitle** — name the decision the reader faces
2. **Hook** — the concrete moment the problem appears ("then the second user shows up")
3. **Primitives** — define the 2–3 concepts people conflate, as a comparison table, and name
   the bug that follows from conflating them
4. **One section per scenario**, simplest first, each containing:
   - What it is (with a short quote from Learn)
   - **The code change** — the actual diff from the previous scenario, not pseudocode
   - When it's useful
   - **3–4 business use cases** — named, concrete, with the numbers that force the choice
     ("40,000 employees, ~300 concurrent")
5. **Configuration section** — auth model, headers table, RBAC table, permission gotchas, CLI
6. **Choosing** — a decision tree plus a comparison table
7. **The repo** — the tree, and what each folder demonstrates
8. **Further reading** — every Learn page used, as reference-style markdown links

Voice: direct, second person, no marketing adjectives, no "in today's fast-paced world". Quote
Learn verbatim for anything surprising and attribute it inline. Surface trade-offs and failure
modes honestly — the honest caveat is why people trust the post.

### Step 5: Write the social posts

One markdown file with three variants:

- **Single post** — under 280 characters excluding the link; state the character count
- **Thread** — 5–8 numbered posts: hook → the confusion everyone hits → one per scenario →
  the big gotcha → config checklist + link
- **LinkedIn** — 150–250 words, prose not bullets-only, one genuine insight, 3–5 hashtags

Use `[link]` placeholders for the published URL. No emoji spam — a few structural ones only.

### Step 6: Publish and confirm

Save all three to `output/` via the artifact tools, confirm with `Glob output/**/*`, then name
each file by its exact filename. Flag anything preview-stage or fast-moving so the user pins
versions before publishing.

## Handling the awkward cases

| Situation | What to do |
|---|---|
| Learn contradicts itself across pages | Cite the more recently updated page, and say in the post that guidance differs |
| The feature is preview and the surface is moving | Ship it, but banner the preview status and the SDK versions you verified against |
| A doc page will not fetch | Retry once, then try the MicrosoftDocs GitHub mirror of the same article; if both fail, drop the claim rather than guessing |
| You cannot run the sample code (no subscription, no network) | Syntax-check only, and say plainly in chat that it is unexecuted |
| The topic spans more services than 3 scenarios hold | Narrow to one decision and offer the rest as a follow-up post — do not sprawl |
| The user only wants one of the three artefacts | Produce just that one; the package is a default, not a requirement |
| A retirement or deprecation date exists | Put it in the post body, not only the footnotes |

## Output

Three files in `output/`:

| File | Content |
|---|---|
| `<topic>-repo.zip` | Unzips to a `git init`-ready repo, all scenarios, verified to compile |
| `blog-<topic>.md` | 2,500–4,000 words, Learn-linked throughout, reference-style links |
| `social-<topic>.md` | Single post + thread + LinkedIn variant |

Chat summary: the repo tree, what the post covers, and any currency caveats.

## Guardrails

- **Never state an Azure fact you did not read on Learn in this session.** No recalled role
  names, SDK versions, API versions, limits, or dates. Mark gaps `[verify]`.
- **Never reproduce Learn pages wholesale.** Short quoted excerpts with attribution and links
  only — respect Microsoft's copyright.
- **Never ship unverified code.** Syntax-check before zipping; say so if you could not run it.
- **Never put secrets, tenant IDs, subscription IDs or real endpoints in the repo** — use
  `.env.example` and placeholders.
- **Flag preview surfaces and retirement dates explicitly** so the reader pins versions.
- **Never publish or post anything** — these are drafts for the user to review and ship.
- Do not fabricate metrics, customer names, or adoption statistics in the business use cases;
  keep them illustrative and clearly hypothetical.
