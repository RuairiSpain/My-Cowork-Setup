# Install and enable Code Output Validator

## Copilot Cowork

1. Open **Cowork** and select **Customize**.
2. Open **Skills**.
3. Select the arrow beside **Add**, then select **Upload skill**.
4. Upload `code-output-validator.skill` or `SKILL.md`.
5. Open **Preferences** and paste the contents of `CUSTOM-INSTRUCTIONS.txt` into custom instructions.
6. Start a new Cowork conversation before testing.

The custom instruction is important: a skill's description controls when it is selected, while Preferences are applied to every Cowork task. The instruction requests this skill whenever output contains code or executable configuration.

## Copilot Studio agent using the GitHub Copilot harness

1. Open the agent and select **Build**.
2. Under components, select **Skills**.
3. Select **Add skill** > **Upload a skill**.
4. Upload `SKILL.md` or `code-output-validator.skill`.
5. Add an agent-level instruction equivalent to `CUSTOM-INSTRUCTIONS.txt` so the agent invokes the validator after code-producing work.

## Test prompts

- `Create a Python API and validate all code before presenting the result.`
- `Review this Terraform and do not claim it is deployable unless validation passes.`
- `Package this project, run its tests, verify SDK parameters, and show the Validation report.`

## Expected result

The final answer should contain a `Validation` section with a verdict, checks run, fixes, anything not verified, residual risks, and one next action.
