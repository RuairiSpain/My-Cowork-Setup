---
name: onedrive-file-intelligence-cleanup
description: |
  Audits the user's OneDrive, catalogs files by age, type, relevance, customer and product,
  builds an animated 6-screen HTML executive dashboard, and drafts a Word reorganization and
  cleanup plan (folder structure, moves, DELETE_ rename candidates). Makes no OneDrive changes
  until the user explicitly approves. Use when user asks to "audit my OneDrive", "clean up my
  OneDrive", "analyze my OneDrive files", "reorganize my OneDrive", or "find duplicate files in
  OneDrive". Do NOT use for SharePoint site/library metadata or moving a single known file
  (use sharepoint-metadata instead), or for mailbox cleanup (use inbox-triage).
metadata:
  category: productivity
  icon: CloudArchive
---

# OneDrive File Intelligence & Cleanup

## Overview
Performs a full, evidence-based audit of the user's OneDrive (default drive), then produces two
deliverables: (1) a self-contained, animated, scroll-snap HTML executive dashboard — 5 overview
screens + 1 prioritized-recommendations screen — and (2) a written reorganization plan as a Word
document. It then STOPS at a hard approval gate. Nothing in OneDrive is renamed, moved, or created
until the user explicitly approves, and approved "deletions" are only ever `DELETE_` renames —
never real deletion.

## When to Use
- "Audit / analyze my OneDrive" or "what's in my OneDrive and how old is it"
- "Clean up / reorganize my OneDrive" or "propose a folder structure for my files"
- "Find duplicate or stale files in my OneDrive"
- Variations: "focus on files modified in the last 12 months", "make it a PowerPoint instead"

## When NOT to Use
- SharePoint site columns, content types, or moving one specific known file — use `sharepoint-metadata`
- Email/inbox cleanup — use `inbox-triage`
- A generic dashboard over non-OneDrive data — use `chart-builder` or `project-dashboard-builder`
- Actually (permanently) deleting files — out of scope; this skill only prefixes `DELETE_`

## Prerequisites
- Read/write access to OneDrive via the `sharepoint_onedrive` tools (and `graph` CallGraph for rename/move after approval).
- If access is denied, say so plainly and stop — never fabricate an inventory.

## Workflow

### Step 1 — Scope the drive
1. `sharepoint_onedrive-GetDefaultDrive` → drive id, owner, quota (total/used).
2. Do a quick top-level `GetDriveChildren` on root and estimate size from folder `childCount`s.
3. If the user supplied a time window ("last [TIME_PERIOD]") apply it. If the drive looks like
   **10,000+ files** and no window was given, default to files modified in the **last 24 months**,
   state that scope clearly in every deliverable, and offer to widen it.

### Step 2 — Inventory (recursive, paginated)
1. Walk the tree with `sharepoint_onedrive-GetDriveChildren` recursively from root, following
   every `@odata.nextLink` / page token until exhausted. Use `GetDriveItem` for any item missing fields.
2. For many calls, use a tool script (`core-RunScript`, see the `tool-scripts` skill) so the full
   payload is captured and nothing is truncated.
3. Capture per item: `name`, full `path`, `isFolder`, extension/type, `size`, `createdDateTime`,
   `lastModifiedDateTime`, `lastModifiedBy`, `webUrl`, item `id`, parent id.
4. Save the raw inventory to `working/onedrive-audit/inventory.json` (and `.csv`). Record the count
   of items fetched vs. any pages that failed — report gaps honestly.

### Step 3 — Categorize (computed by code, never by eye)
Run Python over `inventory.json` to derive:
- **Age band** (by last modified): <30d, 30–180d, 6–12m, 1–2y, 2–5y, 5y+.
- **File type family**: Documents, Spreadsheets, Presentations, PDFs, Images, Video/Audio,
  Archives, Code/Data, Other.
- **Relevance**: Active (modified ≤6m), Reference (6m–2y), Stale (>2y), Low-value (temp/empty/0-byte,
  `~$` lock files, `Copy of`, `(1)` copies, installers).
- **Customer / product**: match against folder names, file-name tokens and (optionally, for a
  sample) `ReadFileContent` snippets. Seed the dictionary from recurring path tokens and any
  customer/product names the user gives. If not clearly detectable, label **"Undetected"** — never guess.
- **Duplicates (optional / on request)**: exact = same normalized name + same size; probable =
  near-identical names (strip `copy`, `(1)`, `v2`, `final`, dates) with size within 5%.
- **Size hot spots**: largest files and folders, % of used quota.
Write `working/onedrive-audit/stats.json`. Every number shown anywhere downstream comes from this file.

### Step 4 — HTML executive dashboard (6 screens)
Build ONE self-contained HTML file (inline CSS/JS; charts via inline SVG/Canvas or an embedded
library — no runtime CDN dependency if avoidable) with **6 full-viewport scroll-snap screens**:
1. **Executive overview** — total files/folders/size, quota used, scope, animated count-up KPIs.
2. **Age disposition** — animated bar/area chart by age band, stale share callout.
3. **Type disposition** — animated donut by type family with hover tooltips (count + size).
4. **Relevance** — Active / Reference / Stale / Low-value, with size reclaimable estimate.
5. **Customer & product** — top customers/products by file count (Undetected shown explicitly);
   duplicates panel if run.
6. **Prioritized recommendations** — ranked actions (High/Medium/Low impact) each tied to a stat.
Include: scroll-snap, fade/slide-in transitions on enter (IntersectionObserver), hover states on
all chart marks and cards, a screen-nav dot rail, and respect `prefers-reduced-motion`. Embed
`stats.json` as data — no hand-typed numbers. Save to `working/onedrive-audit/onedrive-dashboard.html`
and publish to `output/onedrive-dashboard.html` (CopyArtifact `surface="output"` if a direct write fails).
*Variation:* if the user asks for PowerPoint, delegate a 6-slide deck to the pptx agent instead.

### Step 5 — Reorganization plan (Word)
Delegate to the **docx agent** a document `OneDrive-Reorganization-Plan.docx` containing:
1. Summary and scope (date, drive, filters applied, items analyzed).
2. **Proposed folder structure** — a tree (e.g. `/Customers/<Name>`, `/Products/<Name>`,
   `/Projects`, `/Admin`, `/Personal`, `/Archive/<Year>`), with the rationale.
3. **Delete candidates** — table: # | current path | proposed new name (`DELETE_<original name>`) |
   reason | size | last modified. Never mark as delete anything modified in the last 90 days unless it's an exact duplicate.
4. **Move / consolidate** — table: # | current path | destination path | reason.
5. **New folders to create.**
6. Risks, items needing user judgement, and how to undo (rename back / move back).
Number every item so the user can approve selectively. Save to `output/`.

### Step 6 — HARD APPROVAL GATE (never skip, never remove)
Present a concise summary in chat: counts of folders to create, moves, and `DELETE_` renames, plus
links to both deliverables. Then ask explicitly, e.g.:
> "Reply **approve all**, **approve** with item numbers / sections, or tell me what to change. I
> have made **no changes** to your OneDrive."
Make ZERO changes — no renames, moves, or folder creation — until the user replies with explicit
approval in this conversation. Silence, "looks good?" from you, or ambiguous replies are NOT approval;
ask again.

### Step 7 — Execute only approved items
1. Create approved folders (`sharepoint_onedrive-CreateFolder`).
2. Move approved items (`graph-CallGraph` PATCH `/me/drive/items/{id}` with `parentReference`).
3. Rename approved delete candidates to `DELETE_<original name>` (`graph-CallGraph` PATCH `name`).
   Never call DELETE on any item.
4. Handle name conflicts by stopping on that item and reporting it (no auto-overwrite).
5. Report a results table: item # | action | status (done / failed + reason / skipped). Partial
   approval executes only the listed items.

## Output Format
- `output/onedrive-dashboard.html` — 6-screen animated dashboard
- `output/OneDrive-Reorganization-Plan.docx` — numbered plan
- Chat: 5–8 line summary (scope, totals, top 3 findings, plan counts) + the approval request
- After execution: results table and anything that failed

## Guardrails
- **No changes without explicit approval.** The Step 6 gate is mandatory and cannot be waived by the skill.
- **Never permanently delete.** "Delete" means prefix with `DELETE_` only; the user deletes later.
- **Never fabricate** file names, counts, sizes, customers or products — all stats are computed by
  code from the real inventory; unknowns are "Undetected"; partial inventories are labeled partial.
- Do not open or summarize sensitive file contents (HR, finance, personal) beyond what's needed for
  classification; never include file contents in the dashboard.
- Act only on the user's own OneDrive; never touch shared-with-me items owned by others.
- If a tool call fails mid-execution, stop, report what was done, and do not retry destructively.

## Common Issues
| Issue | Fix |
|---|---|
| Huge drive / timeouts | Apply a time window; inventory via a tool script with pagination |
| Customer detection noisy | Ask the user for a customer/product list next run; keep "Undetected" |
| Rename conflict (`DELETE_x` exists) | Skip and report; propose `DELETE_2_x` for approval |
