---
name: inspect-artifact
description: |
  Verifies a finished deliverable by opening and inspecting the artefact itself —
  file, document, deck, workbook, message or code — instead of trusting the claim
  that it was produced correctly. Use when user asks to "check the actual file",
  "verify this deliverable", "did that really get created", "does the output match
  what was asked", or "sanity-check this before I send it".
  Do NOT use to agree what finished means before work starts — use
  definition-of-done for that.
metadata:
  category: analysis
  icon: DocumentSearch
---

## Overview

"Generated successfully" is a claim about a process; it is not evidence about a
result. Files land empty, sheets come out with the wrong headers, slides end up
with placeholder text, totals drift from their source figures, and the summary
still reads as a success. This skill inspects the artefact itself and reports
what is actually in it.

The rule it exists to enforce: **inspect the thing, not the account of the thing.**

## When to Use

- A deliverable was just produced and is about to be sent, shared or published.
- A result was reported as complete and needs confirming before it is relied on.
- A file, deck or workbook came from an automated or multi-step process.
- Numbers in a document need to be reconciled against their source.
- Something looks right in a summary but has not been opened.

## When NOT to Use

- Before the work exists — there is nothing to inspect yet.
- To establish the acceptance criteria themselves; use definition-of-done instead.
- To raise a blocked decision to a person; use escalate-one-question instead.
- To review code for defects as a change set — that is a code review.
- To judge subjective quality of writing style where no criterion was stated.

## Core Instructions

### Step 1: Locate the real artefact

Confirm the artefact exists where it is claimed to exist before saying anything
about it. Check `output/` with `Glob` for workspace deliverables; use
`sharepoint_onedrive-GetDriveChildren` / `ReadFileContent` for OneDrive and
SharePoint items; `outlook-GetMessage` for a sent or drafted message.

A path referenced in a summary is not proof of existence. If the artefact is
missing, stop — that is the finding, and it outranks everything else.

### Step 2: Open it and read the contents

Never judge from a filename, a byte count or a generation log.

| Type | Inspect by |
|---|---|
| Word / PDF | `host-InspectDocument` or the `pdf` skill; read headings and body text |
| Excel | Read every sheet named in the request; check headers, row counts, formulas |
| PowerPoint | `host-InspectDocument`; read each slide's real text, check for overflow |
| Markdown / text / code | `view` the file end to end |
| Email / message | Retrieve the sent item and read the body and recipients |

Read the whole thing when it is short, and the structurally significant parts
when it is long — every named section, sheet or slide the request called for.

### Step 3: Test it against the criteria

For each stated requirement, name the exact location in the artefact that
satisfies it — section heading, sheet name, slide number, page, cell. Mark each
requirement **pass**, **fail**, or **unverified**, and treat unverified as not passing.

Then run the standing checks that catch most real defects:

- **Emptiness** — zero-length file, blank sheet, slide with a title and nothing else.
- **Placeholders** — `TODO`, `TBD`, `[insert]`, `Lorem ipsum`, `XX`, a bracketed gap.
- **Arithmetic** — recompute every total, percentage, delta and average with a code
  tool and compare to what is printed. Do not check figures mentally.
- **Provenance** — each figure traces to a stated source; nothing appeared from nowhere.
- **Leakage** — no internal scaffolding in the body: container paths, session or
  tool identifiers, `working/`, `output/`, raw IDs, internal reference tags.
- **Completeness** — every section, column, sheet or slide the request named is present.
- **Fidelity** — the format matches what was asked (a `.docx` is not a spreadsheet).

### Step 4: Report what is in it, not what was intended

Quote or cite the specific evidence for each verdict. Where something fails, say
precisely what is wrong and where, so it can be fixed without a second search.

## Output

```
Inspection — <artefact name>

Verdict: Pass | Pass with issues | Fail | Not found

| Requirement | Verdict | Evidence (where) |
|---|---|---|

Issues found
1. <what is wrong, exactly where>

Not verified
- <anything that could not be checked, and why>
```

Lead with the verdict. Keep it short when everything passes; expand only on
issues. Name the artefact by its exact filename.

## Guardrails

- Never report on an artefact you have not opened.
- Never treat "created successfully", a log line or a summary as evidence.
- A missing or empty file is a Fail, stated plainly — not a caveat at the end.
- Never compute a figure by hand; use a code tool and show the comparison.
- Never fill a gap in the artefact with plausible content — report the gap.
- If the artefact cannot be read, say so and name the file; do not infer contents
  from its name, size or surrounding context.
- Unverified is never reported as passing.
- Inspect deliverables, never a person's performance.
