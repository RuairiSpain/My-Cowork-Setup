---
name: monday-morning-exec-briefing
description: |
  Builds a two-page executive briefing Word document from the last seven days of email, Teams chats and channels, the week ahead in the calendar, and recently modified files, surfacing the top five things to know, decisions needed, risks and escalations, the week-ahead schedule and a watch list. Use when the user says "prepare my executive briefing", "Monday briefing", "what do I need to know this week", "weekly exec summary", "brief me for the week", or asks to run this briefing on a recurring Monday schedule. Do NOT use for a single-day morning brief (use custom-daily-brief), for preparing one specific meeting (use board-meeting-prep), or for account risk scoring (use customer-health-review).
---

# Monday Morning Executive Briefing

## PURPOSE

Give a Cloud Solution Architect a single two-page executive read of the past week and the week ahead: what changed, what needs a decision, what is at risk, and what to watch. Every line is grounded in a real artefact the user can open. The deliverable is a styled Word document produced by the **docx-agent** — never hand-authored.

## WHEN TO USE

- "Prepare my executive briefing" / "Monday briefing" / "what do I need to know this week".
- Start of week, or after time away, when the user needs a catch-up plus a forward look.
- The user asks to schedule this briefing weekly.

## WHEN NOT TO USE

- A single-day catch-up or inbox triage → use the daily brief / inbox triage skills.
- Preparation for one named meeting → use `board-meeting-prep`.
- Account-level risk scoring across customers → use `customer-health-review`.
- Anything requiring outbound messages: this skill never sends mail or posts to Teams.

## INPUTS TO GATHER

Compute the window first: last 7 days (inclusive) for backward-looking data, next 7 days for the calendar. Use the user's own time zone via `outlook_calendar-GetUserDateAndTimeZoneSettings`.

| Signal | Tool | Notes |
|---|---|---|
| Email, last 7 days | `outlook-ListMessages` | Inbox first; filter by received date. Pull sender, subject, date, snippet |
| Cross-surface topics | `m365_search-SearchM365` | Keyword sweeps: escalation, at risk, blocker, decision, approval, slip, outage |
| Teams 1:1 and group chats | `m365_teams-ListChats` → `m365_teams-ListChatMessages` | Most recently active chats only |
| Teams channels | `m365_teams-ListChannels` → `m365_teams-ListChannelMessages` | Teams the user actually posts in |
| Week ahead | `outlook_calendar-ListCalendarView` | Next 7 days; capture subject, start, duration, organiser, attendee count |
| Recent documents | `sharepoint_onedrive-SearchDrive` | Files modified in the window; capture exact file names |
| People context | `me_profile-GetMyDetails`, `me_profile-SearchPeople` | Resolve ambiguous names before quoting them |

If a source returns nothing or errors, record it as a gap — never infer its contents.

## WORKFLOW

1. **Resolve context.** Get the user's time zone and identity; fix the exact start and end timestamps of both windows and state them in the document.
2. **Sweep email.** `outlook-ListMessages` over the window. Cluster by thread and by customer/project. Note unanswered threads where the user is the last-addressed party.
3. **Sweep search.** `m365_search-SearchM365` with the escalation/decision keyword set to catch items outside the inbox (Teams, files, shared mailboxes).
4. **Sweep Teams.** Chats and channels in the window. Capture explicit asks directed at the user and anything flagged urgent.
5. **Pull the week ahead.** `outlook_calendar-ListCalendarView` for the next 7 days. Identify meetings that need preparation (external attendees, exec attendees, decision items, no agenda).
6. **Pull recent files.** `sharepoint_onedrive-SearchDrive` for documents modified in the window; keep exact file names and links.
7. **Extract and classify.** For every candidate item record: what it is, source artefact (exact name), date, who is involved, and why it matters. Classify as one of: Top Five, Decision Needed, Risk/Escalation, Watch List. Discard noise (newsletters, automated notifications, FYI-only threads).
8. **Rank.** Top Five = highest business impact × urgency, with a bias to customer-facing and revenue-affecting items. Decisions Needed must each name the decision, the owner, and the deadline if one exists.
9. **Draft the content**, then delegate to the **docx-agent** with the brief below.
10. **Report inline**: one-paragraph summary, the five headlines, the file path of the document, and any gaps.
11. **Recurrence (only if asked).** See Scheduling.

## DELIVERABLE SPEC — brief for docx-agent

Delegate with a concrete brief; do not write the .docx yourself.

- **File name:** `Executive Briefing - <week commencing YYYY-MM-DD>.docx`
- **Length:** two pages, A4, professional executive layout, en-GB.
- **Sections, in order:**
  1. **Header block** — user name, role, week commencing date, data window covered.
  2. **Top 5 Things You Need to Know** — numbered; each is one bold headline plus at most two sentences, ending with `Source: <exact artefact name>, <date>`.
  3. **Decisions Needed** — table: Decision | Context | Owner | By when | Source.
  4. **Risks & Escalations** — table: Item | Customer/Project | Severity (High/Medium/Low) | Status | Source.
  5. **Week Ahead** — calendar table: Day | Time | Meeting | Attendees | Preparation needed.
  6. **Watch List** — 3-6 short bullets of things that are not yet actionable but may become so.
  7. **Gaps & Coverage** — sources checked, and anything unavailable.
- **Style:** Segoe UI, 10-11pt body, colour accents for severity, no clip art, no filler. Tables over prose wherever the data is tabular.

## EXECUTIVE VISUAL STANDARD

These artefacts are shown live to CEOs and CIOs — premium consulting-grade, never default Office.

- **Read `Executive/_shared/executive-design-standard.md`** (in the personal skills folder: `skills/Executive/_shared/executive-design-standard.md`) before building anything.
- **Copy the relevant sections verbatim into the brief** you hand to `docx-agent`. That agent cannot see the shared file, so citing it is not enough — paste the text.
- Sections to paste for this skill: **1 (Palette)**, **2 (Typography)**, **3 (Word rules)**, **7 (Never)**.
- Do not paraphrase, round or substitute: exact hex values, fonts, point sizes, table banding, status pills and footer rules are executed literally.
- One callout/pull-quote box carries the single most important finding; cover page, navy heading bars and the page-number footer are mandatory.
- **Any email produced is a DRAFT only** (`outlook-CreateDraftMessage`) — never sent unless the user explicitly asks to send in the current turn. Section 6 governs its subject line, bottom-line block and en-GB tone.
- **End the inline report with (a) the exact filenames produced and (b) an explicit list of evidence gaps** — write "No gaps" only when there genuinely are none.

## QUALITY BAR / VERIFICATION CHECKLIST

Before reporting success, confirm each:

- [ ] Every factual line cites an exact artefact name and date.
- [ ] No invented names, figures, quotes or dates anywhere.
- [ ] Top Five has exactly five items, or fewer with an explicit note on why.
- [ ] Every Decision Needed names an owner and a deadline, or marks them as unknown.
- [ ] The week-ahead table matches `ListCalendarView` output exactly (times in the user's time zone).
- [ ] The document is two pages; if it overflows, cut Watch List items, never sources.
- [ ] Sources checked and gaps are listed in the document.
- [ ] The file exists at the reported path and opens.

## FAILURE HANDLING

- **A tool fails or is unauthorised** → continue with the remaining sources, and list the missing source under Gaps & Coverage. Never silently degrade.
- **A quiet week (thin signal)** → produce the document anyway with fewer items and say plainly that the week was quiet; do not pad.
- **Ambiguous person or customer name** → resolve with `me_profile-SearchPeople`; if still ambiguous, write the name as it appeared in the source and flag it.
- **docx-agent fails** → retry once with a shorter brief; if it fails again, deliver the full briefing inline as markdown and say the document was not created.
- **Volume too large to read fully** → prioritise by recency and by threads involving the user directly, and state the sampling in Gaps & Coverage.

## SCHEDULING (only when the user asks for recurrence)

Run the briefing once interactively first so the user can confirm the shape. Then set it up with `host-SetupScheduledPrompt`:

- **Schedule:** weekly, Mondays at 07:00 in the user's local time zone (confirm the zone first).
- **Prompt text:** "Run the monday-morning-exec-briefing skill for the week commencing today. Cover the previous 7 days and the next 7 days, and save the Word document."
- Tell the user scheduled prompts are capped (five per user) and that they can review or remove them with `host-GetScheduledPrompts` / `host-DeleteScheduledPrompt`.
- Unattended runs must not require approvals: the document save is the only write, and no mail is ever sent.

## GUARDRAILS

- Read-only over the user's data. No email, no Teams post, no calendar change.
- Grounding discipline: no fabricated names, numbers, dates or quotes. Unknowns are written as explicit gaps.
- Office files are always produced by the docx-agent, never hand-authored.
- Personal, health or HR-sensitive content is summarised neutrally or omitted, never quoted.
